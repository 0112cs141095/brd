package com.nucleus;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String args[])
	{
		Configuration cfg=new Configuration ();
	cfg.configure();
SessionFactory s =cfg.buildSessionFactory();
Session session=s.openSession();
Transaction t=session.beginTransaction();



//======================================TO INSERT=========================

HBook143 b=new HBook143();
b.setBookId(105);
b.setBookName("book1");
session.persist(b);
HBook143 b1=new HBook143();
b1.setBookId(106);
b1.setBookName("book1");
session.persist(b1);
t.commit();


/*


//======================================TO DELETE ALL================================

session.delete(b);



//======================================TO DELETE SPECIFIC=============================
String hql = "delete from HBook143  where bookId=103";
session.createQuery(hql).executeUpdate(); 

HBook143 H1=(HBook143) session.get(HBook143.class, 104);
   if(H1!=null){
session.delete(H1);
}*/
//===================================To SHOW BY ID======================

/*HBook143 H1=(HBook143) session.get(HBook143.class, 104);
System.out.println(H1.getBookId());
System.out.println(H1.getBookName());



//==================================to show all==============================
List l=  session.createQuery("FROM HBook143").list();
System.out.println(l);
*/
//================================to update============================



//t.commit();
session.close();

		
	}
}
