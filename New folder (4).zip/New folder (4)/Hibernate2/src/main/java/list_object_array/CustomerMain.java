package list_object_array;

import java.util.ArrayList;
import java.util.List;






import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CustomerMain {

	public static void main(String[] args) {

		Configuration cfg=new Configuration ();
	cfg.configure();
SessionFactory s =cfg.buildSessionFactory();
Session session=s.openSession();
Transaction t=session.beginTransaction();



/*Customer c=new Customer();
c.setId(1);
c.setName("rohit");
c.setSalary(100f);

Customer c1=new Customer();
c1.setId(2);
c1.setName("rohan");
c1.setSalary(200f);

session.persist(c);

session.persist(c1);
*/


Query query=session.createQuery("select name,salary from Customer");
List<Object[]> list= query.list();
for(Object[] e:list)
System.out.println(e[0]+" "+e[1]);
t.commit();
	}

}
