package com.nucleus;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String args[])
	{
		Configuration cfg=new Configuration ();
	cfg.configure();
SessionFactory s =cfg.buildSessionFactory();
Session session=s.openSession();
Transaction t=session.beginTransaction();



//======================================TO INSERT=========================
Publication p=new Publication();
p.setDate(1);
p.setMonth(10);
p.setYear(2012);

HBook143 b=new HBook143();
b.setBookId(101);
b.setBookName("book1");
b.setPdate(p);

session.save(b);
System.out.println(session.save(b));
/*HBook143 b1=new HBook143();
b1.setBookId(107);
b1.setBookName("book1");
b1.setDate(p);
session.persist(b1);*/
t.commit();





//======================================TO DELETE ALL================================

/*session.delete(b);



//======================================TO DELETE SPECIFIC=============================
String hql = "delete from HBook143  where bookId=103";
session.createQuery(hql).executeUpdate(); 

HBook143 H1=(HBook143) session.get(HBook143.class, 105);
   if(H1!=null){
session.delete(H1);
}
//===================================To SHOW BY ID======================

HBook143 H1=(HBook143) session.get(HBook143.class, 104);
System.out.println(H1.getBookId());
System.out.println(H1.getBookName());



//==================================to show all==============================
List l=  session.createQuery("FROM HBook143").list();
System.out.println(l);

//================================to update all data============================
HBook143 H1=(HBook143) session.get(HBook143.class, 105);
   if(H1!=null){
   HBook143 h2=new HBook143();
   h2.setBookId(107);
h2.setBookName("book1");
h2.setDate(p);
session.update(h2);

//=================================to update particular column=================
HBook143 H1=(HBook143) session.get(HBook143.class, 105);
   if(H1!=null){
   H1.update(bookName,"alchemist"); 

//========================================saveORupdate========================
 saveOrUpdate(Object object)
saveOrUpdate(String entityName, Object object) 

HBook143 H1=(HBook143) session.get(HBook143.class, 105);
if(H1!=null){
HBook143 h2=new HBook143();
h2.setBookId(107);
h2.setBookName("book1");
h2.setDate(p);
session.saveOrUpdate(h2);


*/

//t.commit();
session.close();

		
	}
}
