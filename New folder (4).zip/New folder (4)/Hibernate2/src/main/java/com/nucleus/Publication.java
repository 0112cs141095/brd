package com.nucleus;




public class Publication {

	private int d;
	private int month;
	private int year;
	
	public int getDate() {
		return d;
	}
	public void setDate(int date) {
		this.d = date;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
}
