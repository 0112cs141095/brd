package one_to_one;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CustomerMain {

	public static void main(String[] args) {

		Configuration cfg=new Configuration ();
	cfg.configure();
SessionFactory s =cfg.buildSessionFactory();
Session session=s.openSession();
Transaction t=session.beginTransaction();


Address a=new Address ();
a.setCity("bhopal");
a.setState("mp");

Customer c=new Customer();
c.setId(1);
c.setName("ram");
c.setAddress(a);


/*=============if we write in this order more commands will be executed==========
session.persist(c);
session.persist(a);
===================================================================================*/
session.persist(a);
session.persist(c);
t.commit();
	}

}
