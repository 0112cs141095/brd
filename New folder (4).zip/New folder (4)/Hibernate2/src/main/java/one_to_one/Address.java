package one_to_one;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="a143")
public class Address {

	@Id
	private int aid;

	private String city;
	private String state;
	
	
	public int getId() {
		return aid;
	}
	public void setId(int id) {
		this.aid = id;
	}
	
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
