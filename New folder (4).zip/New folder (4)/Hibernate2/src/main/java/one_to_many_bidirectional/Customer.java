package one_to_many_bidirectional;


import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;




@Entity
@Table(name="cccc")
public class Customer  {

	@Id
	private int cid;
	private 	String name;
	
	
	@OneToMany (mappedBy="c")
//	@JoinTable(name="cus_loan")
    private List<Loan> loan;
	
	
	
	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", name=" + name + ", loan=" + loan
				+ "]";
	}
	public List<Loan> getLoan() {
		return loan;
	}
	public void setLoan(List<Loan> loan) {
		this.loan = loan;
	}
	public int getId() {
		return cid;
	}
	public void setId(int id) {
		this.cid = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

	
}
