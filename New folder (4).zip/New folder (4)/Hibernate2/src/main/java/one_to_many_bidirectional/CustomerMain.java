package one_to_many_bidirectional;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CustomerMain {

	public static void main(String[] args) {

		Configuration cfg=new Configuration ();
	cfg.configure();
SessionFactory s =cfg.buildSessionFactory();
Session session=s.openSession();
Transaction t=session.beginTransaction();


Loan l=new Loan();
l.setId(1);
l.setAmount("100");

Loan l2=new Loan();
l2.setId(2);
l2.setAmount("200");



List<Loan>list=new ArrayList<>();
list.add(l);
list.add(l2);

Customer c=new Customer();
c.setId(1);
c.setName("rohit");
c.setLoan(list);
l2.setCustomer(c);
l.setCustomer(c);

/*=============if we write in this order more commands will be executed==========
session.persist(c);
session.persist(a);
===================================================================================*/
session.persist(l);
session.persist(l2);
session.persist(c);

Customer cus=(Customer)session.get(Customer.class,1);
System.out.println(cus.getId()+" "+cus.getName()+" "+cus.getLoan());

// able to call getCustomer() from loan object
Loan loan=(Loan)session.get(Loan.class,1);
System.out.println(loan.getId()+" "+loan.getAmount()+" "+loan.getCustomer());

t.commit();
	}

}
