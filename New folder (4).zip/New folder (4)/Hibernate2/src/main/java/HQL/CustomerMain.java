package HQL;

import java.util.ArrayList;
import java.util.List;








import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CustomerMain {

	public static void main(String[] args) {

		Configuration cfg=new Configuration ();
	cfg.configure();
SessionFactory s =cfg.buildSessionFactory();
Session session=s.openSession();
Transaction t=session.beginTransaction();



/*Customer c=new Customer();
c.setId(1);
c.setName("rohit");
c.setSalary(100f);

Customer c1=new Customer();
c1.setId(2);
c1.setName("rohan");
c1.setSalary(200f);

session.persist(c);

session.persist(c1);*/

//=========================to view all=========================
/*Query query1=session.createQuery("from Customer");
List<Customer>list=query1.list();
System.out.println(list);*/

//========================to view 1 specific column======================
Query query1=session.createQuery("select salary from Customer");

//***************will show error java.lang.Float cannot be cast to HQL.Customer*******************
/*List<Customer>list=query1.list();
for(Customer c:list)
System.out.println(c);*/
//**********************************************

List<Float>list=query1.list();
for(Float c:list)
System.out.println(c);
//=====================================to view multiple specific column=========================================


/*Query query=session.createQuery("select name,salary from Customer");
List<Object[]> list= query.list();
for(Object[] e:list)
System.out.println(e[0]+" "+e[1]);*/

//==================================to delete particular row======================
Query query=session.createQuery("delete  from Customer where salary=?");
query.setParameter(0,200f);
query.executeUpdate();

//===================================to update particular row=============================
/*Query query=session.createQuery("update Customer set salary=? where salary=?");
query.setParameter(0,200f);
query.setParameter(1,500f);
query.executeUpdate();*/
//**********************************************OR**********************
/*Query query=session.createQuery("update Customer set salary=:amt where salary=:amt1");
query.setParameter("amt",200f);
query.setParameter("amt1",500f);
query.executeUpdate();
*/


//================================to view particular records===================================
/*Query query=session.createQuery("FROM Customer");
query.setFirstResult(0);
query.setMaxResults(1);
System.out.println(query.list());*/

t.commit();
	}

}
