/**
 * 
 */
/**
 * @author temp
 *
 */
package embedablelist;