package embedablelist;

import javax.persistence.Embeddable;


public class Address {

	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private int Streetno;
	private String city;
	private String state;
	public int getStreetno() {
		return Streetno;
	}
	public void setStreetno(int streetno) {
		Streetno = streetno;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
