package HCQL;

import java.util.ArrayList;
import java.util.List;









import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class CustomerMain {

	public static void main(String[] args) {

		Configuration cfg=new Configuration ();
	cfg.configure();
SessionFactory s =cfg.buildSessionFactory();
Session session=s.openSession();
Transaction t=session.beginTransaction();



/*Customer c=new Customer();
c.setId(1);
c.setName("rohit");
c.setSalary(100f);

Customer c1=new Customer();
c1.setId(2);
c1.setName("rohan");
c1.setSalary(200f);

session.persist(c);

session.persist(c1);*/

//=========================to view all=========================
/*Criteria c=session.createCriteria(Customer.class);
System.out.println(c.list());*/

//============================to view specific=====================
/*Criteria c=session.createCriteria(Customer.class);
 c.add(Restrictions.eq("salary",100f));

System.out.println(c.list());
*/

//========================to view 1 specific column======================
Criteria c=session.createCriteria(Customer.class);
c.setProjection(Projections.property("salary"));
System.out.println(c.list());





t.commit();
	}

}
