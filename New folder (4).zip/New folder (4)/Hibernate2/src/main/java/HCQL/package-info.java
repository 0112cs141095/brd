/**
 * 
 */
/**
 * @author temp
 *
 */
package HCQL;