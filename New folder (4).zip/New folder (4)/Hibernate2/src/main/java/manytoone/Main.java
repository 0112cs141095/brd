package manytoone;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
public class Main {

	public static void main(String args[])
	{
		Configuration cfg=new Configuration ();
		cfg.configure();
	SessionFactory s =cfg.buildSessionFactory();
	Session session=s.openSession();
	Transaction t=session.beginTransaction();
		
		
		
		
		
		User u=new User();
		u.setUsername("rohan");
		u.setPassword("dc");
		u.setEnabled(1);
		
		User u1=new User();
		u1.setUsername("rohit");
		u1.setPassword("df");
		u1.setEnabled(1);
		
		
		
		Role r=new Role();
		r.setRoleid(1);
		r.setRole("maker");
    
		
		Role r1=new Role();
		r1.setRoleid(1);
		r1.setRole("checker");
    
	     u.setRole(r);
	     u1.setRole(r);
	     
	     List<User> l=new ArrayList();
			l.add(u);
			l.add(u1);
		
		
		r.setUser(l);	
		
		session.persist(u);
		session.persist(u1);
		
		t.commit();
	}
}
