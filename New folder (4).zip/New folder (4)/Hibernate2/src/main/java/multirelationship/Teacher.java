package multirelationship;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="teacher143")
public class Teacher {

	@Id
	@Column(name="tnumber")
 private int teacherid;
	@Column(name="tname")
 private String teachername;

 
public int getTeacherid() {
	return teacherid;
}
public void setTeacherid(int teacherid) {
	this.teacherid = teacherid;
}
public String getTeachername() {
	return teachername;
}
public void setTeachername(String teachername) {
	this.teachername = teachername;
}


 
 
}
