package multirelationship;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="college143")
public class College {

	@Id
	@Column(name="clgnumber")
	private int clgid;
	@Column(name="clgname")
	private String clgname;
	
	@OneToMany(cascade=CascadeType.ALL)
	private List<Teacher> teacher; 
	
	
	public List<Teacher> getStudent() {
		return teacher;
	}
	public void setStudent(List<Teacher> student) {
		this.teacher = student;
	}
	public int getClgid() {
		return clgid;
	}
	public void setClgid(int clgid) {
		this.clgid = clgid;
	}
	public String getClgname() {
		return clgname;
	}
	public void setClgname(String clgname) {
		this.clgname = clgname;
	}

	
}
