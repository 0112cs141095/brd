package multirelationship;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="universe143")
public class University {

	@Id
	@Column(name="universityid")
	private int uid;
	@Column(name="universityname")
	private String uname;
	
	@OneToMany(cascade=CascadeType.ALL)
	private List<College> clg;

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public List<College> getClg() {
		return clg;
	}

	public void setClg(List<College> clg) {
		this.clg = clg;
	}
	
	
}
