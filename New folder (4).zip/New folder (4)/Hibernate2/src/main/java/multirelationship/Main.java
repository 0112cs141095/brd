package multirelationship;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String args[])
	{
		
	
	Configuration cfg=new Configuration ();
	cfg.configure();
SessionFactory s =cfg.buildSessionFactory();
Session session=s.openSession();
Transaction t=session.beginTransaction();

Teacher s1=new Teacher();
s1.setTeacherid(3);
s1.setTeachername("kartik");

Teacher s2=new Teacher();
s2.setTeacherid(4);
s2.setTeachername("preeti");

List<Teacher> l=new ArrayList<>();
l.add(s1);
l.add(s2);

Teacher s3=new Teacher();
s3.setTeacherid(5);
s3.setTeachername("kartik1");

Teacher s4=new Teacher();
s4.setTeacherid(6);
s4.setTeachername("preeti1");


List<Teacher> l5=new ArrayList<>();
l5.add(s3);
l5.add(s4);


College clg=new College();
clg.setClgid(123);
clg.setClgname("bist");
clg.setStudent(l);

College clg1=new College();
clg1.setClgid(344);
clg1.setClgname("oist");
clg1.setStudent(l5);

List<College> l1=new ArrayList<>();
l1.add(clg);
l1.add(clg1);

University u=new University();
u.setUid(1009);
u.setUname("rgpv");
u.setClg(l1);

session.persist(u);

t.commit();

//if we pass the same list of teacher  then it will become many to many relation and will throw unique key error 
}
}