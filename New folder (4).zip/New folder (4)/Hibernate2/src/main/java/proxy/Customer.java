package proxy;


import java.util.List;



import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;




@Entity
@Table(name="cccc")
public class Customer  {

	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", name=" + name + ", loan=" + loan
				+ "]";
	}
	@Id
	private int cid;
	private 	String name;
	
	
	@OneToMany (cascade=CascadeType.ALL)
	@JoinTable(name="cus_loan")
    private List<Loan> loan;
	
	
	
	public List<Loan> getLoan() {
		return loan;
	}
	public void setLoan(List<Loan> loan) {
		this.loan = loan;
	}
	public int getId() {
		return cid;
	}
	public void setId(int id) {
		this.cid = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

	
}
