package proxy;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CustomerMain {

	public static void main(String[] args) {

		Configuration cfg=new Configuration ();
	cfg.configure();
SessionFactory s =cfg.buildSessionFactory();
Session session=s.openSession();
Transaction t=session.beginTransaction();


/*Loan l=new Loan();
l.setId(1);
l.setAmount("100");

Loan l2=new Loan();
l2.setId(2);
l2.setAmount("200");


List<Loan>list=new ArrayList<>();
list.add(l);
list.add(l2);

Customer c=new Customer();
c.setId(1);
c.setName("rohit");
c.setLoan(list);


session.persist(c);
*/



/******************************************************************

Case1:

Customer cus=(Customer)session.get(Customer.class,1);
System.out.println(cus.getId()+" "+cus.getName());

//two time query is executing ...1>to select customer data  2>to select loan data
//this shows lazy loading

System.out.println(cus.getLoan().get(0).getAmount());

***********************************************************************/


/*********************************************************************

//Case2:

Customer cus=(Customer)session.get(Customer.class,1);
session.close();

Session session1=s.openSession();

//this time we are getting only customer data which is already cached in the object
//this shows cus is cached object 

System.out.println(cus.getId()+" "+cus.getName());
session1.close();
***********************************************************************/

/**************************************************************************
//Case3
Customer cus=(Customer)session.get(Customer.class,1);
System.out.println(cus.getId()+" "+cus.getName());

session.close();

Session session1=s.openSession();
System.out.println(cus.getId()+" "+cus.getName());
//in this loan line will give exception becoz proxy object scope is only upto session
System.out.println(cus.getLoan().get(0).getAmount());

session1.close();
**************************************************************************/




 

t.commit();
	}

}
