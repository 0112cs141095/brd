package proxy;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="a143")
public class Loan {

	@Id
	private int lid;

	private String amount;
	
	
	public int getId() {
		return lid;
	}
	public void setId(int id) {
		this.lid = id;
	}
	public String getAmount() {
		return amount;
	}
	@Override
	public String toString() {
		return "Loan [lid=" + lid + ", amount=" + amount + "]";
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	
	
	
	
}
