package hql_manytomany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Book {

	@Id
	public int bookid;
	public String bookname;
	public float price;
	
	@ManyToMany(cascade=CascadeType.ALL,mappedBy="book")
	
	private List<Category> list;

	@Override
	public String toString() {
		return "Book [bookid=" + bookid + ", bookname=" + bookname + ", price="
				+ price + ", list=" + list + "]";
	}

	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public List<Category> getList() {
		return list;
	}

	public void setList(List<Category> list) {
		this.list = list;
	}
}
