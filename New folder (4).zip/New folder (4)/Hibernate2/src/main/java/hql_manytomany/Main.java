package hql_manytomany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



public class Main {

	public static void main(String args[])
	{
		Configuration cfg=new Configuration ();
		cfg.configure();
	SessionFactory s =cfg.buildSessionFactory();
	Session session=s.openSession();
	Transaction t=session.beginTransaction();
	
	
	
	Category c=new Category();
		c.setCatid(1);
		c.setCatname("fiction");
		
		Category c1=new Category();
		c1.setCatid(2);
		c1.setCatname("horror");
		
		Category c2=new Category();
		c2.setCatid(3);
		c2.setCatname("THRILLER");
		
		Category c3=new Category();
		c3.setCatid(4);
		c3.setCatname("SUSPENSE");
		
		
		List<Category> lc= new ArrayList<>();
		
		lc.add(c);
		lc.add(c1);
		
List<Category> lc1= new ArrayList<>();
		
		lc1.add(c2);
		lc1.add(c3);
		
		
		Book book=new Book();
		book.setBookid(111);
		book.setBookname("alchemist");
		book.setPrice(100f);
	    book.setList(lc);
	    
	    Book book1=new Book();
		book1.setBookid(222);
		book1.setBookname("wonder");
		book1.setPrice(200f);
	    book1.setList(lc1);
	    
	    
	    List<Book> booklist=new ArrayList<>();
	    booklist.add(book);
	    booklist.add(book1);
	    
	    
	    c.setBook(booklist);
	    c1.setBook(booklist);
	    c2.setBook(booklist);
          c3.setBook(booklist);	    
	    
          session.persist(book);
          session.persist(book1);
	
	Query query=session.createQuery("from Book");
        //  System.out.println(query.list());
      /*   List<Object[]>list= query.list();
         for(Object[] b:list)
          System.out.println(b[0]+" "+b[1]+" "+b[2]+" "+b[3]);
          t.commit();
          */
	
	/*   List<Book>list= query.list();
    for(Book b:list)
    {  System.out.println(b.getBookid()+" "+b.getBookname()+" "+b.getPrice());
         List<Category>list1=b.getList();
         for(Category cat:list1)
         {
        	 System.out.println(cat.getCatid()+" "+cat.getCatname()+" "+cat.getBook());
         }
    }  */
	
	
     t.commit();
     
	    
	    
	}
}
