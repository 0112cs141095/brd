/**
 * 
 */
/**
 * @author temp
 *
 */
package sequenceannotation;