package many_to_many;



import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Courses {

	@Id
	private int cid;
	private String cname;
	
	private Student s;
	public Student getS() {
		return s;
	}
	public void setS(Student s) {
		this.s = s;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	@Override
	public String toString() {
		return "Courses [cid=" + cid + ", cname=" + cname + "]";
	}
	
}
