package many_to_many;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Student {

	@Id
	private int sid;
	private String sname;
	
	@ManyToMany(cascade=CascadeType.ALL)
	private List<Courses> courses;

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public List<Courses> getCourses() {
		return courses;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", courses="
				+ courses + "]";
	}

	public void setCourses(List<Courses> courses) {
		this.courses = courses;
	}
	
	
}
