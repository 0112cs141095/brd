package many_to_many;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {

		Configuration cfg=new Configuration ();
	cfg.configure();
SessionFactory s =cfg.buildSessionFactory();
Session session=s.openSession();
Transaction t=session.beginTransaction();
	
		Courses c1=new Courses();
		c1.setCid(101);
		c1.setCname("maths");
		
		Courses c2=new Courses();
		c2.setCid(102);
		c2.setCname("chemistry");
	
		List<Courses> l=new ArrayList<>();
		l.add(c1);
		l.add(c2);
		
		Student s1=new Student();
		s1.setSid(1);
		s1.setSname("shubh");
		s1.setCourses(l);
		
	/*session.persist(c1);
	session.persist(c2);
		*/
		
session.persist(s1); 
t.commit();
	}

}
