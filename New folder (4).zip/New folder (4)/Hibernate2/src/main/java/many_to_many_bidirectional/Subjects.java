package many_to_many_bidirectional;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Subjects {

	@Id
	private int cid;
	private String cname;
	
	
	@ManyToMany
	private List<Student1> s;
	
	public List<Student1> getS() {
		return s;
	}
	public void setS(List<Student1> s) {
		this.s = s;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	@Override
	public String toString() {
		return "Courses [cid=" + cid + ", cname=" + cname + "]";
	}
	
}
