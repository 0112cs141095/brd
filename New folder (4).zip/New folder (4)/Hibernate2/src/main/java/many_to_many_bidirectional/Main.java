package many_to_many_bidirectional;

import java.util.ArrayList;
import java.util.List;

import many_to_many.Student;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {

		Configuration cfg=new Configuration ();
	cfg.configure();
SessionFactory s =cfg.buildSessionFactory();
Session session=s.openSession();
Transaction t=session.beginTransaction();
	
		Subjects c1=new Subjects();
		c1.setCid(101);
		c1.setCname("maths");
		
		Subjects c2=new Subjects();
		c2.setCid(102);
		c2.setCname("chemistry");
	
		List<Subjects> l=new ArrayList<>();
		l.add(c1);
		l.add(c2);
		
		Student1 s1=new Student1();
		s1.setSid(1);
		s1.setSname("shubh");
	
		
		Student1 s2=new Student1();
		s2.setSid(2);
		s2.setSname("shubhi");
		
		
		s1.setCourses(l);
		s2.setCourses(l);
		
		List<Student1> list=new ArrayList<>();
		list.add(s1);
		list.add(s2);
		
		
		
		
		
		c1.setS(list);
		c2.setS(list);
		
		
		
	/*session.persist(c1);
	session.persist(c2);
		*/
		session.persist(s2);		
session.persist(s1); 

t.commit();
	}

}
