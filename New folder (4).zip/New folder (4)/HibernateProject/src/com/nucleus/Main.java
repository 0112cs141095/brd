package com.nucleus;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String args[])
	{
		Configuration cfg=new Configuration ();
	cfg.configure();
SessionFactory s =cfg.buildSessionFactory();
Session session=s.openSession();
Transaction t=session.beginTransaction();
HBook143 b=new HBook143();
b.setBookId(101);
b.setBookName("book1");
session.persist(b);

t.commit();

session.close();

		
	}
}
