package com.nucleus.bookDAO;

import java.util.List;

import Class.Book;

public interface BookDAO {
	public String getValue(String str[]);
	public void savebook(Book book);
	public void delete(String s);
	public List display();
	public Book getBookById(String id);
	public void update(Book book);
}
