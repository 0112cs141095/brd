package com.nucleus.connection;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.FileReader;
import java .util.Properties;
import java .io.FileNotFoundException;
import java .io.IOException;

public class ConnectionSetup 
{
	Connection con=null;
	public  Connection getConnection() 
	{
	FileReader file = null;
		
		
			Properties p=new Properties();
			
			try {
				file = new FileReader("D:\\BrdNew\\src\\com\\nucleus\\connection\\Connection.properties");
			} catch (FileNotFoundException e) {
				
				e.printStackTrace();
			}
			
			try {
				p.load(file);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String url=p.getProperty("url");
			String username=p.getProperty("username");
			String password=p.getProperty("password");

			
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		try {
			con=DriverManager.getConnection(url,username,password);
			return con;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	} catch (ClassNotFoundException e) {
		
		e.printStackTrace();
	}
	try {
		con=DriverManager.getConnection(url,username,password);
	} catch (SQLException e) {
	
		e.printStackTrace();
	}
	return con;
	
	
	}}
	
	/*public  Connection getConnection()
	{
		
		try {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	con=DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
		
	}
		catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
	catch (SQLException e) {
			
			e.printStackTrace();
		}
		return con;
	
	}

	public void closeConnection()
	{
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	}
	
	

}
*/