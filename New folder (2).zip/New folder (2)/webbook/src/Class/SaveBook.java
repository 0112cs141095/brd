package Class;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nucleus.bookDAO.BookDAO;
import com.nucleus.connection.ConnectionSetup;

public class SaveBook implements BookDAO {
	
  
	ConnectionSetup connectionSetup=new ConnectionSetup();
	 Connection con1=connectionSetup.getConnection();
	
	
	public String getValue(String str[])
	
	{  String str1="";
	for(int i=0;i<str.length;i++)  
	{ str1+=str[i]+",";
		}
    return 	str1;
    }
		
	public void savebook(Book book)
	{
		try {		
		
   PreparedStatement  pstmt1=con1.prepareStatement("insert into bookservlet143 values (?, ? ,?,?,?)");
      pstmt1.setString (1,book.getName() );
      pstmt1.setString (2,book.getIsbn());
      pstmt1.setString(3,book.getDescription() );
      pstmt1.setString(4, book.getCategory());
    		  pstmt1.setString(5,book.getPublisher() );
    			System.out.println("record inserted");
    						  
        pstmt1.executeUpdate();
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	
}

public void delete(String s)
{
	try
	{
	 PreparedStatement stmt=con1.prepareStatement("delete from bookservlet143 where ISBN=?");  
     stmt.setString(1,s);  
      stmt.executeUpdate(); 
      System.out.println("deleted");}
catch (SQLException e) {
		
		e.printStackTrace();
	}
}

public List display()
{
	try

{ 
List<Book> listBook1 = new ArrayList<>();
	 PreparedStatement stmt2=con1.prepareStatement("select * from bookservlet143");  
	 
	   ResultSet r1=stmt2.executeQuery();
       while(r1.next())
  {   System.out.println("memememme");
  Book book = new Book();
    	   book.setName(r1.getString(1));
  book. setIsbn(r1.getString(2));
  book.setDescription(r1.getString(3));
  book. setCategory(r1.getString(4));
  book.setPublisher(r1.getString(5));
  listBook1.add(book);
  }
 
  return listBook1;

}
catch (SQLException e) {
		
		e.printStackTrace();
	}
	return null;
}
public void update(Book book)
{
	try{
	
      String sql = "UPDATE bookservlet143  SET NAME = ?, DESCRIPTION= ? ,CATEGORY=?,PUBLICATION=?";
      sql += " WHERE ISBN= ?";
      PreparedStatement stmt2=con1.prepareStatement(sql); 
       
      stmt2.setString (1,book.getName() );
      stmt2.setString (2, book.getDescription());
      stmt2.setString(3,book.getCategory());
      stmt2.setString(4, book.getPublisher() );
    		  stmt2.setString(5,book.getIsbn() );
    		  stmt2.executeUpdate();
    			System.out.println("record updated");

}catch (SQLException e) {
	
	e.printStackTrace();
}
}

public Book getBookById(String id)
{ List<Book> listBook1 = new ArrayList<>();
Book book = new Book();
	
try
{
	PreparedStatement stmt3=con1.prepareStatement("select * from bookservlet143 where ISBN=?");  

	  stmt3.setString (1,id);
	   ResultSet r1=stmt3.executeQuery();
	   while(r1.next())
	   { 
		   book.setName(r1.getString(1));
		   book. setIsbn(r1.getString(2));
		   book.setDescription(r1.getString(3));
		   book. setCategory(r1.getString(4));
		   book.setPublisher(r1.getString(5));
		   return book;   }}
	   catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}
}

