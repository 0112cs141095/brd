package bookservelet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.bookDAO.BookDAO;

import Class.Book;
import Class.SaveBook;

/**
 * Servlet implementation class Servlet3
 */
@WebServlet("/Servlet3")
public class Servlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ch;
		String ch1;
		String ch2;
		String c1;
		String c2;
		String c3;
		Book book=(Book) request.getAttribute("obj");
		System.out.println(book);
		if(book.getCategory().contains("fiction"))
		{
			ch="checked='checked'";
		}
		else
			ch="";
		
		if(book.getCategory().contains("horror"))
		{
			ch1="checked='checked'";
		}
		else
			ch1="";
		
		
		if(book.getCategory().contains("romance"))
		{ch2="checked='checked'";
			
		}
		else
			ch2="";
		
		if(book.getPublisher().contains("rk"))
		{c1="checked='checked'";
			
		}
		else
			c1="";
		
		if(book.getPublisher().contains("hp"))
		{c2="checked='checked'";
		
	}
		else
			c2="";
			
		if(book.getPublisher().contains("sr"))
		
			{c3="checked='checked'";
			
			}
		else
			c3="";
		
		
		String sql="<html><head><STYLE>";
	sql+="table{ border-spacing: 15px;}</style>	</head>"+
         "<body>"
			+"<form action='Servelet1' method='post'>"
	     +"<h1><center>BookStore</center></h1><table>" 
	  +"<tr><td><b>NAME:</b></td>"
	  +    "	<td><input type='text' name='name' value='"+book.getName()+"'></td></tr>"
	  +"<tr><td><b>ISBN:</b></td>"
	 +"<td><input type='text'  name='ISBN' value='"+ book.getIsbn()+"'></td></tr><br></br>"
	  +"<tr><td><b>Description:</b></td>"
	+"<td><input type='text' name='description' value='"+book.getDescription()+"'</td><br></br>"
	+	"<tr><td><b>Category:</b><br></br></td></tr>"
	+	"<tr><td><input type='radio'  name='category'  value='fiction'"+ch+" >Fiction"
	+"<input type='radio'  name=category value='horror'"+ch1+">Horror"
   +			"<tr><td><input type='radio' name='category' value='romance'"+ch2+" >Romance<br></br><td></td></tr>"
   
	+"<tr><td><b>Publication:</b><br></br></td></tr>"
	+"<tr><td><input type='checkbox'  name='publication' value='hp'"+c2+" >Hp"
	+"<input type='checkbox'  name=publication value='rk'"+c1+"  >Rk"
	+"<input type='checkbox' name=publication value='sr'"+c3+">SR<br></br>"
	+"<input type='submit'   name='usubmit' value= 'add'></td></tr></table>"
	+"</form></body></html>";
	

	 if(request.getParameter("usubmit")!=null)
	         
      {	  BookDAO sb=new SaveBook();
		  String str[]=request.getParameterValues("publication");
			
		      book.setName(request.getParameter("name"));
		      book. setIsbn(request.getParameter("ISBN"));
		      book.setDescription(request.getParameter("description"));
		      book. setCategory(request.getParameter("category"));
		      book.setPublisher(sb.getValue(str));
			
		     sb.update(book);
		}
	 PrintWriter out=response.getWriter();
	out.println(sql);
	
	
		
		
	
		
	
		

		
	
		
		
	}

}
