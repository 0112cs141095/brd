package bookservelet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Class.Book;
import Class.SaveBook;

/**
 * Servlet implementation class Servlet2
 */
@WebServlet("/Servlet2")
public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Book book=new Book();
         SaveBook sb=new SaveBook();
         PrintWriter out=response.getWriter();
		
         
         if(request.getParameter("submit")!=null)
		{   
		
			
		
		      book.setName(request.getParameter("name"));
		      book. setIsbn(request.getParameter("ISBN"));
		      book.setDescription(request.getParameter("description"));
		      book. setCategory(request.getParameter("category"));
		      String str[]=request.getParameterValues("publication");
		      book.setPublisher(sb.getValue(str));
		      
		      System.out.println(book);
			
		      sb.savebook(book);
		}
     
         if(request.getParameter("dsubmit")!=null)
		{
			System.out.println("dddddddd");
		sb.delete(request.getParameter("delete"));
			
		}
         if(request.getParameter("uid")!=null)
 		{
 			System.out.println("uuuuuuu");
 			 Book book1=sb.getBookById(request.getParameter("ISBN"));
 			 request.setAttribute("obj",book1);
 			request.getRequestDispatcher("Servlet3").forward(request, response);}
 			
         if(request.getParameter("usubmit")!=null)
         
         {	 String str[]=request.getParameterValues("publication");
 			
		      book.setName(request.getParameter("name"));
		      book. setIsbn(request.getParameter("ISBN"));
		      book.setDescription(request.getParameter("description"));
		      book. setCategory(request.getParameter("category"));
		      book.setPublisher(sb.getValue(str));
			
		     // sb.update(book);
 		}
	}

}
