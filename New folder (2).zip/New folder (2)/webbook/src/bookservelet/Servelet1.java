package bookservelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;







import com.nucleus.bookDAO.BookDAO;

import Class.Book;
import Class.SaveBook;


@WebServlet("/Servelet1")
public class Servelet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Servelet1() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  Book book=new Book();
	         BookDAO sb=new SaveBook();
	         PrintWriter out=response.getWriter();
		
		System.out.println("******");
		if(request.getParameter("new")!=null)
		{	System.out.println("***jghj***");
			request.getRequestDispatcher("NewBook.html").forward(request, response);
			System.out.println("******");
		}
		
		
		if(request.getParameter("delete")!=null)
		{	System.out.println("******");
		
		request.getRequestDispatcher("Delete.html").forward(request, response);}
		
	
		
		if(request.getParameter("display")!=null)
		{  System.out.println("ddddyyyy");
		List<Book> list= sb.display();
		for(Book books:list)
		  out.println(books+"\n");  
		   
		}
		
		
		
		if(request.getParameter("update")!=null)
		{
			request.getRequestDispatcher("getUid.html").forward(request, response);
			
		}
	
		
		
         
         if(request.getParameter("submit")!=null)
		{   
		
			
		
		      book.setName(request.getParameter("name"));
		      book. setIsbn(request.getParameter("ISBN"));
		      book.setDescription(request.getParameter("description"));
		      book. setCategory(request.getParameter("category"));
		      String str[]=request.getParameterValues("publication");
		      book.setPublisher(sb.getValue(str));
		      
		      System.out.println(book);
			
		      sb.savebook(book);
		}
     
         if(request.getParameter("dsubmit")!=null)
		{
			System.out.println("dddddddd");
		sb.delete(request.getParameter("delete"));
			
		}
         if(request.getParameter("uid")!=null)
 		{
 			System.out.println("uuuuuuu");
 			 Book book1=sb.getBookById(request.getParameter("ISBN"));
 			System.out.println("uuuuuuu");
 			 request.setAttribute("obj",book1);
 			System.out.println("uuuuuuu");
 			request.getRequestDispatcher("Servlet3").forward(request, response);
 			}
 			
         if(request.getParameter("usubmit")!=null)
         
         {	Book book1=new Book();
        	 String str[]=request.getParameterValues("publication");
 			System.out.println("vbgb");
		      book1.setName(request.getParameter("name"));
		      book1. setIsbn(request.getParameter("ISBN"));
		      book1.setDescription(request.getParameter("description"));
		      book1. setCategory(request.getParameter("category"));
		      book1.setPublisher(sb.getValue(str));
		      System.out.println(book1);
			
		     sb.update(book1);
 		}
	}

	
	}
