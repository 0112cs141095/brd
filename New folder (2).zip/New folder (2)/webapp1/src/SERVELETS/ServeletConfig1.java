package SERVELETS;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServeletConfig1
 */
//@WebServlet("/ServeletConfig1")
public class ServeletConfig1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ServeletConfig1() {
        super();
       
    }

    String email;
 	String contactnumber;
 	String []str;
 	String contactperson;
  public void init()
  {
  	ServletConfig servletConfig=getServletConfig();
  	email=servletConfig.getInitParameter("email");
  
    str=email.split(",");
  	
  	contactnumber=servletConfig.getInitParameter("contactnumber");
  	
  	ServletContext servletContext=getServletContext();
  	contactperson=servletContext.getInitParameter("contactperson");
  }
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.println("Email: "+email);
		out.println("<br></br>");
		out.println(contactperson);
		out.println("<br></br>");
		for(int i=0;i<str.length;i++)
		{
			out.println(str[i]);
			out.println("<br></br>");
		}
		out.println("Contact Number: "+contactnumber);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

}
