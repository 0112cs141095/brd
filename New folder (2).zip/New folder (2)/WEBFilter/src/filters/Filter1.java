package filters;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;


//@WebFilter("/Filter1")
public class Filter1 implements Filter {

    /**
     * Default constructor. 
     */
    public Filter1() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		System.out.println("filter");
	//	PrintWriter out=response.getWriter();
    	String str=request.getParameter("name");
    	String h="fnlkbc";
    	 String str1="";
	 
	   if(request.getParameter("name")!=null)
	   {
		  
		   if(str.contains("@")||str.contains("?"))
		   { System.out.println("iffilter");
			   
			   int index1=str.indexOf("@");
			  
			   for(int i=0;i<str.length();)
				  
			   {    System.out.println("forfilter");
				   if(i==index1)
		            {
			               i++;
			               System.out.println(i);
			  
					}
		           else
		           {         
		        	  
			           str1+=str.charAt(i);
			           System.out.println(str1);
			          request.setAttribute("name", str1);
			           System.out.println(str1);
			           i++;
		           }
				  
			   } 
			 
			   chain.doFilter(request, response);
			   
		   }
		   else
		   { request.setAttribute("name", str);
			   chain.doFilter(request, response);}
		   }
		  
    } 
		
	


	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
