/**
 * 
 */
/**
 * @author temp
 *
 */
package com.nucleus.model;