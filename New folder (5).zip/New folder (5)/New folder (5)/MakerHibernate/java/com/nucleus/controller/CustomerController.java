package com.nucleus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import com.nucleus.service.CustomerService;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.nucleus.model.Customer;



@Controller
public class CustomerController {

	@Autowired
	CustomerService customerservice;
	
	@RequestMapping("/new")
	public String  newcustomer(Customer customer)
	{
		
		
		return "Customer1";
		
		
	}
	
	
	@RequestMapping("/customersubmit")
	public String  handler2(@Valid Customer customer,BindingResult result)
	{
		if(result.hasErrors())
			{System.out.println( "***********");
			return "Customer1";}
		
		else
		{ Date date=new Date();
			String d=new SimpleDateFormat("dd-MMM-yyyy").format(date);
			System.out.println(d);
			customer.setDate(d);
			
		String yes= customerservice.insert(customer);
		if(yes.equals("saved"))
		return "completed";
		
		else
			return "error";}
	}
	
	@RequestMapping("/delete")
	public String  deletecustomer(Customer customer)
	{
		
		
		return "Delete";
		
		
	}
	
	@RequestMapping("/deletesubmit")
	public String  delete( Customer customer,BindingResult result)
	{
		
		
		if(result.hasErrors())
			return "Delete";
		
		else
		{
		String yes= customerservice.delete(customer);
		
		
		
		
		if(yes.equals("deleted"))
			return "completed";
			
			else
				return "error";}
		}
	
	@RequestMapping("/viewbyid")
	public String  viewbyid(Customer customer)
	{
		
		
		return "ViewById";
		
		
	}
	
	
	@RequestMapping("/viewsubmit")
	public  ModelAndView viewid(  Customer customer,BindingResult result)
	{
		
		if(result.hasErrors())
			return  new  ModelAndView ("ViewById");
		
		else
		{
			
		
		Customer c1= customerservice.show1(customer);
		if(c1.getCustomerCode()==null)
		{
			return new ModelAndView("error");
		}
		
		
		
			
			
			else
					{List<Customer>l=new ArrayList();
					l.add(c1);
				return new ModelAndView("viewall","list",l);}
		}}
	
	@RequestMapping("/viewall")
	public   ModelAndView viewall(Customer customer)
	{
		
		List<Customer>l= customerservice.show();
		if(l!=null)
		{
			return new ModelAndView( "viewall","list",l);
		}
		else
			return new ModelAndView("error");
	}	
		
		@RequestMapping("/update")
		public String  updateid(Customer customer)
		{
			
			
			return "updateId";
			
			
		}
		
		@RequestMapping("/updatesubmit")
		public   ModelAndView update(@Valid  Customer customer,BindingResult result)
		{
			System.out.println(customer.getCustomerCode());
			System.out.println(result);
			System.out.println("DGDFGFGD");
			
			if(result.hasErrors())
			{	System.out.println("DGDFGFGD");
				return  new  ModelAndView ("updateId");}
			
			else
				{
				Customer c1= customerservice.show1(customer);
				System.out.println(c1);
				
			if(c1.getCustomerCode()==null)
			{
				return new ModelAndView("error");
			}
			
			
			
				
				
				else
						{
				
					return new ModelAndView("update","c",c1);
					}
			}
		
		
}
		
		@RequestMapping("/updatesubmit2")
public String  edit(Customer customer)
{
			
			
			
			System.out.println("vhesdvcvsvcsvcsdvd");
			System.out.println(customer.getDate());
			
			Date date=new Date();
			String d=new SimpleDateFormat("dd-MMM-yyyy").format(date);
			System.out.println(d);
			customer.setModifiedDate((d));
			
			
			
			
String str= customerservice.update(customer);
	
if(str.equals("null"))
	return "error";
else
	return "completed";
	
}
		@RequestMapping("/adduser")
		public String adduser()
		{
			return "adduser";
		}
		@RequestMapping("/addadmin")
		public String addadmin()
		{
			return "addadmin";
		}	
}
