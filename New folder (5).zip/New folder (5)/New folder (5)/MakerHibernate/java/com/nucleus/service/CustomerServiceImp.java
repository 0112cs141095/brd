package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nucleus.dao.CustomerDao;
import com.nucleus.model.Customer;


@Service
public class CustomerServiceImp implements CustomerService{

@Autowired
	CustomerDao customerdao;
	
	public String insert(Customer c) {
		
		String str=customerdao.insert( c);
		return str;
	}

	@Override
	public String delete(Customer c) {
	
		String str=customerdao. delete( c);
		return str;
	}

	@Override
	public Customer show1(Customer c) {
		
		Customer customer=customerdao.show1( c);
		return customer;
	}

	@Override
	public List<Customer> show() {
		
		List<Customer> list	=customerdao.show();
		return list;
	}

	@Override
	public String update(Customer c) {
		String str=	customerdao.update( c);
		return str;
	}
	
	
	

}
