package com.nucleus.dao;








import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;





import com.nucleus.model.Customer;


@Repository
public class CustomerDaoImp implements CustomerDao{
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public String insert(Customer c)
	{
		try{
	
Object[]cus={c.getCustomerCode(),c.getCustomerName(),c.getCustomerAddress1(),c.getCustomerAddress2(),c.getPin(),c.getMailId(),c.getContactNumber(),c.getContactPerson(),c.getDate(),c.getModifiedDate(),c.getCreatedBy(),c.getModifiedBy()};
	jdbcTemplate.update("insert into cspring143 values(c143.nextval,?,?,?,?,?,?,?,?,?,?,?,?)",cus);
		
			
			return "saved";
			
		         
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return "null";
				
			}
	}
	
	
	
	
	
	
	 public String delete(Customer c)
	 {
		 try{
			 
			     
			 
			 Object[]cus={c.getCustomerCode()}; 
				  jdbcTemplate.update("delete from cspring143 where CODE=?",cus);
		         
		        
		         return "deleted";
		      }
			 
		   	
		  catch(Exception e)
			    {
				return "null";
				
			       }
			
		
	}
	 
	 
			
	 public Customer  show1(Customer  c)
		{ System.out.println("*********");
		System.out.println(c.getCustomerCode());
		 Object[]cus={c.getCustomerCode()}; 
		 
		 try{
		 Customer u= (Customer) jdbcTemplate.queryForObject("select * from cspring143 where CODE=?",cus, new CustomerDetails());
		System.out.println(u);
			return u;}
		 catch(Exception e)
		 {
			 e.printStackTrace();
			 Customer c1=new Customer();
			 return  c1;
		 }
		}
	 
	 
	 public List<Customer> show()
	 {
		 List<Customer> u=new ArrayList();
		 try{
			 u= (List<Customer>) jdbcTemplate.query("select * from cspring143 ", new CustomerDetails());
			
				return u;}
			 catch(Exception e)
			 {
				 e.printStackTrace();
				
				 return  u;
			 }
	 }
	 
public String update(Customer c)
{
	 try{
		 
		 System.out.println(c);
		 System.out.println(c.getCustomerId());
		 System.out.println(c.getCustomerCode());
		 System.out.println(c.getDate());
		 Object[]cus={c.getCustomerId(),c.getCustomerName(),c.getCustomerAddress1(),c.getCustomerAddress2(),c.getPin(),c.getMailId(),c.getContactNumber(),c.getContactPerson(),c.getDate(),c.getModifiedDate(),c.getModifiedBy(),c.getCustomerCode()};
	 
	 jdbcTemplate.update("update cspring143 set ID=?,NAME=?,ADDRESS1=?,ADRESS2=?,PIN=?,EMAIL=?,CONTACTNUMBER=?,CONTACTPERSON=?,CREATEDDATE=?,MODIFIEDDATE=? ,MODIFIEDBY=? where CODE=?", cus);
return "updated";}
	 catch(Exception e)
{
	
	e.printStackTrace();
	 return  "null";
}
	 
		
	 
	
}
}

