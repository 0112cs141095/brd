package com.nucleus.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nucleus.model.Customer;

public class CustomerDetails implements RowMapper<Customer>{

	
public Customer mapRow(ResultSet r1, int row) throws SQLException  {
		
		System.out.println(row);
		Customer c=new Customer();
		
		  c.setCustomerId(r1.getLong(1));
		 c.setCustomerCode(r1.getString(2));
         c.setCustomerName(r1.getString(3));
         c.setCustomerAddress1(r1.getString(4));
         c.setCustomerAddress2(r1.getString(5));
         c.setPin(r1.getString (6));
         c.setMailId(r1.getString(7));
         c.setContactNumber(r1.getString(8));
         c.setContactPerson(r1.getString(9));
         System.out.println(r1.getString(10));
         c.setDate(r1.getString(10));
         c.setModifiedDate(r1.getString(11));
         c.setCreatedBy(r1.getString(12));
         c.setModifiedBy(r1.getString(13));
      
      System.out.println(c);
	
		return c;
	}
}
