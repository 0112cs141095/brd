package com.nucleus.dao;

import java.awt.print.Book;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nucleus.model.User;




public class UserDetails implements RowMapper<User> {
	
	
		
	
	public User mapRow(ResultSet rs, int row) throws SQLException  {
		
		System.out.println(row);
		User user =new User();
		
		
		user.setUsername(rs.getString(1));    
      user.setPassword(rs.getString(2));   
      String role=rs.getString(3);
    System.out.println(role);
      if(role.equals("maker"))
      {
    	  user.setValid(true);
      }
      else
    	  user.setValid(false) ;
      
      System.out.println(user);
	
		return user;
	}
	
	

	
	
	
	
	}	
	
	

	

