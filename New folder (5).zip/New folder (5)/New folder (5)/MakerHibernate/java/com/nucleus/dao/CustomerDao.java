package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Customer;



public interface CustomerDao {
	public String insert(Customer c);
	 public String delete(Customer c);
	
	 
	  public Customer show1(Customer c);
	  public List<Customer> show();
	  public String update(Customer c);
	
}
