package com.nucleus.aop;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.nucleus.dao.CustomerDaoImp;

@Aspect
@Component
public class main {

	
	
		static Logger log = Logger.getLogger(main.class.getName());
		
		
		@Before("execution(* com.nucleus.dao.*.*(..))")
		public void aftertest(JoinPoint j)
	{
			log.info("Method: "+ j.getStaticPart());
			log.info("**********************************");
	}
        
			
		
		

	

}
