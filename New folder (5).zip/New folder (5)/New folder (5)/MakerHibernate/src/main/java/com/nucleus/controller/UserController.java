package com.nucleus.controller;



import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import com.nucleus.model.User;

import com.nucleus.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	UserService userservice;
	
	
	@RequestMapping("/adduser")
	public String adduser(User user)
	{
		return "adduser";
	}
	@RequestMapping("/addadmin")
	public String addadmin()
	{
		return "addadmin";
	}	
	
	@RequestMapping("/addusersubmit")
	public String adduser1(User user,BindingResult result)
	{
		if(result.hasErrors())
		{System.out.println( "***********");
		return "adduser";}
	
	else
	{ 
		
	String yes= userservice.insert(user,2);
	if(yes.equals("saved"))
	return "completed";
	
	else if(yes.equals("null"))
		return "error";}
		return "error";
		
	}
	
	@RequestMapping("/addadminsubmit")
	public String addadmin1(User user,BindingResult result)
	{
		if(result.hasErrors())
		{System.out.println( "***********");
		System.out.println("mfgmfg");
		return "addadmin";}
	
	else
	{ 
		System.out.println("mfgmfg");
	String yes= userservice.insert(user,1);
	if(yes.equals("saved"))
	return "completed";
	
	else
		return "error";}
		
	}

	

	
	
	@RequestMapping("/accdenied")
		public String handler()
		{
			return "accessdenied";
		}
		
		@RequestMapping("/login")
		public String handler1()
		{
			return "Login";
		}
		
		@RequestMapping("/failure")
		public ModelAndView handler3()
		{
			System.out.println("&&&&&&&&&&&&&&&&");
			
			String str="INVALID NAME OR PASSWORD";
			return new  ModelAndView ("Login","error",str);
		}
		
		@RequestMapping("/defaulttarget")
		public String handler6(HttpServletRequest request)
		{
			
			String target;
			
			 if(request.isUserInRole("ROLE_USER"))
			{
				target="redirect:/user";
			}
			else if(request.isUserInRole("ROLE_ADMIN"))
			{
				target="redirect:/admin";
			}
			else
				{System.out.println("&%##^&%$##%%%");
				target="redirect:/accdenied";}
			
			return target;
		}
	
		@RequestMapping("/user")
		public String makerpage()
		{      
			return "Maker";
		}
		
		
		
	
		@RequestMapping("/logout")
		public String logout()
		{
			return "Login";
		
}
		@RequestMapping("/admin")
		public String admin()
		{
			return "Register";
		}
}	
		
	
