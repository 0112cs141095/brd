package com.nucleus.dao;









import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;















import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;






import org.springframework.transaction.annotation.Transactional;

















import com.nucleus.model.Customer;
import com.nucleus.model.User;


@Repository
public class CustomerDaoImp implements CustomerDao{
	
	 static Logger log = Logger.getLogger(CustomerDaoImp.class.getName());
	 long i=0;
	@Autowired
	SessionFactory sf;
	
	@Transactional
	public String insert(Customer c)	{
		
			c.setCustomerId(i+1);
			i++;
		System.out.println(c);
			 Customer ccccc=show1(c);
			
			 System.out.println(ccccc);
			 if(ccccc==null)
	     {
				 System.out.println("ahfkshdkghskl");
			 sf.getCurrentSession().persist(c);
			
					log.info("saved" + c +"\n");
										return "saved";
		     }
		 else
		           {			
			 log.info(" Unique Constraint Exception occured");			  
		      return "null";			 }			
		
		
}
	
	
	
	
	
	@Transactional
	 public String delete(Customer c)
	 {
		
			 
		     Customer result=show1(c);
			     System.out.println(result);
			     if(result==null)
			     {
			    	 log.info(" Invalid id Exception occured");
			    	 return "null";
			     }
			     else
			     {
			    	 sf.getCurrentSession().delete(result);
			    		log.info("deleted"+result +"\n");
			    	  return "deleted";
			     }
			 
			 
		         
		   	}
	
	
	
	
	
	
	
	
	
	
	
	 
	 
	@Transactional		
	 public Customer  show1(Customer  c)
		
	 {
		
		
		 Customer  result= new Customer();
		 
		
			  
				String s= c.getCustomerCode();
				System.out.println(s);
			
					 Criteria criteria=sf.getCurrentSession().createCriteria(Customer.class);
					
						 Criteria criteria1=	 criteria.add(Restrictions.eq("customerCode",s));
						 
						 result	 =(Customer)criteria1.uniqueResult();
						 System.out.println("nsld");
						 System.out.println(result);
						 
						 log.info(" view data  "+ result);
						 return result;
					        
				
	            	
				 }   

		
		     
		     
	
	 
	
	
		
	 
	@Transactional
	 public List<Customer> show(Customer  c)
	 {
		 List<Customer> u=new ArrayList();
		String s= c.getCustomerCode();
		System.out.println(s);
		
			 Criteria criteria=sf.getCurrentSession().createCriteria(Customer.class);
			
				 u=criteria.list();
		   
			
			 
			 System.out.println("u=" + u);
				return u;
				}
			

	@Transactional
	public String update(Customer c)
	{
		
			 
			 System.out.println(c);
			 sf.getCurrentSession().update(c);
			
			 log.info(" update  "+c);
		
	return "updated";}
		
		 
		 

 
		
	 
	





	@Override
	public String insertuser(User user) {
		sf.getCurrentSession().persist(user);
		return "saved";
	}




@Transactional
	@Override
	public Customer both(String s) {
		
		 Customer  result=new Customer();
		 
			
		  
			
			System.out.println(s);
			
			Criteria criteria2=sf.getCurrentSession().createCriteria(Customer.class);
			
			 Criteria criteria3=	 criteria2.add(Restrictions.eq("customerName",s));
			 
			 result	 =(Customer)criteria3.uniqueResult();
		
				
					 
					 if(result==null)
					 {
				
						 Criteria criteria=sf.getCurrentSession().createCriteria(Customer.class);
							
						 Criteria criteria1=	 criteria.add(Restrictions.eq("customerCode",s));
						 
						 result	 =(Customer)criteria1.uniqueResult();
						 
						 
						return result;
					 }
					 else 
						 
					 
					 System.out.println("nsld");
					 System.out.println(result);
					 
					 log.info(" view data  "+result);
					 return result;
				        
	}





@Override
public List<Customer> viewbydate(String[] s)  {
	
	/*for(int i=0;i<s.length;i++)
	{
		System.out.println(s[i]);
		DateFormat formatter = new SimpleDateFormat("dd-MON-YYYY");
		try {
			Date date = (Date)formatter.parse(s[i]);
		
			
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		 
		*/
		
		
	
	
	
	List<Customer> list=new ArrayList();
/*	Query q=sf.getCurrentSession().createQuery("from chibernate143 where date between :from and :to");*/
	Criteria c =sf.getCurrentSession().createCriteria(Customer.class);
	Criteria c1=c.add(Restrictions.between("date", s[0], s[1]));
	list=c1.list();
	
	/*c.setParameter("from",s[0]);
	c.setParameter("to",s[1]);*/
  // list =	q.list();
	
   System.out.println("dkfgdgjj");
   System.out.println(list);
	return list;
}






/*@Transactional
public List<Customer> view(String[] s) {
	
	Customer result=  new Customer();
	List<Customer> list=new ArrayList();

for(int i=0;i<s.length;i++)
{
	
  String s1=s[i];
  Criteria criteria=sf.getCurrentSession().createCriteria(Customer.class);
  Long l=Long.parseLong(s1);
	
	 Criteria criteria1=	 criteria.add(Restrictions.eq("customerId",l));
	 
	 result =(Customer)criteria1.uniqueResult();
	
  list.add(result);
  
  System.out.println(list);
  
  
  
  
}
	return list;
}*/}


