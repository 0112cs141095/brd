package com.nucleus.service;

import com.nucleus.model.Customer;
import com.nucleus.model.User;

public interface UserService {

	public String insert(User user,int i);
}
