package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Customer;
import com.nucleus.model.User;



public interface CustomerDao {
	public String insert(Customer c);
	 public List<Customer> show(Customer  c);
	  public String update(Customer c);
	  public Customer show1(Customer c);
	 public String delete(Customer c);
	public String insertuser(User user);
	 public Customer both(String s);
//	public List <Customer> view(String s[]);
	 public List <Customer> viewbydate(String s[]);
	 
	
}
