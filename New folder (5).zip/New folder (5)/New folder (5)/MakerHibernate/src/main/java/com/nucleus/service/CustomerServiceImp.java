package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nucleus.dao.CustomerDao;
import com.nucleus.model.Customer;


@Service
public class CustomerServiceImp implements CustomerService{

@Autowired
	CustomerDao customerdao;
	
	public String insert(Customer c) {
		
		String str=customerdao.insert( c);
		System.out.println("gdfbfbgbf"+ " "+ str);
		return str;
	}
	@Override
	public List<Customer> show(Customer  c) {
		
		List<Customer> list	=customerdao.show(c);
		return list;
	}
	@Override
	public String update(Customer c) {
		String str=	customerdao.update( c);
		return str;
	}
	@Override
	public Customer show1(Customer c) {
		
		Customer customer=customerdao.show1( c);
		return customer;
	}

	//@Override
public String delete(Customer c) {
	
		String str=customerdao. delete( c);
		return str;
	}
@Override
public Customer both(String s) {
	Customer customer=customerdao.both(s);
	return customer;
}

/*public List<Customer> view(String[] s) {
	List<Customer> list	=customerdao.view(s);
	return list;
}
*/
	
public List<Customer> viewbydate(String[] s) {
List<Customer> list	=customerdao.viewbydate(s);
return list;
}


	

	
	
	
	

}
