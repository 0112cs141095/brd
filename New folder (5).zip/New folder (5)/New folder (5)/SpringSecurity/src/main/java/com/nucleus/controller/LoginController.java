package com.nucleus.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.model.Book;

@Controller
public class LoginController {

	@RequestMapping("/accdenied")
	public String handler()
	{
		return "error";
	}
	
	@RequestMapping("/login")
	public String handler1()
	{
		return "Login";
	}
	
	@RequestMapping("/failure")
	public ModelAndView handler3()
	{
		System.out.println("&&&&&&&&&&&&&&&&");
		
		String str="invalid NAME OR PASSWORD";
		return new  ModelAndView ("Login","error",str);
	}
	
	@RequestMapping("/book")
	public String Book1(Book book)
	{
		return "Book";
	}
}
