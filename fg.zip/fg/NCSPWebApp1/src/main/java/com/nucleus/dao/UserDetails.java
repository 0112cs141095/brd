package com.nucleus.dao;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;

import com.nucleus.model.Book;


public class UserDetails implements RowMapper<Book> {

	
	public Book mapRow(ResultSet rs, int row) throws SQLException {
		Book book=new Book();
		
		book.setName(rs.getString(1));
		book.setIsbn(rs.getString(2));
		book.setDescription(rs.getString(3));
		book.setCategory(rs.getString(4));
		book.setPublisher(rs.getString(5));
		
	
		return book;
	}

	
	}

	

