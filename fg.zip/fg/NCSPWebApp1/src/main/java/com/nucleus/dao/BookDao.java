package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Book;


public interface BookDao {

	public void save (Book book);
	public void delete(Book book);
/*public void delete(String s);*/
	public List<Book> show();
	public Book show1(Book book);
	public Book save1(Book book);
}
