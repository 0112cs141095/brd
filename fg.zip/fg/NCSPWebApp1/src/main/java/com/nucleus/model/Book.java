package com.nucleus.model;

public class Book {

	String name;
	@Override
	public String toString() {
		return "Book [name=" + name + ", isbn=" + isbn + ", description="
				+ description + ", category=" + category + ", publisher="
				+ publisher + "]";
	}
	String isbn;
	String description;
	String category;
	
	String publisher;
	 
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
}
