package com.nucleus.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nucleus.model.Book;







@Repository
public class BookDaoImpl implements BookDao

{ 
	@Autowired
	JdbcTemplate jdbcTemplate;
	List<Book> book=new ArrayList<Book>();
	
	public void save(Book book)
	{
		Object books[]={book.getName(),book.getIsbn(),book.getDescription(),book.getCategory(),book.getPublisher()};
		
		jdbcTemplate.update("insert into bookservlet143 values(?,?,?,?,?)",books);
	}

	public void delete(Book book)
	{ Object books=book.getIsbn();
	
		jdbcTemplate.update("delete from bookservlet143 where ISBN=?",books);
	
		
	}
	
	public List<Book> show()
	{ System.out.println("*********");
		List<Book> book= (List<Book>) jdbcTemplate.query("select * from bookservlet143", new UserDetails());
	
		return book;
	}

	
	public Book show1(Book book)
	{ System.out.println("*********");
	 Object books[]= {book.getIsbn()};
	 try{
	 Book u= (Book) jdbcTemplate.queryForObject("select * from bookservlet143 where ISBN=?",books, new UserDetails());
	 return u; }
	 
	 catch(Exception e)
	 {System.out.println("*******fbcfgh");
	 Book b=new Book();
		 e.printStackTrace();
		 return b;
	 }
		//return u;
	}

	
	public Book save1(Book book) {
		
		return null;
	}

	
	

}
	
	// public void
	
	/*public void delete(String s)
	{
		jdbcTemplate.update("delete from bookservlet143 where ISBN=?",s);
	}
	*/
	

