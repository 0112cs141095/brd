package com.nucleus.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.dao.BookDao;
import com.nucleus.model.Book;

@Controller
public class Control
{
	@Autowired
BookDao bookDao;

	@RequestMapping("/link1")	
public ModelAndView handler()
{
	return new  ModelAndView("success");
}
	
	
	@RequestMapping("/BookReg")	
	public String handler(Book book)
	{
		return "BookRegistration";
	}
	
	@RequestMapping("/booksubmit")	
	public String handler1(Book book)
	{
		bookDao.save(book);
		return "success";
	}
	
	@RequestMapping("/deletebook")
	public String handler2(Book book)
	{
		
		return "Delete";
	}
	
	/*@RequestMapping("/deletebook")
	public String handler2(String s)
	{
		
		return "Delete";
	}
	*/
	@RequestMapping("/deleteid")
	public String handler3(Book book)
	{
		bookDao.delete(book);
		return "success";
	}

	
	@RequestMapping("/show")
	public ModelAndView handler4()
	{
		List<Book>book=bookDao.show();
		 for(Book e:book)  
			        System.out.println(e);  
			
		 return new ModelAndView("view","c",book);

		
	}
	
		@RequestMapping("/update")
	public String handler5(Book book)
     {
			return "updateid";
	}
	
		/*@RequestMapping("/u")
		public ModelAndView handler6(Book book)
		{
			Book b=bookDao.show1(book);
			  
				        System.out.println(b);  
				        
				      
				      
				      
				
			 return new ModelAndView("updateform1","r",b);

			
		}*/
		
		
		
		@RequestMapping("/u")
		public ModelAndView handler6(Book book)
		{
			Book b=bookDao.show1(book);
			  
			if(b.getIsbn()==null)
			{
				return new ModelAndView("success");
			}
				        System.out.println(b);  
				        
				      List<Book> l=new ArrayList<Book>();
				      l.add(b);
				      
				//      return new ModelAndView("view","c",l); 
				
			 return new ModelAndView("updateform1","r",l);

			
		}
}
	

