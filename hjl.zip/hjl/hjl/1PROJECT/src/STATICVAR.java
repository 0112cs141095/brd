class EMPLOYEE
{
	  int empid;//different copies are generated for both the object
	String name;
	int age;
	static int nextid=1;//only one copy is generated so all changes a done on that copy only
	
void get(int age,String name)
{this.name=name;
this.age=age;
System.out.println("id is "+ nextid);// 1 is generated first time nad the other time it is incremented by one
System.out.println("age is "+ age + " and name is " + name);
 nextid++;//incrementation takes place after each run
 }}

class STATICVAR
{
	public static void main(String[] args){
	EMPLOYEE e=new EMPLOYEE();// first object creation
	EMPLOYEE f=new EMPLOYEE();//second object creation
      e.get(21,"ram");
      f.get(22,"shyam");
	}

}
