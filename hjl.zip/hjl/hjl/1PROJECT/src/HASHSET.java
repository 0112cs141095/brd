import java.util.HashSet;


public class HASHSET {

	public static void main(String[] args) {
	int s[]={10,20,20,40,50};
	HashSet h=new HashSet();
  for(int i=0;i<5;i++)
  {
	  if(h.contains (s[i]))
	  
	  {
		  System.out.println("present");
	  }
	  else
	  {     h.add(s[i]);
		  System.out.println("not present");
	  }
  }
  
  
	}

}
