class BIRTHDATE   //bithdate class
{
	int day;
	String month;
	int year;
	
	BIRTHDATE(int day,String month,int year)//3 parameters constructor
	{this.day=day;
	this.month=month;
	this.year=year;
	}
}


public class AGGERATION //main class
{
	int id;
	String name;
	BIRTHDATE dob; // creating object of birthdate data type

	AGGERATION(int id,String name,BIRTHDATE dob) //constructor
{this.id=id;
		this.name=name	;
this.dob=dob;}

void display()
{
	System.out.println("id is "+ id + " name is "+ name);
	System.out.println("birth date is " + dob.day+"/"+dob.month+"/"+dob.year); //calling data members by the object name
}

public static void main(String args[])
{BIRTHDATE b=new BIRTHDATE(14,"october",96);// assigning values
BIRTHDATE c=new BIRTHDATE(18,"september",95);

AGGERATION e1=new AGGERATION(1,"ram",b);
AGGERATION e2=new AGGERATION(2,"shyam",c);

e1.display(); //display values
e2.display();}
	
}
