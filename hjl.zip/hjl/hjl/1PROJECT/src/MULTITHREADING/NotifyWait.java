package MULTITHREADING;

public class NotifyWait {

	public static void main(String[] args) {
	

	}

}
