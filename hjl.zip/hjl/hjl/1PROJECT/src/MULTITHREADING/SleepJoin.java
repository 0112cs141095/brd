package MULTITHREADING;




class ChildThread2 extends Thread
{
	public void run()
	{ for( int i=0;i<5;i++)
		System.out.println("child class" +i);
	try {
		Thread.sleep(500);
	} catch (InterruptedException e) {
		
		e.printStackTrace();
	}}
	
	
}
public class SleepJoin {

	public static void main(String[] args) {
		
		 ChildThread2 ct=new  ChildThread2();
		 ChildThread2 ct1=new  ChildThread2();
		 ChildThread2 ct3=new  ChildThread2();
		 ct.start();
		 try {
			ct.join(1500);   //execution will be given for 1500 mili seconds
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}   
	     ct1.start();
	     ct3.start();
	     
	}

}
