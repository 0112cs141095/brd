package MULTITHREADING;


class ChildThread3 implements Runnable
{
	  public void run(){
		   System.out.println("running...");
		  }
}
public class ThreadRunnable {

	public static void main(String[] args) {
		
			
		       ChildThread3	   t1=new  ChildThread3();
			Thread t=new Thread(t1);         //because we implemented runnable
			 System.out.println("Name of t:"+t.getName());
			  t.setName("Sonoo Jaiswal");
			  System.out.println("After changing name of t:"+t.getName());
			 }
			


	

}
