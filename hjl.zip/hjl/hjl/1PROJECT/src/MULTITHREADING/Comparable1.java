package MULTITHREADING;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Student implements Comparable<Student>
{
	int rollno;
	String name;
	
	
	public Student(int rollno, String name) {
		super();
		this.rollno = rollno;
		this.name = name;
	}
 public int compareTo(Student s)
{
	if(rollno>s.rollno)
	{
		return 0;}
	
	
		
		else if(rollno>s.rollno)
		{
			return 1;
			
		}
		else
			return -1;
	
}
	
	/*public int compareTo(Student s)
	{
		if(name.equals(s.name))
		{
			return 1;
		}
		else 
			return 0;
	}*/
}

public class Comparable1 {
	public static void main(String args[])
	{
		
	
	 List <Student> l=new ArrayList<Student>();
	    
	Student s1=new Student(103,"SURBHI");
	Student s2=new Student(102,"SURBHI");          
     l.add(s1); 
     l.add(s2);
     
    
    Collections.sort(l);
     for(Student std:l)
     {
    	 System.out.println("roll no"+ std.rollno + " name"+ std.name);
    	 
     }
     
}}
