package MULTITHREADING;



class StudentChild implements Cloneable
{
	int rollno;
	String name;

	
	public StudentChild(int rollno, String name) {
		
		this.rollno = rollno;
		this.name = name;
	}
	
	public  Object clone() throws CloneNotSupportedException        
	{
		 return super.clone();
	}
	
 
	
}


public class Clone {
	void show(StudentChild s)
	{
		System.out.println("rollno "+s.rollno+ "name "+s.name);
	}
	public static void main(String[] args) throws CloneNotSupportedException {
	
		StudentChild s1=new StudentChild(101,"surbhi");
		StudentChild s2= (StudentChild)s1.clone();
		Clone c=new Clone();
		c.show(s1);
		c.show(s2);

	}

}
