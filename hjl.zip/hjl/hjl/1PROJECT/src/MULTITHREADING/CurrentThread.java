package MULTITHREADING;


		
		public class   CurrentThread{

			public static void main(String[] args) {
				
					
				      
					Thread t=Thread.currentThread();       
					 System.out.println("Name of t:"+t.getName());
					  t.setName("I am main class thread");
					  System.out.println("After changing name of t:"+t.getName());
					 }
					


			

		


	

}
