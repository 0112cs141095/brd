package MULTITHREADING;


class ChildThread4 implements Runnable
{   public void run()
{
	

	ChildThread ct1=new ChildThread();
       System.out.println("thread in child  "+ ct1.getPriority());
       System.out.println("priority is" + ct1.getPriority());
}
}
public class Priority {

	public static void main(String[] args) {
		ChildThread ct=new ChildThread();
	System.out.println(	" thread in main "+ct.getPriority());
	ct.setPriority(5);
	ct.run();
	}

}
/*output:
thread in main 5
Thread[Thread-1,5,main]
child class thread*/