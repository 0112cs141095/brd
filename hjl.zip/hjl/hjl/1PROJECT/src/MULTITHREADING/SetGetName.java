package MULTITHREADING;


class ChildThread extends Thread
{
	public void run()
	{    ChildThread ct1=new ChildThread();
		System.out.println(ct1);  
		System.out.println("child class thread");
	}
}
public class SetGetName {

	public static void main(String[] args) {
		
	ChildThread ct=new ChildThread();
	System.out.println(ct.getName());
	
	System.out.println(ct.getId());
	ct.setName("child thread name change");
	System.out.println(ct);   // give the priority and the method main
	System.out.println(ct.getPriority());
	ct.run();
	}

}
 /*output: Thread-0
 10
 Thread[child thread name change,5,main]
 5
 Thread[Thread-1,5,main]
 child class thread*/