package MULTITHREADING;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class Student1 
{
	int rollno;
	String name;
	
	
	public Student1(int rollno, String name) {
		super();
		this.rollno = rollno;
		this.name = name;
	}
}

 class RollNoComparator  implements Comparator<Student1>
{
	public int compare(Student1 s1,Student1 s2)
	{
		if(s1.rollno==s2.rollno)
			return 0;
		else if(s1.rollno>s2.rollno)
			return 1;
		else
			return -1;
	}
}
 
 class NameComparator implements Comparator<Student1>{

	 public int compare(Student1 s1,Student1 s2)
	{
		return s1.name.compareTo(s2.name);
		
	}
 }

 public class Comparator1 {

	public static void main(String[] args) {
	
Student1 s1=new Student1(101,"rurbhi");
Student1 s2=new Student1(102,"ram");
ArrayList<Student1> l=new ArrayList<Student1>();
 
 l.add(s1);
 l.add(s2);
//Collections.sort(l,new RollNoComparator()) ;
Collections.sort(l,new NameComparator()) ;
for(Student1 s:l)

System.out.println(s.rollno +"  "+s.name);

	
	}}
 
	


