package MULTITHREADING;


class SynchronizedDemo
{
	 synchronized void  print() throws InterruptedException
	{
		for(int i=0;i<5;i++)
		{
			System.out.println("class 1 "+i);
			Thread.sleep(500);
		}
	}
}

class SynchronizedDemo1 implements Runnable
{
	SynchronizedDemo sd2;
	public void setSd2(SynchronizedDemo sd2) {
		this.sd2 = sd2;
	}
	public void run()
	{
		try {
			
			sd2.print();
		}
		catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		for(int i=0;i<5;i++)
		{
			System.out.println("class 2 "+i);
			
		}
	}
	
}
public class Synchronized {
	public static void main(String args[])
	{
		
		SynchronizedDemo sd=new SynchronizedDemo();  //shared resource
	
	SynchronizedDemo1 sd1=new SynchronizedDemo1();
	sd1.setSd2(sd);
	Thread th=new Thread(sd1);
	SynchronizedDemo1 sd4=new SynchronizedDemo1();
	sd4.setSd2(sd);          //sharing
	Thread th2=new Thread(sd4);
	
	th.start();
	th2.start();
	 
}}
