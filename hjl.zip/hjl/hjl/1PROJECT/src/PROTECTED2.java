
class PROTECTED2{

	public static void main(String[] args) {
		
			{  PROTECTED2 b=new  PROTECTED2();
	b.show(); // WILL not WORK AS SHOW IS A PROTECTED FUNCTION SO IS not AVAILABLE 
	}}}
 
