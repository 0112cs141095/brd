package day5;

import java.util.Scanner;

public class EmployeeMain {

	public static void main(String[] args) {
		
		System.out.println("      Welcome!          ");
		System.out.println("ENTER UR CHOICE ");
		System.out.println("PRESS 1 TO GET WEEKLY SALARY OF EMPLOYEE");
		System.out.println("PRESS 2 TO SET THE RATE OF EMPLOYEES");
		Scanner kb=new Scanner (System.in);
		
		int n=kb.nextInt();
		kb.nextLine();
		switch(n)
		{
		case 1:
			System.out.print("enter the name of employee");
			 String name= kb.nextLine();
		}
	      
      		

	}

}
