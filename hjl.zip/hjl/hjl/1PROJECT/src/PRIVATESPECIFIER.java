
class PRIVATE
{
	private  void show()
	{
		System.out.println("x");
	}
}
class specifier {

	public static void main(String[] args) {
		
			{ PRIVATE b=new PRIVATE();
	b.show(); // WILL NOT WORK AS SHOW IS A PRIVATE FUNCTION SO IS AVAILABLE ONLY WITHIN THAT CLASS
	}}
