
public class CIRCLECLASS {
	private	double radius;
public String color;
CIRCLECLASS()
{
	
}
CIRCLECLASS(double radius)
{
	this.radius=radius;
}
 double getradius()
 {
	 return radius;
 }
 double getarea()
 {    double r=getradius();
	 double area= Math.PI*Math.pow(r,2); 
  return area;}
	
 public static void main(String[] args) {
	 
	 CIRCLECLASS w=new CIRCLECLASS(10);
	 w.getradius();
	 
	 double farea=w.getarea();
		System.out.println("area is "+ farea);

	}

}
