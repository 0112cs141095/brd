class PROTECTED3 extends Z{

	public static void main(String[] args) {
		
			{  PROTECTED3 b=new PROTECTED3();
	b.show(); // WILL  WORK AS SHOW IS A PROTECTED FUNCTION SO IS AVAILABLE 
	}}}
 
