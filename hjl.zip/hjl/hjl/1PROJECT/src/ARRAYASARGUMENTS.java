import java.util.Scanner;

class Calculate
{public int sum(int arr[],int c)
{int sum=0;
int i;
	for(  i=0;i<c;i++)
	{sum=sum+arr[i];}
return sum;}
	
}
public class ARRAYASARGUMENTS {
	
public static void main(String args[])
{System.out.println("enter the no. of values");
 Scanner kb=new Scanner(System.in);
 int b=kb.nextInt();
	int arr []=new int[b];
	System.out.println("enter values in the array");
int c=kb.nextInt();	
	for( int i=0;i<c;i++)
		{arr[i]=kb.nextInt();
		}
	 Calculate d=new  Calculate();
	int total= d.sum(arr, c);
	System.out.println(total);}

}
