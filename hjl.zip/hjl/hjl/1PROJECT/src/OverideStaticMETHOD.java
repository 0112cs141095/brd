




class BASE
{
	 static void print ()
	{
		System.out.println("BASE CLASS");
	}
}
	class CHILD extends BASE
	{
		 static void print ()//overridden static method 
		{
			System.out.println(" CHILD CLASS");
		}
	}
public class OverideStaticMETHOD {

	public static void main(String[] args) {
		CHILD obj=new CHILD();
		 obj.print();//child class object is created any method is called
	
	}

}
