 
public class STRINGARGUMENT {
	public void get( String name)
	 {
		 System.out.println("name is "+ name);
	 }

	public static void main(String[] args) {
		STRINGARGUMENT s=new STRINGARGUMENT();
		s.get("surbhi");
		
		

	}

}
