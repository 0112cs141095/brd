package pkg2;

import pkg1.Z;

class PROTECTED4 extends Z{

	public static void main(String[] args) {
		
			{  PROTECTED4 b=new  PROTECTED4();
	b.show(); // WILL not  WORK AS SHOW IS A PROTECTED FUNCTION SO IS  not AVAILABLE  outside package
	}}}
