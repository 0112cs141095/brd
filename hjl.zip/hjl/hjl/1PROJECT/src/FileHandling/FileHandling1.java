package FileHandling;
 import java.io.*;
public class FileHandling1 {
	
	public void saveToFile(String name)
	{  FileWriter filewriter=null;
		try
		{
			filewriter=new FileWriter("file1.txt",true);  //
			PrintWriter printwriter=new PrintWriter(filewriter);
			printwriter.write(name);
			printwriter.flush();}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	
	finally
	{
		try
		{
			filewriter.close();
		}
	     catch(Exception w)
	     {
	    	 w.printStackTrace();
	     }
	 }
	
	}
	
	public void readFromFile()
	{
		try
		{
			FileReader filereader=new FileReader("file1.txt");
			BufferedReader bufferedreader=new BufferedReader(filereader);
			String line=bufferedreader.readLine();
			System.out.println(line);
			
		}
		catch(IOException k)
		{
			k.printStackTrace();
		}
	//	catch(File)
	}

	public static void main(String[] args) {
		
		FileHandling1 filehandling=new FileHandling1();
		filehandling.saveToFile("surbhi");
		filehandling.readFromFile();
	}
}

