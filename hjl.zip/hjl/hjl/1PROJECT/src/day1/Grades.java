package day1;


	

import java.util.Scanner;
import java.util.*;
	public class Grades {
		float average(int arr[],int n)
		{int sum=0;
			for(int i=0;i<n;i++)
			{ 
			 sum =sum +arr[i];}
		float av=sum/n;
		return av;}
			

		public static void main(String[] args) {
			System.out.println("Enter the no of students");
			Scanner kb=new Scanner(System.in);
			int n=kb.nextInt();
			int arr[]=new int[n];
			for(int i=0;i<n;i++)
			{
				System.out.println("Enter grades for student "+ (i+1));
				int a= kb.nextInt();
				if(a>100)		
				{System.out.println("Invalid grades,try again.....");
				  i--;}
				else
					arr[i]=a;
			}
			Grades g=new Grades();
			float x=g.average(arr,n);
			System.out.println("Average is "+ x);
			
		}

}
