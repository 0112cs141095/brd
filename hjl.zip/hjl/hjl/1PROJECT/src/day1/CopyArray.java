package day1;





import java.util.Scanner;
class COPY1
{
	 static int[] copyOf(int[] array)
	{
		 int n=array.length;
	int b[]=new int [n];
	 for( int i=0;i<array.length;i++)
{
	b[i]=array[i];
	
	
	
}
return b;	 }
	 }

public class CopyArray {
	

public static void main(String[] args)
{
	int i;
	Scanner kb= new Scanner(System.in);
	System.out.println("Enter no of values in the array:");
 int n=kb.nextInt();
	int a[]=new int[n];
	int c[]=new int[n];
	
	
	System.out.print("Enter values in the array:");
	
		for(i=0;i<n;i++)
	{
		a[i]=kb.nextInt();
	}
	
	
	 //COPYARRAY a=new  COPYARRAY();
    c = COPY1.copyOf(a);
   
     for(int j=0;j<n;j++)
    { 
   	 System.out.print(c[j]);
   	 System.out.print(" ");
   	 
   	 
    }
	}

}
