package day1;

public class Fibonacci {
	
		public static void main(String args[])
		{
			int i=0;
			int j=1;
			double total=0;
			int sum=0;
			System.out.println("The first 20 fibonacci no are:");
			System.out.print(j);
			System.out.print(" ");
	  for( int k=2;k<=20;k++){
				sum=i+j;
				System.out.print(sum +" ");
				total=total+sum;
				i=j;
				j=sum;
				
			}
	  System.out.println("The average is:" +((total+1)/20));
		

	}}

