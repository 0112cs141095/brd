package Collections;

import java.util.ArrayList;
import java.util.List;

public class NongenericGet
{
	  public static void main(String args[])
	        {     
	               List l=  new ArrayList();
	            
	               
	               l.add(10);
	               l.add(10.4);
	               l.add("hello");
	               l.add(2,"bye");
	             
	               System.out.println(l.get(1));
	               // int x=l.get(1);   error:cannot convert object to int
	       
	               int x=(Integer)l.get(0);  //upcasting
	               System.out.println(x);
	              
	         }

}
