package Collections;

class Test
{
	void show(int... a)
	{
	      for(int b:a)
	      {
		System.out.println(b);}
	}
	
	void show(int a1)
	{
		System.out.println(a1);
	}
	
	void show(Integer a2)
	{
		System.out.println(a2);
	}
}


public class NearestCall {
	public static void main(String args[])
	{
		Test t=new Test();
		t.show(10);
	
	}
	
	

}
