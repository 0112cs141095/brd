package Collections;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Student
{ 
	  Scanner kb=new Scanner(System.in);

     int rollno;  
     String name;  
     int age;  
            
     Student(int rollno,String name,int age)
     {  
   
    	   this.rollno=rollno;  
           this.name=name;  
           this.age=age;  
     }  
     
     public  String toString()
     {
     	return "Name: " +name+ "  Roll no: "+rollno+ "  Age: "+age +"\n";
     }
     
     
}  


public class Studentnongenerics
{ int rollno;
	
	void display(ArrayList al)
    {
   	 System.out.println(al);
    }
	
	void show(int sid,ArrayList al)
			{ boolean found=false;
		for(int i=0;i<al.size();i++)
	   	  {
	   		Student s=(Student)  al.get(i);
	   		  if(s.rollno==sid)
	   		  {
	   			  System.out.println(s);
	   			found=true;
			}}
		 if(!found)
		   	  
		   	  
	   		  System.out.println("Invalid ID");	}
    
    void delete(ArrayList al,int sid )
    { boolean found=false;
   	  for(int i=0;i<al.size();i++)
   	  {
   		Student s=(Student)  al.get(i);
   		  if(s.rollno==sid)
   		  {
   			  
   			 al. remove(i);
   			 found=true;
   		  }}
   	  if(!found)
   	  
   	  
   		  System.out.println("Invalid ID");
   	  else
   		  

   		  System.out.println("Record deleted");}
   	 
    void update(ArrayList al,Student std)
    {boolean found=false;
    	for(int i=0;i<al.size();i++)
     	  {
     		Student s=(Student)  al.get(i);
     		  if(s.rollno==std.rollno)
     		  {    s.rollno=std.rollno;
     		        s.age=std.age;
     		        s.name=std.name;
     		       found=true;
     		  }}
     		 if(!found)
     		   	      		   	  
     	   		  System.out.println("Invalid ID");
     		      
     	   	  else
     	   		  

     	   		  System.out.println("Record updated");}
    
    
  

	public static void main(String[] args)
	   {
		    Studentnongenerics  m= new Studentnongenerics();
		  
		   System.out.println("DETAILS ARE:");
		   System.out.println("");
		   
		   		 
		  Student s1=new Student(101,"Rohan",23);  
		  Student s2=new Student(102,"Ravi",21);  
		  Student s3=new Student(103,"Rohit",25);  
		  
		  
		  ArrayList <Student> l=new ArrayList <Student>();
		  
		  int choice=0;
		  
		  l.add(s1);//adding Student class object  
		   l.add(s2);  
		  l.add(s3);  
		  System.out.println("******************");
		  do{
		  System.out.println("press 1 to display the  record of students");
		  System.out.println("press 2 to delete the particular id student");
		  System.out.println("press 3 to display the particular id student");
		  System.out.println("press 4 to update the particular id student");
		  Scanner s=new Scanner(System.in);
	    	 choice=s.nextInt();
		
	    	 switch(choice)
	    	 {
	    	 case 1:
	    		     m.display(l);
	    		     break;
	    	 case 2:
	    		 System.out.println("Enter the id:");
	       	    int id=s.nextInt();
	    		   m.delete(l ,id);
	    		   break;
	    		     
	    	
		  case 3:
			  System.out.println("Enter the id:");
			  int sid1=s.nextInt();
			  m.show(sid1,l);
			  break;
			  
			  
		  case 4:
			  System.out.println("Enter the id:");
			  int sid2=s.nextInt();
			  s.nextLine();
			  System.out.println("Enter the name");
			 String sname=s.nextLine();
			  System.out.println("Enter the age");
			  int sage= s.nextInt();
			  Student s4=new Student(sid2,sname, sage);
			  m.update(l,s4);
			 
		 
		  } }while(choice!=1||choice!=2||choice!=3);

	
}
}
