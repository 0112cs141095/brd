package Collections;

import java.util.List;
import java .util.ArrayList;

class Test2
{
	void display(List l)
	
	{
		System.out.println(l);
		
	}
}


public class ArrayList1 
{
	
public static void main(String args[])
{     
	          Test2 t=new Test2();
               List l2=new ArrayList();
               ArrayList al=new ArrayList();
               List l=  new ArrayList();
            
               
               l.add(10);
               l.add(10.4);
               l.add("hello");
               l.add(2,"bye");
               l.remove(2);
              // l.add(l2);  hash code of l2 will be printed 
               l2.add(90);
               l2.add(50);
               l.add(l2);
 
               
               //System.out.println(l);  
          
               al.add("surbhi");
                l2.add(al);
     
                
                t.display(l);
                t.display(l2);
                t.display(al);
 
         }
}

 /*output:  [10, 10.4, hello, [90, 50, [surbhi]]]
[90, 50, [surbhi]]
[surbhi]*/


