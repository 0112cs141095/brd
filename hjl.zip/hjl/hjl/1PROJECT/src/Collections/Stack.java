package Collections;

class A
{   int i,x;
int arr[]=new int[100];
	void add(int b)
   
{
		
	while(i<100)
	{
		arr[i]=b;
		i++;
		
		break;
	}
}
	void show()
	{
		for( int i=0;arr[i]!='\0';i++)
		{
			System.out.println(arr[i]);
			System.out.println("");
			
		}
	i--;}
	
   void remove()
   {    
	   arr[i]='\0';
	   

	   
   }
}


	


public class Stack {
	public static void main(String args[])
	{
		A a=new A();
		a.add(10);
		a.add(20);
		a.show();
		System.out.println("************");
		a.remove();
		a.show();
		System.out.println("************");
		a.add(30);
		a.show();
		System.out.println("************");
		a.remove();
		a.show();
		
		
		
	}
	

}
