package Collections;
import java.util.*;


class Test3
{
	void display(Set l)
	
	{
		System.out.println(l);
		
	}
}
public class SetMain {

	public static void main(String[] args) {
		  
		Test3 t=new Test3();
		  //Creating HashSet and adding elements  
		  Set set=new HashSet();  
		  set.add("Ravi");  
		  set.add("Vijay");  
	  set.add("Ravi");  //duplicate values 
		  set.add(10);  
		  t.display(set);

	}

}
