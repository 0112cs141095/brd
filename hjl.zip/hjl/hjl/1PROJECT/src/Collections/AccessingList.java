package Collections;


	import java.util.ArrayList;

	import java.util.Iterator;

	import java.util.List;





	public class AccessingList {

	    public static void main(String args[])

	    {

	        List <Integer >l1=new ArrayList<>();

	                 l1.add(90);

	                 l1.add(20);

	                 l1.add(2,20);

	                 l1.add(3,50);

	                 l1.add(4,30);

	     //          l1.add(2,20); run time error as value at second index is added last

	       

	                 for( int i=0;i<l1.size();i++)

	                  {

	                         int x=l1.get(i);

	                          System.out.println(x);

	                  }

	   

	         List <Double >l2=new ArrayList<>();

	    

	                 l2.add(9.0);

	                 l2.add(20.6);

	                 l2.add(2,12.65);

	                 l2.add(3,58.9);

	                 l2.add(4,30.21);

	  

	                  for(Double d:l2)

	                      

	                  {

	                      System.out.println(d);

	                  }

	         

	           List <String >l3=new ArrayList<>();   

	           

	                    l3.add("ram");

	                    l3.add("shyam");

	    

	            Iterator <String> itr=l3.iterator();

	            while(itr.hasNext())

	            {

	                System.out.println(itr.next());

	            }

	    }

	}

