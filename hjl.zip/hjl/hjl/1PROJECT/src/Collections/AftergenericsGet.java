
package Collections;

import java.util.ArrayList;
import java.util.List;
public class AftergenericsGet {

	  public static void main(String args[])
	        {     
	               List<Integer> l=  new <Integer> ArrayList(); //including generics
	            
	               
	                  l.add(10);
	            
	               // l.add(10.4);    error because can't add float
	              //  l.add("hello"); error because can't add string
	              //  l.add(2,"bye"); error because can't add string
	             
	                 System.out.println(l.get(0));
	                 int x=l.get(0); //   no error
	       
	             /*  int x=(Integer)l.get(0);  // no need to do upcasting
	               System.out.println(x);*/
	              
	         }

}
