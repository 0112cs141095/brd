package Collections;

import java.util.Scanner;


class T
{ 
	int count;
    String details;
    long sum=0;
    int c=0;
    int u=0;
  
   void calculate (int count,String details[])
  {
	   for(int i=0;i<details.length;i++)
	   {
		        String a=details[i];
		        
		        long l=a.length();
		        System.out.println("length=  "+l);
		        
		        Long a1=Long.parseLong(a);
		
		       
		        while(a1!=0)
		        {
		        	 long r=  (a1%10);
		        	 sum=sum+r;
		        	 
		        	 a1=a1/10;
		      
		        }
		        
		          
		        double av =(double)sum/l;
		        System.out.println("average ="+av);
		        sum=0;
		        if(av>=5)
		        {
		           u++;
		           
		        }
		        	
	   }       	
	   System.out.println("bowlers is" + u)  ;	
		        
 }
	   
	  
  }
 


public class TestMain1 {

	public static void main(String[] args)
	
	{
		
		                   T r=new T();
		            
		                   System.out.println("enter the no of players");
		                   Scanner kb=new Scanner(System.in);
		                   int a=kb.nextInt();
		                    kb.nextLine();
		      
		                    String details[]=new String[a];
		                    System.out.println("enter the details");
		                    String str=kb.nextLine();
	
		                             int x= str.length() -2;
		                             str=str.substring(1,x);
                                     String str1[]= str.split(",");
		
                                     for( int j=0;j<str1.length;j++)
		                                 {
		
		                                     details[j]=str1[j];
	                                     }
                                   r.calculate( 5,details);

   
	}

}
