package day3;


 class Book {
private int bookId;
private String title;
private String author;
private float price;



	
	
public int getBookId() {
	return bookId;
}

public String getTitle() {
	return title;
}

public String getAuthor() {
	return author;
}

public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
Book(int bookId,String title,String author,float price){
	this.bookId = bookId;
	this.title = title;
	this.author = author;
	this.price = price;

}

}

 class Periodical extends Book {
	

	private int period;
	
	Periodical(int bookId, String title, String author, float price, int period) {
		super(bookId, title, author, price);
	
		this.period=period;
	}
	
	void change(float price, int period){
		setPrice(price);
		this.period=period;
	}

	
	public String toString() {
		return "Periodical [period=" + period + ", bookId=" + getBookId()
				+ ", price=" + getPrice()+ ", author=" + getAuthor() + ", title="
				+ getTitle() + "]";
	}
	
	
	
}
public class PeriodicalMain {

	public static void main(String[] args) {

		Book book;
		book = new Periodical(964,"ALCHEMIST","PAULO",200.0f,2);
		System.out.println(book);
	}

}
