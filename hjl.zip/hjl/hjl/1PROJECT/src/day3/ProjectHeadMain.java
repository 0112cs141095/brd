package day3;

import java.util.Scanner;

class Employ
{
	 private String id;
	 private String name;
	 private String desgn;
	 private String p_id;
	static private String phoneno;
	 Employ( String id, String name, String desgn, String p_id, String phoneno)
	 {
		 this.id=id;
		 this.name=name;
		 this.desgn=desgn; 
		 this.p_id=p_id;
		 this.phoneno=phoneno;
	 }
	String getId() {
		return id;
	}
	 String getName() {
		return name;
	}
	 String getDesgn() {
		return desgn;
	}
	 String getP_id() {
		return p_id;
	}
	String getPhoneno() {
		return phoneno;
	}
	void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	
	
	
	
}

class ProjectHead extends Employ
{
	private String practicename;
	 static private int noofcustomer;
	ProjectHead (String practicename,int noofcustomer)
	{
		super("01cs0123","RAM","manager","m254","9834736519");
		this.practicename=practicename;
		this.noofcustomer=noofcustomer;
	}
	
	void show()

    {

        System.out.println("NAME IS: " + getName()+"\nID IS: "+ getId() +"\nDESIGNATION IS: "+getDesgn()+ "\nproject id IS: "+getP_id()+"\nphonenumber IS:"+ getPhoneno()+"\nPRACTICE NAME:"+ practicename+"\nNO OF CUSTOMER:"+noofcustomer); }
	
	void modify(int cusno,String pnum)
{         this.setNoofcustomer(cusno);
		setPhoneno(pnum);
}
	private String getPracticename() {
		return practicename;
	}
	
	private void setNoofcustomer(int noofcustomer) {
		this.noofcustomer = noofcustomer;
	}
	private int getNoofcustomer() {
		return noofcustomer;
	}
	
}
public class ProjectHeadMain {
	public static void main(String args[])
	{
		
	
	 System.out.println("EMPLOYEE DETAIL IS\n ");
	 ProjectHead p=new ProjectHead("Shyam",57);
	 p.show();
	  System.out.println("*************************************");

      System.out.println("PRESS 1 TO MODIFY NUMBER OF CUSTOMERS and phone no:");

      Scanner kb=new Scanner (System.in);

       int n=kb.nextInt();
       kb.nextLine();
       if(n==1)

       {   System.out.println("ENTER NEW NUMBER");

        String pnum=kb.nextLine();

        

        System.out.println("ENTER NEW NUMBER OF CUSTOMER  ");

        int cusno=kb.nextInt();

           p.modify( cusno, pnum);

       System.out.println(" Modified STUDENT DETAIL IS ");

       p.show();}

       else

           System.exit(1);

           
	}}
	


