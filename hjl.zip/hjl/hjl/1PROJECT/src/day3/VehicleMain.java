package day3;

 class Vehicle {
	private int vehicleno;
	private int model;
	private String make;
	private String manufacturer;
	private String color;
	
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getVehicleno() {
		return vehicleno;
	}
	
	public int getModel() {
		return model;
	}

	public String getMake() {
		return make;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	
	
	
	Vehicle(int vno,int model,String make, String manufacturer,String color){
		this.vehicleno = vno;
		this.color=color;
		this.make = make;
		this.model = model;
		this.manufacturer = manufacturer;
	}

	}
	
	


 class Truck extends Vehicle{
	
	
	private String loadingCapacity = "100 tonns";
	
	Truck(int vno, int model, String make, String manufacturer, String color) {
		super(vno, model, make, manufacturer, color);

	}

	
	public void modify(String color, String loadingCapacity){
		setColor( color);
		this.loadingCapacity = loadingCapacity;
	}


	
	public String toString() {
		return "Truck [LoadingCapacity=" + loadingCapacity + ", color=" + getColor()
				+ ", vehicleno=" + getVehicleno() + ", model=" +getModel()+ ", make="
				+ getMake() + ", manufacturer=" +getManufacturer() + "]";
	}


	
	
	
	
	
}
public class VehicleMain {

	public static void main(String[] args) {
		
		Truck t = new Truck(6734,453,"Moto","Motorola","black");
		t.modify("blue", "70tonns");
		System.out.println(t);
	}

}
