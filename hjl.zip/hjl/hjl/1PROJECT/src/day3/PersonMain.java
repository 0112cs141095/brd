package day3;

class Person
{
	 public Person(String name, int birthyear) {
		super();
		this.name = name;
		this.birthyear = birthyear;
	}
	private String name;
	 private int birthyear;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getYear() {
		return birthyear;
	}
	public  void setYear(int year) {
		this.birthyear = birthyear;
	}
}

class Students extends Person
{ private String major;

	public Students(String name, int birthyear, String major) {
		super(name, birthyear);
		this.major = major;
	}
	void show()
	{
		System.out.println("name: "+getName() +"year: "+ getYear()) ;
	}
   public String toString()
   {
	   return "Student  major is " + major ;
   }


	public  String getMajor() {
		return major;
	}

	
	
	
}
class Instructor extends Person
{
	 public Instructor(String name, int birthyear, double salary) {
		super(name, birthyear);
		this.salary = salary;
	}
	 

	private double salary;
	public String toString()
	   {
		   return "INSTRUCTOR SALARY is " + salary ;
	   }

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
}

public class PersonMain {

	public static void main(String[] args) {
		
		
		Instructor i=new Instructor("SHYAM",1995,20000);
		Students s=new Students("ROHAN",1998,"physics");
		Person p1=new Students("rohit",1997,"chemistry"); 

System.out.println(p1);
System.out.println(s);
System.out.println(i);}

}
