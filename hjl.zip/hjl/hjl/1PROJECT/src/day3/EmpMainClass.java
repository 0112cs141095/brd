package day3;

class Employee

{

   private String name;

   private double salary;

   Employee(String name,double salary)

   {

       this.name = name;

       this.salary = salary;

   }

    /**

     * @return the name

     */

    public String getName() {

        return name;

    }



    /**

     * @return the salary

     */

    public double getSalary() {

        return salary;

    }



    /**

     * @param salary the salary to set

     */

    public void setSalary(double salary) {

        this.salary = salary;

    }



    /**

     * @param name the name to set

     */

    public void setName(String name) {

        this.name = name;

    }

    

}

class Manager extends Employee

{  

    

    String dept;

    public Manager(String name,  double salary, String dept) 

    {

        super(name, salary);

        this.dept = dept;}

   public  String toString()

    {

        return "NAME IS: "+  getName() + "\nSALARY IS: " +getSalary()+ "\nDEPARTMENT IS: " + dept ;

    }

}

 class Executive extends Manager

 {     

     Executive()

     {

         

             super("ram",1000,"it");}

     public  String toString()

     {      

         return "Executive NAME IS: "+  getName() + " \nSALARY IS: "+  getSalary()+ "\nDEPARTMENT IS: " + dept +"";

   

 }}

        

public class EmpMainClass {

  

    public static void main(String args[])

    { 

        Manager m=new Manager("ram",1000,"it");

        Executive e=new Executive();

        System.out.println(e);

    }

   

    

}
