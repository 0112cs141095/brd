package day3;


class Product {

	private int productId;
	private String name;
	private int categoryId;
	private float unitPrice;
	
	Product(int p_id,String name, int c_Id, float price){
		this.productId = p_id;
		this.name=name;
		this.categoryId=c_Id;
		this.unitPrice = price;
	}
	
	public int getProductId() {
		return productId;
	}
	
	
	public String getName() {
		return name;
	}
	
	public int getCategoryId() {
		return categoryId;
	}
	
	public float getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(float unitPrice) {
		this.unitPrice = unitPrice;
	} 
	
}
class ElectricalProduct extends Product {
	

	private int voltagerange;
	private int wattage;
	
	
	ElectricalProduct(int p_id, String name, int c_Id, float price,int voltage,int watt) {
		super(p_id, name, c_Id, price);
		this.voltagerange = voltage;
		this.wattage =watt;
		
	}

	void modify(int watt, float price){
		this.wattage = watt;
		setUnitPrice(price);
	}


	public String toString() {
		return "ElectricalProduct [voltagerange=" + voltagerange + ", wattage="
				+ wattage + ", productid=" + getProductId() + ", name=" + getName()
				+ ", categoryId=" +getCategoryId() + ", unitPrice=" + getUnitPrice()
				+ "]";
	}}
	
	public class ProductMain {

		
		public static void main(String[] args) {

			ElectricalProduct e =new ElectricalProduct(101, "REFEREGIRATOR", 9791, 1670.0f, 2500, 150);
			e.modify(15, 1156.0f);
			System.out.println(e);
		}

	}
