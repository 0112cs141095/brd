import java.util.Scanner;

 class BOOK
 {
	 String booktitle;
	 String authorname;
	 String isbn;
	 int noofcopies;
	 BOOK()
	 {
		 
	 }
	 
	 BOOK(String booktitle ,String author,String isbn ,int noofcopies)
	  
	 {this.booktitle =booktitle ;
	 this.authorname=author;
	 this.isbn=isbn;
	 this.noofcopies=noofcopies;}
	 String getbooktitle()
	 {
		 return booktitle;
	 }
	 String getauthorname()
	 {
		 return authorname;
	 }
	 String getisbn()
	 {
		 return isbn;
	 }
	 int getnoofcopies()
	 {
		 return noofcopies;
		 
	 }
	 void setnoofcopies(int noofcopies)
	 {
		 this.noofcopies=noofcopies;
		 
	 }
	 void display()
	 {
	 System.out.println("name is "+ booktitle +"author is "+ authorname +"isbn= "+isbn+"copies="+noofcopies);
	 }}
	
public class BOOKSTORE {
	BOOK[] book= new BOOK[100];
	void init()
	{
		book[0]= new BOOK("DATA STUCTURE","SEYMOUR","189654",3);
		book[1]= new BOOK("PROGRAMMING In C++","STEPHEN","197684",6);
		book[2]= new BOOK("ADVANCED JAVA" ,"DAVID","12543",1);
		book[3]= new BOOK("C PROGRAMMING LANGUAGE" ,"DENIS" ,"187643",2);
	}
	public void order(String isbn,int  noofcopies)
	{
		for( int i=0;i<book.length;i++)
		{
			if(book[i].getisbn().equalsIgnoreCase(isbn))
			{
				book[i].setnoofcopies((book[i].getnoofcopies())+noofcopies);
				}
			else
				{
				void addNewBook(BOOK b)
				{
					
				
				
				     
				        book[totalBooks] = b;
				        totalBooks++;

				}
				}}
	
	public void sell(String booktitle  ,int  noofcopies)
			{for( int i=0;i<book.length;i++)
			{
				
			
		if(book[i]. getbooktitle().equalsIgnoreCase( booktitle))
			{
			if(book[i].getnoofcopies()>= noofcopies)
				{book[i].setnoofcopies((book[i].getnoofcopies())+noofcopies);
				}
			else
				{System.out.println("sorry...book is not available");
				}
		}
			}}
	void display()
	{
		for( int i=0;i<book.length;i++)
		{
			book[i].display();
		}
	}
}
	
 public class mainclass()
{
	
		public static void main(String[] args) 
	{ BOOKSTORE bs;
	bs.init();
	int n;
	do{
	
	
	
			System.out.println("Enter �1�, to display the Books: Title � Author � ISBN - Quantity. ");
	
	System.out.println("Enter �2�, to order new books. ");
	System.out.println("Enter �3�, to sell books. ");
	System.out.println("Enter �0�, to exit the system");
	Scanner kb = new Scanner(System.in);
     n= kb.nextInt();
	switch(n)
	{
	case 1:
		bs.display();
		System.out.println("press any key to continue");
		break;
	case 2:bs.order("456372", 2);
	System.out.println("press any key to continue");
	break;
	case 3:bs.sell("DATA STUCTURE", 1);
		System.out.println("press any key to continue");
		break;
	case 4:
		break;}}
	while(n!=0);
	
	}

 
	         

	
	}
		/*	String itemName ;
			String author ;
			
			String itemNum ;

			int  itemQuan  ;

			

			System.out.println("enter the no of books to be enterd int the library" );
			Scanner kb = new Scanner(System.in);
            int n= kb.nextInt();
            kb.nextLine();
            BOOK book[] = new BOOK[n];
           
            for(int i=0;i<n;i++)
    {
	     System.out.println("ENTER THE BOOKS details of book" +(i+1));
	   System.out.println("===========================");
	    System.out.print("Enter Item Name: ");
	   itemName = kb.nextLine();

	   System.out.print("Enter isbn Number: ");
	   itemNum = kb.nextLine();         

	   System.out.print("Enter Quantity of Item: ");
	   itemQuan = kb.nextInt();
	   kb.nextLine();

	   System.out.print("Enter Author name ");
	   author = kb.nextLine();
	 
	 
	   for( int j=0;j<n;j++)
	   {
	   BOOK book[j] = new BOOK(itemName,author,itemNum,itemQuan );
	   b[j].display();}
}
//System.out.println("Enter �1�, to display the Books: Title � Author � ISBN - Quantity. ");



//int a=kb.nextInt();
//if(a==1)
	
	}}
	

	
		
	
		
		
		  
    	/*	   int a;System.out.println("Enter �1�, to display the Books: Title � Author � ISBN - Quantity. ");
		System.out.println("Enter �2�, to order new books. ");
		System.out.println("Enter �3�, to sell books. ");
		System.out.println("Enter �0�, to exit the system");
		switch(a)
	}
		BOOK books[];
		void sell(String booktitle, int noofcopies)
		{
		

	}

}*/
