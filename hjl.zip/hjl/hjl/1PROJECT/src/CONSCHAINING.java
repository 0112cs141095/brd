class A
{
	A(int l,int b,int h)//3 parameters constructor
	{int i=l;
	int j=b; 
	int k=h;
		
		System.out.println("length="+l+"breadth="+b+"height="+h);}
A()//non parameterized constructor
	{this(0,0,0); //this value is sent to the 3 paramenters constructor
	}

A(int s)//single parameter constructor
{this(s,s,s);//this value is sent to the 3 paramenters constructor
	}}


class CONSCHAINING {
	

	public static void main(String[] args) {
		{ A q=new A();
		 A w=new A(10);
		 A e=new A(10,20,30);
		}
	}}


