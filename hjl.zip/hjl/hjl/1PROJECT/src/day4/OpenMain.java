package day4;


import java.util.Scanner;
class Open
{
	void open()
	{
		System.out.println("parent class method called");
	}
}
class Door extends Open
{
	int noOfGates=2;
	void open()
	{
		System.out.println("open the door!!! .No of gates is"+noOfGates);
	}
}
class Window extends Open
{
	String windowType="Glass Window";
	void open()
	{
		System.out.println("open the window!!!.Window Type is"+windowType);
	}
}
class BankAccount extends Open
{
	String accNo="98765";
	String bankName="SBI";
	void open()
	{
		System.out.println("open a bank account in"+bankName+"acc no is"+accNo);
	}
}
public class OpenMain
{
	public static void main(String[] args)
	{
Door d=new Door();
Window w=new Window();
BankAccount b=new BankAccount();
System.out.println("Choose an option");
Scanner sc=new Scanner(System.in);
System.out.println("1 for opening door");
System.out.println("2 for opening window");
System.out.println("3 for opening bank account");
int n=sc.nextInt();
switch(n)
{
case 1:
	d.open();
	break;
case 2:
	w.open();
	break;
case 3:
	b.open();
	break;
default:
	System.out.println("invalid input");
}
}
}
