import java.util.Scanner;






class Student
{ 
	  Scanner kb=new Scanner(System.in);

     int marks;  
     String name;  
      
            
     Student(int marks,String name)
     {  
   
    	   this.marks=marks;  
           this.name=name;  
           
     }  
     
    
     public  String toString()
     {
     	return "Name: " +name+ " Marks: "+marks  +"\n";
     }
     
     
}  

class StringComparison
{
	 void comparison(Student s1,Student s2)
     {
    	 if(s1.name==s2.name&& s1.marks==s2.marks)
    	 {
    		 System.out.println("equal");
    	 }
    	 else
    		 System.out.println("notequal");
     }
    
	
	 void show(Student s1,Student s2)
     {      String x=s1.name;
     String y=s2.name;
    	 if(x.equals(y)&& s1.marks==s2.marks)
    	 {
    		 System.out.println("equal");
    	 }
    	 else
    		 System.out.println("not equal");
     }
	
	public static void main(String args[])
{
	Student s1=new Student(10,"Ravi");  
	  Student s2=new Student(10,"Ravi"); 
	  
	  StringComparison sc = new  StringComparison();
	  sc.show(s1,s2);
	  sc.comparison(s1, s2);
	  
}}