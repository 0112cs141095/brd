package day2;


import java.util.Scanner;



class Student

{  private String stdname;

private  String stdid;

private int stdgrade;
int year;

Student(String stdid, String stdname, int stdgrade)  

{

    this.stdid=stdid;

    this.stdname=stdname;

    this.stdgrade=stdgrade;
    

}



    Student()

{

    System.out.println("Enter details of the Student");

     System.out.println("===========================");

}

 

Student(String stdid, String stdname)  

{

    this(stdid,stdname,0);

    this.stdname=stdname;

}

Student(String stdid)   

{

    this(stdid,"null",0);

}

void display()

{

    System.out.println("name is "+ stdname+" id is "+ stdid + " grade is "+ stdgrade);

}

void display(int year)

{ 

   
display();
    this.year=year;
    System.out.println( "\nyear is"+ year);
    
}

}

 public class StudMain {

    public static void main(String args[])

    {   
    	Student s=null;
    	System.out.println("1.TO CREATE STUDENT OBJECT");

    System.out.println("2.TO DISPLAY THE STUDENT INFO.");

     System.out.println("*************************");

      System.out.println("ENTER ANY CHOICE");

      Scanner kb=new Scanner (System.in);
      Scanner k=new Scanner (System.in);
      int n=kb.nextInt();

      switch(n)

      {

          case 1:
        	  System.out.println("ENTER THE DETAILS OF STUDENT");
        	  System.out.println("WHICH DETAIL YOU WANT TO ENTER");
        	  System.out.println("1.NAME AND ID\n 2.NAME AND ID AND GRADE\n 3.ID\n ");
           
          
           int x=k.nextInt();
           k.nextLine();
           switch(x)
           {
              
           
        	   case 1:
            System.out.println("ENTER THE NAME OF STUDENT");
                 String name=k.nextLine();
                 System.out.println("ENTER THE ID OF STUDENT");
                 String stdid=k.nextLine();
                 s= new  Student( stdid, name)  ;
                 break;
                
        	   case 2:
                System.out.println("ENTER THE NAME OF STUDENT");
            String sname=k.nextLine();
            System.out.println("ENTER THE ID OF STUDENT");
            String id=k.nextLine();
            System.out.println("ENTER THE NAME OF STUDENT");
            int grade=k.nextInt();
             s= new  Student( id, sname,grade)  ;
             break;
                
                
        	   case 3: 
                System.out.println("ENTER THE ID OF STUDENT");
           String sid=k.nextLine();
           s= new  Student( sid )  ;
           break;
           
                default:
        	   System.out.println("PLEASE ENTER THE CORRECT CHOICE");}
            
           System.out.println("DATA ENTERED!");
           System.out.println("press 2 to display the data");
           int y=k.nextInt();
           if(y!=2)
           break;
           
           
           
          case 2:
            System.out.println("DO YOU WANT TO DISPLAY THE YEAR OF STUDENT?");
           System.out.println("1.yes\n  2.no\n");
          int in=k.nextInt();
          do{
        	  
          
        	  if(in==1)   
          
           { System.out.println("ENTER THE YEAR OF STUDENT");
        	   int year=k.nextInt();
           
               s.display(year);
               }
           else if(in==2)
        	   s.display();
           else
        	   
        	   System.out.println("PLEASE ENTER THE CORRECT CHOICE"); }
          while(n!=1&&n!=2);
        	  
        	  
      }
               
            }
      }

      

    

    

    

