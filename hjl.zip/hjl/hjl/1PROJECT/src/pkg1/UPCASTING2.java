package pkg1;
class base1
{ 
	void print ()
	{
		System.out.println("BASE CLASS");
	}
	void get()
	{
		System.out.println("BASE CLASS SECOND METHOD");
	}
}

	

	class child1 extends base1
	{
		void print ()//overridden method 
		{
			System.out.println(" CHILD CLASS");
		}
		void get()
		{
			System.out.println("CHILD CLASS");
		}
	}

public class UPCASTING2 {
	void show1(base1 b)
    {//CHILD VERSION WILL BE DISPLAYED
		b.get(); //compilation error if method is not present in base class
    	b.print();
			
		}

	public static void main (String[] args) {
		base1 b1=new child1();
		child1 c1=new child1();
		UPCASTING2 u=new UPCASTING2();
		u.show1(c1);//child class version will be diaplyed
		System.out.println("----------");
		u.show1(b1);//child class version will be displayed
		

	}

}
