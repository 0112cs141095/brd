package pkg1;

abstract class SHAPE1
{ int length;  
	int breadth;
SHAPE1()  //non parameterized constructor to instantiate length
	{
 length=10;
	}

SHAPE1(int b){
	breadth = b;
}
	 abstract void area();
	
}
class RECTANGLE extends SHAPE1
{ 
	RECTANGLE()//constructor to call parameterized constructor of shape class
	{ 
		super(20);//breadth=12 is set 
	}
	void area()
	{
		System.out.println("rectangle area" + (length*breadth)); //lenth is assible as it is inherited
		System.out.println("rectangle area");
		
	}
}
class Circle extends SHAPE1
{
	void area()
	{System.out.println("circle area");
		
	}
}

public class AbstractClass {

	public static void main(String[] args) {
		
		SHAPE1 s=new RECTANGLE();
		s.area();
		SHAPE1 s1=new Circle();
		s1.area();
	}

}
