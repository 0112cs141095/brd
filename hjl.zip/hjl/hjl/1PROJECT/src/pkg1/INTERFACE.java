package pkg1;

 interface SHAPE
{ //int b; is not permitted because they are by default final so has to be initialized

	 int  K=10;//is initialized so permitted
	
	 //shape(); is not permitted because no members need to be initialized
	
	void area();

}
 class rectangle implements SHAPE
 {
	  public void area()
	 {
		 //length is accessible as it is inherited
			System.out.println("rectangle area "+ K);
	 }
 }
 
public class INTERFACE {

	public static void main(String[] args){
		SHAPE s=new rectangle();
		s.area();
		
		System.out.println(SHAPE.K);
		

	}

}
