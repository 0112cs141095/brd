

class Z
{
	protected  void show()
	{
		System.out.println("x");
	}
}
class PROTECTED1{

	public static void main(String[] args) {
		
			{  Z b=new  Z();
	b.show(); // WILL  WORK AS SHOW IS A PROTECTED FUNCTION SO IS AVAILABLE 
	}}}
