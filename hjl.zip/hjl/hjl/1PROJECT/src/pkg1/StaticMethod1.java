package pkg1;

class B
{void print ()
{
	System.out.println("nonstatic method in same class");
}

void show()
{print();//same class nonstatic method
System.out.println("nonstatic method");
}
static void display()
{ //print();same class nonstatic method
	System.out.println("static method");
}
}
public class StaticMethod1 {
	

	public static void main( String []args) {
		
	B a=new B ();
	a.show();
	B.display();}

}
