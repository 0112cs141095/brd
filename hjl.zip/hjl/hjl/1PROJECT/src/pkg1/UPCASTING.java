package pkg1;




	class D1
	{
		void print ()
		{
			System.out.println("BASE CLASS");
		}
		
	}

		class E1 extends D1
		{
			void print ()//overridden method 
			{
				System.out.println(" CHILD CLASS");
			}
			void show ()
			{
				System.out.println("BASE CLASS");
			}
		}

	public class UPCASTING {public static void main(String[] args) {
		D1 obj=new E1();//UPCASTING:CAN BE DONE ONLY WHEN THE METHOD IS ALSO PRESENT IN BASE CLASS
	
		obj.print();//CHILD CLASSS METHOD WILL BE CALLED
	
		// obj.show();COMPILATION ERROR AS THE METHOD IS NOT PRESENT THE BASE CLASS
		

	}

}


