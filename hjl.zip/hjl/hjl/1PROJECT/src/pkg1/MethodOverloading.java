package pkg1;

class F
{
	void print (int a)
	{
		System.out.println(a);
	}


	void print (int a,String s)//overloaded method in same class
	{
		System.out.println(a+" "+ s);
	}
}
class G extends F
{
	void print (int a,int age,String s)//overloaded method in inheritance
	{
		System.out.println("class is "+a+"name is "+s+"age is "+age);
	}
}

public class MethodOverloading {

	public static void main(String[] args) {
		F obj=new F();
		obj.print(10);
		G obj1=new G();
		obj.print(10,"ram");
		obj1.print(10,10,"ram");
		obj1.print(10,"ram");//when called by object of g call the method of f
	}

}
