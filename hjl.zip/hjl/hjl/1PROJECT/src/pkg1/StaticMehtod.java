package pkg1;



	
	
	class A
	{
		 static void print ()
		{
			System.out.println("static method in another class");
		}
	}
		
	public class StaticMehtod {
		
	void show()
	{
		System.out.println("nonstatic method");
	}
	static void display()
	{
		System.out.println("static method");
	}
	
	
	
	public static void main(String args[])
	{StaticMehtod v=new StaticMehtod();
		v.show();// called by object becoz it it is nonstatic method
		display();//can be called without object because it is static method in same class
		A.print();//called with classname because it is static method in another class
	}
}


