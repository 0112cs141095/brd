package pkg1;
class base2
{ 
/*	void print ()
	{
		System.out.println("BASE CLASS");
	}*/
void get()
	{
		System.out.println("BASE CLASS SECOND METHOD");
	}
}

	

	class child2 extends base2
	{
		void print ()//overridden method 
		{
			System.out.println(" CHILD CLASS print method");
		}
		/*void get()
		{
			System.out.println("CHILD CLASS get method");
		}*/
	}

public class DOWNCASTING {
	void show1(base2 d){
		d.get();
		if(d instanceof child2)
		{
//		d.print();
		child2 temp;
		temp = (child2)d;
		temp.print();
		}
   /* {
    * //CHILD VERSION WILL BE DISPLAYED
		d.get(); //compilation error if method is not present in base class
    	d.print();
		if(d instanceof child2)
		{d.get(); //compilation error if method is not present in base class
    	d.print();
	*/		
		}

	public static void main (String[] args) 
		{
		base2 b=new base2();
		base2 b1=new child2();
		child2 c1=new child2();
		DOWNCASTING u=new DOWNCASTING();
		u.show1(b);//child class version will be diaplyed
		u.show1(b1);
		
//		System.out.println("---");
//		u.show1(b);System.out.println("---");
//		u.show1(b1);
	}
	}

