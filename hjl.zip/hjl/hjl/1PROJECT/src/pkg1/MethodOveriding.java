package pkg1;

class D
{
	void print ()
	{
		System.out.println("BASE CLASS");
	}
}
	class E extends D
	{
		void print ()//overridden method 
		{
			System.out.println(" CHILD CLASS");
		}
	}
	
public class MethodOveriding {

	public static void main(String[] args) {
		 E obj=new E();
		 obj.print();//child class object is created any method is called
		 
		

	}

}
