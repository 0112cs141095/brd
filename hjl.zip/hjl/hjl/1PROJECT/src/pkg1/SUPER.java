package pkg1;

class H
{
	H()
	{System.out.println("BASE CLASS CONSTRUCTOR");//will be called first
		
	}
	H(int a,int b)
	{
		System.out.println("BASE CLASS PARAMETERIZED  CONSTRUCTOR");
		System.out.println(a+b);
	}
	void print ()
	{
		System.out.println("BASE CLASS");
	}
}
	class  ChildH extends H//constructor is not inherited but is invokrd by the child class object
	{
		void print ()//overridden method 
		{//super(); this is added automatically by the compiler if the constructor is in the child class is not present 
			//print() this will class child class print method and will go into an infifnite loop
			super.print();
			System.out.println(" CHILD CLASS");
		}
		ChildH()
		{ 
			super(10,10);
		}
	}

public class SUPER {

	public static void main(String[] args) {
		ChildH obj=new ChildH();
		obj.print();
	
	}

}
