package pkg1;

public class STRING {
	String str ="HI";
	String str1 ="HI";
	
	

	public static void main(String[] args) {
	

	}

}
