package JDBC;



//import java.sql.Connection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

class User1
{
	String sname;
	String  mail;
	String password;
	User1(String sname,String mail,String password)
	{
        this.sname=sname;  

        this.mail=mail;  

        this.password=password;  

  }  
	
	 public  String toString()

   {

   	return "Name: " +sname+" "+ "email is "+mail+ " "+ "password:"+password +"\n";

   }
	
}

 class JDBC3 {
	Connection con=null;
	void connect()
	{
		try
		{
			
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
	    con=DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
    System.out.println(con); 
    }
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		 catch(SQLException e)
	       {
	    	   e.printStackTrace();
	       }
	}

void signup( User1 u)
{
	  try
	  {
		  
	  
	  PreparedStatement pstmt=con.prepareStatement("SELECT * from Login1 where name='"+u.sname+"'");
	             ResultSet r= pstmt.executeQuery();
	           
	             
         if(r.next())
         {        
      	   System.out.println("user name is already taken");
      	   
      	 
         }
         else
         {   PreparedStatement pstmt1=con.prepareStatement("insert into Login1 values(?,?,?)");
         pstmt1.setString(1,u.sname);
         pstmt1.setString(2,u.mail);
         pstmt1.setString(3,u.password);
         pstmt1.executeUpdate();
        System.out.println("Account Created.....Please sign in"); }
	  }
	  catch(SQLException e)
    {
 	   e.printStackTrace();
 //	System.out.println("******");
    }
	  
}

void signin(User u1)
{
	  try
	  {
			System.out.println("******");
	  
	  PreparedStatement pstmt1=con.prepareStatement("SELECT * from Login1 where name='"+u1.sname+"' and password='"+u1.password+"'");
	  ResultSet r1= pstmt1.executeQuery();
	  if(r1.next())
    {        
 	   System.out.println(" welcome ");
 	   
 	  
    }
	  else
	  {
		  System.out.println("Invalid userid and password");
	  }
	  }
	  catch(SQLException e)
    {
 	   e.printStackTrace();
 	System.out.println("******");
    }
	  catch(NullPointerException e)
	  {
		  e.printStackTrace();
	  }
	  
}


	public static void main(String[] args) {
	     int x;
	     Scanner kb=new Scanner(System.in);
	     JDBC2 j=new JDBC2 ();
	    // j.connect();
		
		do{
		System.out.println("1.SIGN UP");
	   System.out.println("2.SIGN IN");
	   System.out.println("ENTER UR CHOICE");
	
	  x=kb.nextInt();
	
		switch(x)
		{case 1:
			System.out.println("enter ur name");
			  String name=kb.nextLine();
			  kb.nextLine();
			  System.out.println("enter ur email");
			  String id=kb.nextLine();
			  kb.nextLine();
			  System.out.println("enter ur password"); 
			  String pwrd=kb.nextLine();
			  User u=new User(name,id,pwrd);
			
			  j.connect();
		//	  User u=new User("surbh","101","47365745");
			  j.signup(u);
			  break;
			  
	
		case 2:
			 System.out.println("welcome");
			System.out.println("enter ur name");
			  String name1=kb.nextLine();
			  System.out.println("enter ur password"); 
			  String pwrd1=kb.nextLine();
			  User u1=new User(name1,null,pwrd1);
			  j.connect();
			//  User u1=new User("surbhi",null,"47365745");
			  j.signin(u1);
			  break;
		case 3:
			System.exit(0);
		}}
	  while(x!=2||x!=3||x!=0);
	
	
	
		}
	}



