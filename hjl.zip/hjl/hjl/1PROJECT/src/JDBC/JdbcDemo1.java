package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class JdbcDemo1 {

	public static void main(String[] args) {
		Connection con=null;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
	
		PreparedStatement pstmt=con.prepareStatement("select* from BookStore1");
		ResultSet r=pstmt.executeQuery();
		r.next();
		
		int bookid=r.getInt(1);
		String bookname=r.getString(2);
		float price=r.getFloat(3);
		System.out.println("ID: "+   bookid  +"  NAME: "+ bookname + " PRICE: " + price);
		System.out.println("**********************");
	
		  PreparedStatement pstmt2=con.prepareStatement("select * from BookStore1");
		  PreparedStatement  pstmt1=con.prepareStatement("insert into BookStore1 values (?, ? ,?)");
	      pstmt1.setInt (1,1751);
	      pstmt1.setString (2,"alchemist2");
	      pstmt1.setFloat (3,231.7f);
	    
	      int i=  pstmt1.executeUpdate();
	       ResultSet r1=pstmt2.executeQuery();
	       
	       PreparedStatement stmt=con.prepareStatement("delete from BookStore1 where bookid=?");  
	       stmt.setInt(1,2351);  
	        stmt.executeUpdate();  
	        ResultSet r3=pstmt2.executeQuery();
	       
	       
	 
	 while(r1.next())
	  { int bookid1= r1.getInt(1);
	  String bookname1=r1.getString(2);
		float price1=r1.getFloat(3);
	    System.out.println("ID: "+   bookid1  +"  NAME: "+ bookname1+ " PRICE: " + price1);   
	  }		
		
	 System.out.println("**********************");
		
		 
		 while(r3.next())
		  { int bookid1= r3.getInt(1);
		  String bookname1=r3.getString(2);
			float price1=r3.getFloat(3);
		    System.out.println("ID: "+   bookid1  +"  NAME: "+ bookname1+ " PRICE: " + price1);   
		  }		
			}
		
		
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
       catch(SQLException e)
       {
    	   e.printStackTrace();
       }
	
	finally
	{
		try
		{
			con.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
		
	}

}
