
class DEFAULT
{
	void show()
	{ 
		System.out.println("x");
	}
}
class specifier {

	public static void main(String[] args) {
	DEFAULT a=new DEFAULT();
	a.show(); // IS AVAILABLE ANYWHERE IN THE PROGRAM

	}

}