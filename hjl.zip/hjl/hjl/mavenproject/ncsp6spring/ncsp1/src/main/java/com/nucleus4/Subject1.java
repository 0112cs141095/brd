package com.nucleus4;

import com.nucleus3.Branch;

public class Subject1 {
	 private int subId;
	 private String subName;
	
	 
	
	
	@Override
	public String toString() {
		return "Subject1 [subId=" + subId + ", subName=" + subName + "]";
	}
	public int getSubId() {
		return subId;
	}
	public void setSubId(int subId) {
		this.subId = subId;
	}
	public String getSubName() {
		return subName;
	}
	public void setSubName(String subName) {
		this.subName = subName;
	}
}
