package nucleus10.lifecycleannotation;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
   public static void main (String  args[])
   {
AbstractApplicationContext app=new ClassPathXmlApplicationContext("nucleus10.xml");
Student s2=(Student) app.getBean("s3");
System.out.println(s2. getStdId() );
app.registerShutdownHook();





}
}