package lifecycleall;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Main {

	public static void main(String[] args) {
		AbstractApplicationContext app=new ClassPathXmlApplicationContext("lifecycleall.xml");
		Student s2=(Student) app.getBean("s3");
		System.out.println(s2. getStdId() );
		app.registerShutdownHook();
	}

}
