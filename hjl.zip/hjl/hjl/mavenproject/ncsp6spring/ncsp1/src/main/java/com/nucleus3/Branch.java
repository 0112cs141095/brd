package com.nucleus3;

public class Branch {
private String branch;

public String getBranch() {
	return branch;
}

public void setBranch(String branch) {
	this.branch = branch;
}

}
