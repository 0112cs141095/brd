package nucleus11.defaultinit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Student {
	private int stdId;
	 
	
	
	
 public void init()
 {
	 System.out.println("student init method" );
	 
 }


 public void destroy()
 {
	 System.out.println("student destroy method");
	 
 }
 public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
}
