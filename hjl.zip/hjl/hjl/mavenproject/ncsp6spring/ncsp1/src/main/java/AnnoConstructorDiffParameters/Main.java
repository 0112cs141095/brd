package AnnoConstructorDiffParameters;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;





public class Main {

	public static void main(String[] args) {
		ApplicationContext app=new ClassPathXmlApplicationContext("annoconstructor.xml");
		Student s1=(Student) app.getBean("s1");
		System.out.println(s1);

		
	}

}
