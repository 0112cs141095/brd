package com.nucleus;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

class Student {
	
	private int stdId;
	private String stdName;
	public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}

	}




public class Main {

	public static void main(String[] args) {
		ApplicationContext appilacationContext=new ClassPathXmlApplicationContext("springone.xml");
	Student s1=(Student) appilacationContext.getBean("s1");
		System.out.println(s1. getStdId()+" "+s1.getStdName());
		
		
	}

}
