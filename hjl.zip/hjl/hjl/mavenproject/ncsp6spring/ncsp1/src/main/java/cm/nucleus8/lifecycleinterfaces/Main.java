package cm.nucleus8.lifecycleinterfaces;


import com.nucleus2.*;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
   public static void main (String  args[])
   {
AbstractApplicationContext app=new ClassPathXmlApplicationContext("nucleus8.xml");
Student s2=(Student) app.getBean("s2");
System.out.println(s2. getStdId() +" "+s2. getStdName());

app.registerShutdownHook();


}
}