package aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;




public class Main {
public static void main(String args[])
{
	ApplicationContext app=new ClassPathXmlApplicationContext("aop.xml");

	Student s2=(Student)app.getBean("s2");
	System.out.println(s2. getStdId() +" "+s2. getStdName());
	s2.showStudent();
	
	Subject1 sub=s2.getSubject();
	System.out.println(sub.getSubId()+" "+sub. getSubName());
	sub.showSubject();
}
}
