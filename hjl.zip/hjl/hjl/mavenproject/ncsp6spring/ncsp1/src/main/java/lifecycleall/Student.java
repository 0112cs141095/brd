package lifecycleall;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Student   implements InitializingBean, DisposableBean{

	
		private int stdId;
		
		public void init()
		 {
			 System.out.println("student init method1");
		 }
		 public void destroy1()
		 {
			 System.out.println("student destroy method1");
		 }

		
	@PostConstruct	
	 public void x()
	 {
		 System.out.println("student init method");
	 }

	@PreDestroy
	 public void y()
	 {
		 System.out.println("student destroy method");
	 }
	 public int getStdId() {
			return stdId;
		}
		public void setStdId(int stdId) {
			this.stdId = stdId;
		}
		
		public void afterPropertiesSet() throws Exception {
			System.out.println("bean will create");
				
			}
			public void destroy() throws Exception {
			System.out.println("bean destroyed");
				
			}
				}


