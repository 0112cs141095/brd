package aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.JoinPoint.StaticPart;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.SourceLocation;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class aop {
	
	/*@Before("execution(void showStudent())")
	public void beforetest()
	{
		System.out.println("I AM BEFORE STUDENT");
	}
	

	@After("execution(void showStudent())")
	public void aftertest()
	{
		System.out.println("I AM after STUDENT");
	}
	*/
	
	/*@Around("execution(void showStudent())")
	public void aroundtest()
	{
		System.out.println("I AM around STUDENT");

		
        
	}*/
	
	/*@Around("execution(void showStudent())")
	public void aroundtest()
	{
		System.out.println("I AM around STUDENT");

		
        
	}*/

	
	
	/*@Before("execution(* *(..))")
	public void aroundtest2()
	{
		System.out.println("I AM before STUDENT");

		
    }
	*/
	
	/*@Around("execution(void showStudent())")
	public void aroundtest(ProceedingJoinPoint p) throws Throwable
	{
		
		System.out.println("I AM around STUDENT start");
          // p.proceed(); //send method 
       	System.out.println("I AM around STUDENT end");
	}*/
	
	
	@AfterReturning("execution(void showStudent())")

		public void aftertest(JoinPoint j)
	{
		System.out.println("I AM after STUDENT");
		System.out.println(j.getStaticPart());
	}
        
	}
	

