/**
 * 
 */
/**
 * @author temp
 *
 */
package nucleus10.lifecycleannotation;