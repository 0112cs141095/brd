package autowiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Main {

	public static void main(String[] args) {
		ApplicationContext app=new ClassPathXmlApplicationContext("autowiringByType.xml");

		Student s2=(Student) app.getBean("s2");
		System.out.println(s2. getStdId() +" "+s2. getStdName());
		Subject sub=s2.getSubject();
		System.out.println(sub.getSubId()+" "+sub. getSubName());
	}

}
