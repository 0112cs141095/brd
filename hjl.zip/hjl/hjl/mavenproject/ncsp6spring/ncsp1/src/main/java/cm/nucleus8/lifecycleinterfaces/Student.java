package cm.nucleus8.lifecycleinterfaces;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;



public class Student implements InitializingBean, DisposableBean {


	private int stdId;
	private String stdName;
	
	public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public void afterPropertiesSet() throws Exception {
	System.out.println("bean will create");
		
	}
	public void destroy() throws Exception {
	System.out.println("bean destroyed");
		
	}
	
	}


