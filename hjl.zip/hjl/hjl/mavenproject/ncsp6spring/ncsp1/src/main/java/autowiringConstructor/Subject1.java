package autowiringConstructor;

public class Subject1 {
	 
	private int subId;
	 private String subName;
	
	 public Subject1(int subId, String subName) {
			super();
			this.subId = subId;
			this.subName = subName;
		}

	@Override
	public String toString() {
		return "Subject1 [subId=" + subId + ", subName=" + subName + "]";
	}
	 
	
}
