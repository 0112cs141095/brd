/**
 * 
 */
/**
 * @author temp
 *
 */
package cm.nucleus8.lifecycleinterfaces;