package com.nucleus3;



public class Student {
	


		private int stdId;
		private String stdName;
		private Subject1 subject;
		
		
		public Subject1 getSubject() {
			return subject;
		}
		public void setSubject(Subject1 subject) {
			this.subject = subject;
		}
		public int getStdId() {
			return stdId;
		}
		public void setStdId(int stdId) {
			this.stdId = stdId;
		}
		public String getStdName() {
			return stdName;
		}
		public void setStdName(String stdName) {
			this.stdName = stdName;
		}
		
		}


