package com.nucleus5;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Main {
	public static void main(String args[])
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("nucleus5.xml");
	
	Student s1=(Student) app.getBean("s1");
	System.out.println(s1);
 
	}
	
}
