package beanPostProcessor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nucleus2.Student;




public class Main {

	public static void main(String[] args) {
		ApplicationContext app=new ClassPathXmlApplicationContext("beanPostProcessor.xml");
	//	Student s2=(Student) app.getBean("s2");

	}

}
