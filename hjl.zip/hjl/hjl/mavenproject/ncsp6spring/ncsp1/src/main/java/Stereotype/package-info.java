
package Stereotype;