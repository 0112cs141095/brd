package com.nucleus2;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
   public static void main (String  args[])
   {
ApplicationContext app=new ClassPathXmlApplicationContext("nucleus9.xml");

Student s2=(Student) app.getBean("s2");
System.out.println(s2. getStdId() +" "+s2. getStdName());
Subject1 sub=s2.getSubject();
System.out.println(sub.getSubId()+" "+sub. getSubName());


}
}