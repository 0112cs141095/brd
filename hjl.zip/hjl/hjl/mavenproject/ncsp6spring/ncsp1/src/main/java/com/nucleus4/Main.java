package com.nucleus4;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nucleus4.Student;
import com.nucleus4.Subject1;

public class Main {

	public static void main(String[] args) {
		
		ApplicationContext app=new ClassPathXmlApplicationContext("nucleus4.xml");
		Student s2=(Student) app.getBean("s2");
		System.out.println(s2. getStdId() +" "+s2. getStdName());
		List<Subject1> list=s2.getSubject();
		System.out.println(list);

	}

}
