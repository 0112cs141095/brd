package com.nucleus5;

import com.nucleus5.Subject1;

public class Student {
	


		private int stdId;
		private String stdName;
		private Subject1 subject;
		
		
		
		public Student(int stdId, String stdName, Subject1 subject) {
			super();
			this.stdId = stdId;
			this.stdName = stdName;
			this.subject = subject;
		}



		@Override
		public String toString() {
			return "Student [stdId=" + stdId + ", stdName=" + stdName
					+ ", subject=" + subject + "]";
		}



		
		
		}


