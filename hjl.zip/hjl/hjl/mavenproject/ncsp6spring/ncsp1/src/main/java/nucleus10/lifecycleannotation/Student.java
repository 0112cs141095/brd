package nucleus10.lifecycleannotation;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Student {
	private int stdId;
	
@PostConstruct	
 public void x()
 {
	 System.out.println("student init method");
 }

@PreDestroy
 public void y()
 {
	 System.out.println("student destroy method");
 }
 public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
}
