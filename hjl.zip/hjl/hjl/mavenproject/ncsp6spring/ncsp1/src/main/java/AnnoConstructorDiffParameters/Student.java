package AnnoConstructorDiffParameters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;


public class Student {
	


		private int stdId;
		private String stdName;
		private Subject1 subject;
		
		
		@Autowired
		
		public Student(int stdId, String stdName, Subject1 subject) {
			super();
			this.stdId = stdId;
			this.stdName = stdName;
			this.subject = subject;
		}



		@Override
		public String toString() {
			return "Student [stdId=" + stdId + ", stdName=" + stdName
					+ ", subject=" + subject + "]";
		}



		
		}


