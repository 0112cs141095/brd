package com.nucleus.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;






@Entity
@Table(name="chiber143")
public class Customer implements Serializable {

@Id
@Column(name="cusid143")
private	long customerId;


@Column(name="cuscd143")
private String date;

@Column(name="cusmd143")
private String  modifiedDate;

public long getCustomerId() {
	return customerId;
}

public void setCustomerId(long customerId) {
	this.customerId = customerId;
}

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public String getModifiedDate() {
	return modifiedDate;
}

public void setModifiedDate(String modifiedDate) {
	this.modifiedDate = modifiedDate;
}






	}


