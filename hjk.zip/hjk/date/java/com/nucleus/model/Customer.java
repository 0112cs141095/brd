package com.nucleus.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;






@Entity

@Table(name="chibernate143")
public class Customer implements Serializable {

@Id
@Column(name="custid143")
private	long customerId;

@Column(name="custcode143")
@Length(min=1, max=10,message="length must be btwn 1 to 10")
private String	customerCode;

@Column(name="custname143")
@NotEmpty @Pattern(regexp="^[a-zA-Z\\s]*$")@Length(min=1, max=20,message="length must be btwn 1 to 20")
private String customerName;

@Column(name="custaddress1")
@NotEmpty @Length(min=1, max=20,message="length must be btwn 1 to 20")
private String customerAddress1;

@Column(name="custaddress2")
@Length( max=20,message="length must be smaller than 20")
private String customerAddress2;

@Column(name="custpin143")
@NotEmpty @Length(min=6, max=6,message="length must be equal to 6")  @Pattern(regexp="^[0-9]*$")
private String pin;

@Column(name="custmail143")
@NotEmpty @Email @Length(min=8, max=20,message="length must be greater than 8")
private String mailId;

@Column(name="custnumber143")
@NotEmpty @Length(min=10, max=10,message="length must be equal to 10")  @Pattern(regexp="^[0-9]*$")
private String contactNumber;

@Column(name="custcp143")
@NotEmpty @Length(min=1, max=20,message="length must be btwn 1 to 20")
private String contactPerson;

@Column(name="custrs143")
private String recordStatus;

@Column(name="custcd143")
private String date;

@Column(name="custcb143")
private  String createdBy;
@Column(name="custmd143")
private String  modifiedDate;
@Column(name="custmb143")
private  String modifiedBy;



public String  getPin() {
	return pin;
}
public void setPin(String  pin) {
	this.pin = pin;
}

public String getRecordStatus() {
	return recordStatus;
}
public void setRecordStatus(String recordStatus) {
	this.recordStatus = recordStatus;
}

public String getModifiedDate() {
	return modifiedDate;
}
public void setModifiedDate(String modifiedDate) {
	this.modifiedDate = modifiedDate;
}

public long getCustomerId() {
	return customerId;
}
public void setCustomerId(long customerId) {
	this.customerId = customerId;
}
public String getCustomerCode() {
	return customerCode;
}
public void setCustomerCode(String customerCode) {
	this.customerCode = customerCode;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getCustomerAddress1() {
	return customerAddress1;
}
public void setCustomerAddress1(String customerAddress1) {
	this.customerAddress1 = customerAddress1;
}
public String getCustomerAddress2() {
	return customerAddress2;
}
public void setCustomerAddress2(String customerAddress2) {
	this.customerAddress2 = customerAddress2;
}
public String getMailId() {
	return mailId;
}
public void setMailId(String mailId) {
	this.mailId = mailId;
}
public String getContactNumber() {
	return contactNumber;
}
public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}
public String getContactPerson() {
	return contactPerson;
}
public void setContactPerson(String contactPerson) {
	this.contactPerson = contactPerson;
}

public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date =  date;
}
public String getCreatedBy() {
	return createdBy;
}
public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}
public String getModifiedBy() {
	return modifiedBy;
}
public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
}
@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", customerCode="
			+ customerCode + ", customerName=" + customerName
			+ ", customerAddress1=" + customerAddress1 + ", customerAddress2="
			+ customerAddress2 + ", pin=" + pin + ", mailId=" + mailId
			+ ", contactNumber=" + contactNumber + ", contactPerson="
			+ contactPerson + ", recordStatus=" + recordStatus + ", date="
			+ date + ", createdBy=" + createdBy + ", modifiedDate="
			+ modifiedDate + ", modifiedBy=" + modifiedBy + "]";
}







	}


