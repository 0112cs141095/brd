package com.nucleus.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nucleus.dao.UserDao;
import com.nucleus.model.User;

@Service
public class UserServiceImp implements UserService{

	@Autowired
	UserDao userdao;
	
	@Override
	public String insert(User user,int i) {
		String str=userdao.insert(user,i);
		return  str;
	}

}
