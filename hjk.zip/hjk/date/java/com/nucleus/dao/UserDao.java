package com.nucleus.dao;

import com.nucleus.model.Customer;
import com.nucleus.model.User;

public interface UserDao {
	public String insert(User user,int i);
}
