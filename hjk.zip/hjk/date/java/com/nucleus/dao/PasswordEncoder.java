package com.nucleus.dao;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordEncoder {

	
	public String encodepwd(String pwd)
	{
		BCryptPasswordEncoder bcrypt=new BCryptPasswordEncoder();
		return bcrypt.encode(pwd);
	}
}
