package com.nucleus.dao;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.model.Customer;
import com.nucleus.model.Role;
import com.nucleus.model.User;

@Repository
public class UserDaoImp implements UserDao {

	@Autowired
	SessionFactory sf;
	
	Role r=new Role();
	
	@Transactional
	@Override
	public String insert(User user,int i) {
		 
		
		
		try{
			String s=user.getUsername();
			 Criteria criteria=sf.getCurrentSession().createCriteria(User.class);
				
			 Criteria criteria1= criteria.add(Restrictions.eq("username",s));
			 
			 User result	 =(User)criteria1.uniqueResult();
			if(result==null)
			{
				
			
			 
			 String pwd=user.getPassword();
		   PasswordEncoder p=new PasswordEncoder();
		   pwd=p.encodepwd(pwd);
			user.setPassword(pwd);
			user.setEnabled(1);
		
			 
				
				if(i==1)
				{
					r.setRoleid(1);
					r.setRole("ROLE_ADMIN");
					
				}
				else if(i==2)
				{
					r.setRoleid(2);
					r.setRole("ROLE_USER");
				}
			
			
		
			user.setRole(r);
		
		sf.getCurrentSession().save(user);
		return "saved";
			}
			else
			{
				return "null";
			}
		
        
	}
	catch(Exception e)
	{
		e.printStackTrace();
		return "null";
		
	}
	}

}
