package com.nucleus.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.dao.CustomerDaoImp;
import com.nucleus.model.Customer;
import com.nucleus.model.User;
import com.nucleus.service.CustomerService;
import com.nucleus.service.UserService;
/*import com.nucleus.service.UserService;
*/

@Controller
public class UserController {
	
	@Autowired
	UserService userservice;
	
	
	@RequestMapping("/adduser")
	public String adduser(User user)
	{
		return "adduser";
	}
	@RequestMapping("/addadmin")
	public String addadmin()
	{
		return "addadmin";
	}	
	
	@RequestMapping("/addusersubmit")
	public String adduser1(User user,BindingResult result)
	{
		if(result.hasErrors())
		{System.out.println( "***********");
		return "adduser";}
	
	else
	{ 
		
	String yes= userservice.insert(user,2);
	if(yes.equals("saved"))
	return "completed";
	
	else if(yes.equals("null"))
		return "error";}
		return "error";
		
	}
	
	@RequestMapping("/addadminsubmit")
	public String addadmin1(User user,BindingResult result)
	{
		if(result.hasErrors())
		{System.out.println( "***********");
		System.out.println("mfgmfg");
		return "addadmin";}
	
	else
	{ 
		System.out.println("mfgmfg");
	String yes= userservice.insert(user,1);
	if(yes.equals("saved"))
	return "completed";
	
	else
		return "error";}
		
	}

	
/*	@Autowired
	UserService userservice;
	

	@Autowired
	CustomerService customerservice;
	
	@RequestMapping("/link1")
	public String handler(User user)
	{
		return"Login";
	}
	
	@RequestMapping("/Login")
	public String  handler1(@Valid User user,BindingResult result)
	{
		if(result.hasErrors())
			return "Login";
		
		else
		{		String yes=userservice.login(user);
		if(yes.equals("valid"))
		return "Maker";
		
		else
			return "error";}
	}
	*/
	/*@RequestMapping("/new")
	public String  newcustomer(Customer customer)
	{
		
		
		return "Customer";
		
		
	}
	
	
	@RequestMapping("/customersubmit")
	public String  handler2(@Valid Customer customer,BindingResult result)
	{
		if(result.hasErrors())
			{System.out.println( "***********");
			return "Customer";}
		
		else
		{ Date date=new Date();
			String d=new SimpleDateFormat("dd-MMM-yyyy").format(date);
			System.out.println(d);
			customer.setDate(d);
			
		String yes= customerservice.insert(customer);
		if(yes.equals("saved"))
		return "completed";
		
		else
			return "error";}
	}
	
	@RequestMapping("/delete")
	public String  deletecustomer(Customer customer)
	{
		
		
		return "Delete";
		
		
	}
	
	@RequestMapping("/deletesubmit")
	public String  delete(@Valid Customer customer,BindingResult result)
	{
		
		
		if(result.hasErrors())
			return "Delete";
		
		else
		{
		String yes= customerservice.delete(customer);
		
		
		
		
		if(yes.equals("deleted"))
			return "completed";
			
			else
				return "error";}
		}
	
	@RequestMapping("/viewbyid")
	public String  viewbyid(Customer customer)
	{
		
		
		return "ViewById";
		
		
	}
	
	
	@RequestMapping("/viewsubmit")
	public  ModelAndView viewid( @Valid Customer customer,BindingResult result)
	{
		
		if(result.hasErrors())
			return  new  ModelAndView ("ViewById");
		
		else
		{
			
		
		Customer c1= customerservice.show1(customer);
		if(c1.getCustomerCode()==null)
		{
			return new ModelAndView("error");
		}
		
		
		
			
			
			else
					{List<Customer>l=new ArrayList();
					l.add(c1);
				return new ModelAndView("viewall","list",l);}
		}}
	
	@RequestMapping("/viewall")
	public   ModelAndView viewall(Customer customer)
	{
		
		List<Customer>l= customerservice.show();
		if(l!=null)
		{
			return new ModelAndView( "viewall","list",l);
		}
		else
			return new ModelAndView("error");
	}	
		
		@RequestMapping("/update")
		public String  updateid(Customer customer)
		{
			
			
			return "updateId";
			
			
		}
		
		@RequestMapping("/updatesubmit")
		public   ModelAndView update( @Valid Customer customer,BindingResult result)
		{
			
			if(result.hasErrors())
				return  new  ModelAndView ("updateId");
			
			else
				{
				Customer c1= customerservice.show1(customer);
				System.out.println(c1);
				
			if(c1.getCustomerCode()==null)
			{
				return new ModelAndView("error");
			}
			
			
			
				
				
				else
						{
				
					return new ModelAndView("update","c",c1);}
			}
		
		
}
		
		@RequestMapping("/updatesubmit2")
public String  edit(Customer customer)
{
			
			
			
			System.out.println("vhesdvcvsvcsvcsdvd");
			System.out.println(customer.getDate());
			
			Date date=new Date();
			String d=new SimpleDateFormat("dd-MMM-yyyy").format(date);
			System.out.println(d);
			customer.setModifiedDate((d));
			
			
			
			
String str= customerservice.update(customer);
	
if(str.equals("null"))
	return "error";
else
	return "completed";
	
}
		*/
	
	
	@RequestMapping("/accdenied")
		public String handler()
		{
			return "error";
		}
		
		@RequestMapping("/login")
		public String handler1()
		{
			return "Login";
		}
		
		@RequestMapping("/failure")
		public ModelAndView handler3()
		{
			System.out.println("&&&&&&&&&&&&&&&&");
			
			String str="INVALID NAME OR PASSWORD";
			return new  ModelAndView ("Login","error",str);
		}
		
		@RequestMapping("/defaulttarget")
		public String handler6(HttpServletRequest request)
		{
			
			String target;
			
			 if(request.isUserInRole("ROLE_USER"))
			{
				target="redirect:/user";
			}
			else if(request.isUserInRole("ROLE_ADMIN"))
			{
				target="redirect:/admin";
			}
			else
				{System.out.println("&%##^&%$##%%%");
				target="redirect:/error";}
			
			return target;
		}
	
		@RequestMapping("/user")
		public String makerpage()
		{      
			return "Maker";
		}
		
		
		
	
		@RequestMapping("/logout")
		public String logout()
		{
			return "Login";
		
}
		@RequestMapping("/admin")
		public String admin()
		{
			return "Register";
		}
}	
		
	
