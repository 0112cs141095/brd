package com.nucleus;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;



public class CustomerMain {

	public static void main(String[] args) {

		EntityManagerFactory fact=Persistence.createEntityManagerFactory("std1");
		EntityManager em=fact.createEntityManager();
		
		EntityTransaction t=em.getTransaction();
		t.begin();


Customer c=new Customer();
c.setCusid(2);
c.setName("rohit");


Customer c1=new Customer();
c1.setCusid(1);
c1.setName("rohan");

//===================to save======================
em.persist(c);
em.persist(c1);
em.
//=========================view all============================
/*Query query=em.createQuery("from Customer");
List<Customer>cus=query.getResultList();
System.out.println(cus);*/
//============================view one===================



/*Query query1=em.createQuery("from Customer where name=?");
query.setParameter(0,"rohan");
Customer ck=(Customer)query1.getSingleResult();
System.out.println(ck);*/
t.commit();
	}

}
