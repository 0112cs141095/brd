package com.nucleus;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;




@Entity
@Table(name="ccccc1")
public class Customer {

	@Id
	@Column(name="customerbfgid")
	private int cusid;
	private 	String name;

	
	
	
	@Override
	public String toString() {
		return "Customer [cusid=" + cusid + ", name=" + name + "]";
	}
	public int getCusid() {
		return cusid;
	}
	public void setCusid(int cusid) {
		this.cusid = cusid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

	
}
