package com.nucleus.errorlog;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ErrorLog {

	
		
			public void saveToFile(String line) throws IOException
			{
				FileWriter filewriter = null;
				try {
					filewriter = new FileWriter("errorgf.txt",true);
					
					filewriter.write(line+"\n");
					filewriter.flush();
				}
				catch (IOException e) {
					e.printStackTrace();
				}
					finally
					{
						filewriter.close();
					}
			}
		}

	


