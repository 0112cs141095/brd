package com.nucleus.DAO;

///import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.nucleus.connection.ConnectionSetup;
import com.nucleus.domain.CustomerInfo;
import com.nucleus.errorlog.ErrorLog;

public class CustomerDao implements CustomerDaoI {
	Connection con1;
	
	
public  void insertRecord(CustomerInfo c) throws SQLException
	
	{    
	 
		try
		{   
			if(con1==null)
			{
				ConnectionSetup connectionSetup=new ConnectionSetup();
				con1=connectionSetup.getConnection();
			}
			con1.setAutoCommit(false);
			//con1.setAutoCommit(false);
		
		System.out.println(con1);
		
		PreparedStatement pstmt=con1.prepareStatement("insert into customer143 values(sa1.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		

		pstmt.setString(1,c.getCustomerCode());
		pstmt.setString(2,c.getCustomerName());
		pstmt.setString(3,c.getCustomerAddress1());
		pstmt.setString(4, c.getCustomerAddress2());
	                   
		pstmt.setInt(5,c.getPin());
		pstmt.setString(6,c.getMailId());
		pstmt.setLong(7,c.getContactNumber());
		pstmt.setString(8,c.getContactPerson());
		pstmt.setString(9,c.getRecordStatus());
		pstmt.setString(10,c.getFlag());
		pstmt.setString(11,c.getDate());
		pstmt.setString(12,c.getCreatedBy());
		pstmt.setString(13,c.getModifiedDate());
		pstmt.setString(14,c.getModifiedBy());
		pstmt.setString(15,c.getAuthorizedDate());
		pstmt.setString(16,c.getAuthorizedBy());
		pstmt.executeUpdate();
		System.out.println("saved");
		
	         
		}
		catch(SQLException e)
		{
			System.out.println("Invalid value");
		}
		
	}


public void  filelog(String l) throws IOException ,SQLException
{ 
	BufferedReader bufferedreader=null;
	try{
	ErrorLog e=new ErrorLog();
	  FileReader filereader= new FileReader(l);
	 
	 
	 bufferedreader=new BufferedReader(filereader);

	String  line=bufferedreader.readLine();

              
    System.out.println(line);
                   while(line!=null)

                { 
                   
                         e.saveToFile(line);
                         line=bufferedreader.readLine();
                }
                   roll();
                   }
finally
{
	System.out.println("record Saved");
	bufferedreader.close();

	
}
}

public void roll() throws SQLException{
	
	con1.rollback();
	System.out.println("Rolled back");
}
public void commit(char choice,int n) throws SQLException
{
	if(choice=='R')
	{
		con1.commit();
	}
	else if(choice=='F'&& n==10)
	{
		con1.commit();
	}
}

	}

	
	
	


