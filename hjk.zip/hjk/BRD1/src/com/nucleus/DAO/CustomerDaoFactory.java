package com.nucleus.DAO;

public class CustomerDaoFactory {

	
		
		public static  CustomerDaoI getCustomerImpl(String impType)
		{
			if(impType.equals("rdbms"))
			{
				
				return new CustomerDao()  ;
			}
			else
				return null;
			
		}
	
	}


