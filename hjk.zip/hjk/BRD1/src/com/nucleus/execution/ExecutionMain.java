package com.nucleus.execution;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import com.nucleus.DAO.CustomerDao;
import com.nucleus.DAO.CustomerDaoFactory;
import com.nucleus.DAO.CustomerDaoI;


public class ExecutionMain  {
	
	
	public static void main(String[] args) throws IOException, SQLException {
	
		Execution customerdaoi = new Execution();
		
		Scanner kb=new Scanner(System.in);
    System.out.println("Enter the file path");
	String path=kb.nextLine();
	
	int n=1;
	String l=null;
	do{
	System.out.println("Enter the name of the file NAME ");
	String fname=kb.nextLine();
	
	if(fname.endsWith(".txt"))
	{
         l=path.concat("\\"+fname);	
          n=2;
	}
	else
	{
		System.out.println("enter file with .txt extension");
		
	}}while(n==1);
	
	
	
	System.out.println("Enter the rejection level");
	System.out.println(" R - if Record Level rejection is followed.");
       System.out.println("F � if File level rejection is followed");
       char choice=kb.next().charAt(0);
		
       switch(choice)
       {
       case 'R':  customerdaoi . readFromFile(l,choice);
       break;
    	   
       case 'F':    customerdaoi.readFromFile(l, choice);

       }
	    



		

}}