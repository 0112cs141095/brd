package com.nucleus.DAO;

import com.nucleus.domain.User;

public interface UserDao {
	  public  String login(User user);
}
