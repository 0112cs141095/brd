package com.nucleus.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.ConnectionSetup;
import com.nucleus.domain.User;

public class UserDaoImp implements UserDao {
	
	ConnectionSetup connectionSetup=new ConnectionSetup();
	 Connection con1=connectionSetup.getConnection();
	
		
		
		
	      public  String login(User user) {
		
	       try
	       {
	    	   boolean more=false;
	    	   
	    	   System.out.println("22222222222222");
	       
		
	         String username = user.getUsername();    
	         String password = user.getPassword();   
		    
	     	PreparedStatement stmt1=con1.prepareStatement("select * from user0143 where NAME=? and PASSWORD=?"); 
	     	 stmt1.setString (1,username);
	     	 stmt1.setString (2,password);
	  	   ResultSet r1=stmt1.executeQuery();
	  	   
	  	   more=r1.next();
	  	   
	  		 System.out.println(more);
	  		  
  		
	  	 
	  
	  	 if (!more) 
         {
            System.out.println("Sorry, you are not a registered user! Please sign up first");
             return "not valid";
         } 
	  	 else if (more) 
         { System.out.println("333333333");
            user.setValid(true);
	  		String role1=checkRole(user);
	  		return role1;
         }
	       }
	  	 catch (SQLException e) {
				
				e.printStackTrace();
			}
		return null;
			
	       }
	      
	      


	      public String checkRole(User user)
	      { try{
	    	  
	     
	    	  String sql="select user0143.name,user0143.password,role143.r_name from user0143 Inner join role143 ON user0143.ROLEID=role143.ROLEID";
	    	  PreparedStatement stmt1=con1.prepareStatement(sql);
	    	  ResultSet r2=stmt1.executeQuery();
	    	  r2.next();
	    	 String role= r2.getString(3);
         System.out.println(role);
        return role;
	      }
	      catch (SQLException e) {
				
				e.printStackTrace();
			}
		return null;
			

	
}}
