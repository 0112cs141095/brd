package com.nucleus.DAO;

import java.util.List;

import com.nucleus.domain.Customer;

public interface CustomerDao {
	public void insert(Customer c);
	 public void delete(String s);
	 public List view(String id);
}
