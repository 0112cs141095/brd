package com.nucleus.DAO;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpSession;



import com.nucleus.connection.ConnectionSetup;
import com.nucleus.domain.Customer;


public class CustomerDaoImp implements CustomerDao{
	
	ConnectionSetup connectionSetup=new ConnectionSetup();
	Connection	con1=connectionSetup.getConnection();
	
	public void insert(Customer c)
	{
		try{
	

	PreparedStatement pstmt=con1.prepareStatement("insert into customer143 values(sa1.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			System.out.println("*************");
	
			pstmt.setString(1,c.getCustomerCode());
			pstmt.setString(2,c.getCustomerName());
			pstmt.setString(3,c.getCustomerAddress1());
			pstmt.setString(4, c.getCustomerAddress2());
			System.out.println("*************");            
			pstmt.setInt(5,c.getPin());
			pstmt.setString(6,c.getMailId());
			pstmt.setLong(7,c.getContactNumber());
			pstmt.setString(8,c.getContactPerson());
			System.out.println("*************");
			pstmt.setString(9,c.getRecordStatus());
			pstmt.setString(10,c.getFlag());
			System.out.println("*************");
			pstmt.setString(11,c.getDate());
			System.out.println("*************");
			pstmt.setString(12,c.getCreatedBy());
			pstmt.setString(13,c.getModifiedDate());
			pstmt.setString(14,c.getModifiedBy());
			pstmt.setString(15,c.getAuthorizedDate());
			pstmt.setString(16,c.getAuthorizedBy());
			System.out.println("*************");
			pstmt.executeUpdate();
			System.out.println("saved");
			
		         
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				//System.out.println("Invalid value");
			}
		finally{
			try {
				con1.close();
			} 
			catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
			
		}
	 public void delete(String s)
	 {
		 try{
		 PreparedStatement pstmt1=con1.prepareStatement("delete from customer143 where CODE=?");
		 pstmt1.setString(1,s);
		 pstmt1.executeUpdate();
		 System.out.println("deletd");
		 
}
		 catch(SQLException e)
			{
				e.printStackTrace();
				//System.out.println("Invalid value");
			}
		 finally{
				try {
					con1.close();
				} 
				catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
}
	 
	 public List  view(String id)
	 {PreparedStatement pstmt1;
		 try
		 {System.out.println(id);  
		 if(id.equals("no"))
		 {
			  pstmt1=con1.prepareStatement("select * from customer143");
		 }
		 else
			 {pstmt1=con1.prepareStatement("select * from customer143 where CODE=?");
		 pstmt1.setString(1,id);}
		
		 List <Customer> list= new ArrayList<>();
		 
		 pstmt1.setString(1,id);
		 ResultSet r1= pstmt1.executeQuery();
		 while(r1.next())
		 {
			 Customer c=new Customer();
			
			c.setCustomerCode(r1.getString(2));
			System.out.println(c.getCustomerCode());
			 c.setCustomerName(r1.getString(3));
			  c.setCustomerAddress1(r1.getString(4));
			  c.setCustomerAddress2(r1.getString(5));
				System.out.println("*************");            
				  c.setPin(r1.getInt(6));
				  c.setMailId(r1.getString(7));
				  c.setContactNumber(r1.getLong(8));
				  c.setContactPerson(r1.getString(9));
				System.out.println("*************");
				c.setRecordStatus(r1.getString(10));
				  c.setFlag(r1.getString(11));
				System.out.println("*************");
				 c.setDate(r1.getString(12));
				System.out.println("*************");
				 c.setCreatedBy(r1.getString(13));
				 c.setModifiedDate(r1.getString(14));
				 c.setModifiedBy(r1.getString(15));
				 c.setAuthorizedDate(r1.getString(16));
				 c.setAuthorizedBy(r1.getString(17));
				System.out.println("*************");
				pstmt1.executeQuery();
			
				list.add(c);
				System.out.println(list);
				
	 }
		 return list;
	 } catch(SQLException e)
		{
			e.printStackTrace();
			//System.out.println("Invalid value");
		}
	 finally{
			try {
				con1.close();
			} 
			catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		return null;	}
	 
	        
	    
	 

}


