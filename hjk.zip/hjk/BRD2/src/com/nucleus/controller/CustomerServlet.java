package com.nucleus.controller;



import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import com.nucleus.DAO.CustomerDao;
import com.nucleus.DAO.CustomerDaoImp;
import com.nucleus.domain.Customer;


/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("/CustomerServlet")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("iufgiacsgfosvbao");
		
		response.getWriter().println("gcivufeviuf");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	System.out.println("***********");
		PrintWriter out=response.getWriter();
		
		CustomerDao customerDao=new CustomerDaoImp();
		if(request.getParameter("customersubmit")!=null)
		{
			Customer c=new Customer();
        	c.setCustomerCode(request.getParameter("code"));
       
        c.setCustomerName(request.getParameter("name"));
        c.setCustomerAddress1(request.getParameter("address1"));
        c.setCustomerAddress2(request.getParameter("address2"));
        c.setPin(Integer.parseInt(request.getParameter("pin")));
        c.setMailId(request.getParameter("email"));
        c.setContactNumber(Long.parseLong(request.getParameter("cnum")));
        c.setContactPerson(request.getParameter("cperson"));
        c.setRecordStatus("N");
      c.setFlag("A");
        
        
        String date=new SimpleDateFormat("dd-MMM-yyyy").format(Calendar.getInstance().getTime());
        System.out.println(date);
        c.setDate(date);
        
        HttpSession session = request.getSession(false);	    
      String name=  (String) session.getAttribute("currentSessionUser"); 
        c.setCreatedBy(name);
        c.setModifiedDate("");
        c.setModifiedBy("fgjghj");
        
        c.setAuthorizedDate(request.getParameter("gghgh"));
        c.setAuthorizedBy(request.getParameter("hjghjgh"));
       System.out.println(c);
        customerDao.insert(c);
        
    
		}
		
		
		if(request.getParameter("deleteid")!=null)
		{
			customerDao.delete(request.getParameter("dcode"));
		}
		
		if(request.getParameter("viewbyid")!=null)
		{
			System.out.println("**********");
			List<Customer> list=customerDao.view(request.getParameter("viewbox"));
			
			for(Customer books:list)
			  out.println(books+"\n");  
			request.setAttribute("c", list);
			request.getRequestDispatcher("viewall.jsp").forward(request, response);
		}
		if(request.getParameter("vit")!=null)
		{
			System.out.println("***********");
			List<Customer> list=customerDao.view("no");
			for(Customer books:list)
				  out.println(books+"\n");  
			request.setAttribute("c", list);
			request.getRequestDispatcher("viewall.jsp").forward(request, response);
		}
		
	}

}
