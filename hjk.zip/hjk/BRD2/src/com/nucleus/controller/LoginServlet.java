package com.nucleus.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.DAO.UserDao;
import com.nucleus.DAO.UserDaoImp;
import com.nucleus.domain.User;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		UserDao userDao=new UserDaoImp();
	    User user = new User();
	    System.out.println("11111111111");
	   
	    user. setUsername(request.getParameter("username"));
	     user.setPassword(request.getParameter("password"));

	     System.out.println(user);
	   String str=  userDao.login(user);
	     
		   		if(str.equals("maker"))
		   		{
		   			request.getRequestDispatcher("Maker.jsp").forward(request, response);
		   		}
		   		
		   		else if(str.equals("checker"))
		   		{
		   			request.getRequestDispatcher("Checker.jsp").forward(request, response);
		   		}
		   		else if(str.equals("not valid"))
		   		{
		   			request.getRequestDispatcher("Register.jsp").forward(request, response);
		   		}
	    if (user.isValid())
	     {
	    	String username=user.getUsername();
		        System.out.println("valid");
	          HttpSession session = request.getSession(true);	    
	          session.setAttribute("currentSessionUser", username); 
	       //   response.sendRedirect("userLogged.jsp"); //logged-in page      		
	     }
		        
	     else 
	          response.sendRedirect("invalidLogin.jsp"); //error page 
	
			
			

	       }
}
