import java.text.SimpleDateFormat;
import java.util.Calendar;


public class vjljd {

	public static void main(String[] args) {
		 String date=new SimpleDateFormat("dd-MM-yyyy").format(Calendar.getInstance().getTime());
	        System.out.println(date);
	}

}
