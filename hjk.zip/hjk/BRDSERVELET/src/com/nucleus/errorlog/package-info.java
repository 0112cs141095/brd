/**
 * 
 */
/**
 * @author temp
 *
 */
package com.nucleus.errorlog;