package com.nucleus.DAO;

import java.io.IOException;
import java.sql.SQLException;

import com.nucleus.model.CustomerInfo;

public interface CustomerDaoI 
{
	public  void insertRecord(CustomerInfo c) throws SQLException;
	public void  filelog(String l)throws IOException ,SQLException ;
	public void roll()throws SQLException;
	public void commit(char choice,int n) throws SQLException;
 
	// public void readFromFile(String l,char choice);
}