package com.nucleus.execution;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nucleus.DAO.CustomerDao;
import com.nucleus.DAO.CustomerDaoFactory;
import com.nucleus.DAO.CustomerDaoI;
import com.nucleus.connection.ConnectionSetup;
import com.nucleus.errorlog.ErrorLog;
import com.nucleus.model.CustomerInfo;
import com.nucleus.validation.Validation;



public class Execution1  {
	int num=0;
	 int n1=0;
		BufferedReader bufferedreader;
	
	public void readFromFile( String l ,char choice) throws IOException 

	{  
		
		FileReader filereader;
	   Execution e1=new Execution();
	   ErrorLog elog=new ErrorLog();
	    String line=null;
	    int n=0;

	    CustomerDaoI customerdao = CustomerDaoFactory.getCustomerImpl("rdbms");
		
	    try

		{ System.out.println("******");

		 filereader= new FileReader(l);
		 
		 
			bufferedreader=new BufferedReader(filereader);

			 line=bufferedreader.readLine();

                      
                           while(line!=null)

                        { 
                               System.out.println(line);

       String[] information= line.split("~",-1);

        
                    	
                    	CustomerInfo c=new CustomerInfo();
                    	c.setCustomerCode(information[0]);
                   
                    c.setCustomerName(information[1]);
                    c.setCustomerAddress1(information[2]);
                    c.setCustomerAddress2(information[3]);
                    c.setPin(Integer.parseInt(information[4]));
                    c.setMailId(information[5]);
                    c.setContactNumber(Long.parseLong(information[6]));
                    c.setContactPerson(information[7]);
                    c.setRecordStatus(information[8]);
                    c.setFlag(information[9]);
                    c.setDate(information[10]);
                    c.setCreatedBy(information[11]);
                    c.setModifiedDate(information[12]);
                    c.setModifiedBy(information[13]);
                    
                    c.setAuthorizedDate(information[14]);
                    c.setAuthorizedBy(information[15]);
                   
                   
                    
                    Validation v=new Validation();
                         
   
                    if(v.checkCode(c.getCustomerCode()))
                   
                    	if(v.checkNull(information))
                    
                    	if(v.checkName(c.getCustomerName()))
                    	
                    		if(v.checkPinCode(c.getPin()))

                    			if(v.checkEmailFormat(c.getMailId()))

                    				if(v.checkRecordStatus(c.getRecordStatus()))

                    					if(v.checkFlag(c.getFlag()))

                    						if(v.checkContact(c.getContactNumber()))

                    							if(v.checkCode(c.getCustomerCode()))	

                    							{
                                                          n1++;
                    							 	
                    							    customerdao. insertRecord(c);
                    								 customerdao.commit(choice,n1);
                    								 line=bufferedreader.readLine();
                    							}

                    							else

                    							{
                    								     if(choice=='R')
                    								     { elog.saveToFile(line+"----->error in code");
                    								     line=bufferedreader.readLine();
                    								 }
                    								     else
                    								     {  n1=0;
                    								    	 customerdao.filelog(l);
                    								    	 
                    								    	 System.out.println("error in code");
                    								     break;}
                    								
                    								     
                    								     // .flush();

                    							}

                    					else
                                                                    {
                    							 if(choice=='R')
                    							{elog.saveToFile(line+"-------------->error in contact number");
                    							 line=bufferedreader.readLine();}
                    							 else
            								     {  n1=0;
            								    	 customerdao.filelog(l);
            								    	 
            								    	 System.out.println("error in contact number");
            								     break;}
                                                                //    out.flush();

                                                                    }

                    				else
                    					{	if(choice=='R')
                    						{elog.saveToFile(line+"------------->Error in flag");
                    line=bufferedreader.readLine();}
                    				 else
								     {  n1=0;
								    	 customerdao.filelog(l);
								    	 
								    	 System.out.println("error in flag");
								     break;}
                    					}
                    
                    			
                    				else
                    				{		if(choice=='R')
                    				{	elog.saveToFile(line+"------------->Error in Record Status");
                    				 line=bufferedreader.readLine();}
                    			 else
							     {  n1=0;
							    	 customerdao.filelog(l);
							    	 
							    	 System.out.println("error in  Record Status");
							     break;}
                    				}
                    		
                    			
                    			else
                    			{
                    				if(choice=='R')

                    				{elog.saveToFile(line+"------------>Error in Email Format");
                    line=bufferedreader.readLine();}
                                            
                    				 else
    							     {  n1=0;
    							    	 customerdao.filelog(l);
    							    	 
    							    	 System.out.println("--------->error in Email Format");
    							     break;}
                        				}
                                          

                                            

                    		else

                                    {
                    			if(choice=='R')
                                        
                    			{	elog.saveToFile(line+"--------->Error in pin code");
                    			 line=bufferedreader.readLine();}
                    			 else
							     {  n1=0;
							    	 customerdao.filelog(l);
							    	 
							    	 System.out.println("error in pin code");
							     break;}

                                    }

                    	else
                    		{if(choice=='R')
                    		{elog.saveToFile(line+"--------->Error in Name");
                    line=bufferedreader.readLine();}
                    		else
                    			{n1=0;
				    	 customerdao.filelog(l);
				    	 
				    	 System.out.println("error in Name");
				     break;}}
                   
               
                    	
                    	else
                    {if(choice=='R')
                    {	elog.saveToFile(line+"---------->Missing value");		         
                    line=bufferedreader.readLine();}
                    
                    else
        			{n1=0;
	    	 customerdao.filelog(l);
	    	 
	    	 System.out.println("Missing value");
	     break;}
                    }
                    
                
                    else
                    	if(choice=='R')
                    {	elog.saveToFile(line+"---------->unique constraint");		         
                    line=bufferedreader.readLine();}    
                    
                    	 else
             			{n1=0;
     	    	 customerdao.filelog(l);
     	    	 
     	    	 System.out.println("unique constraint");
     	     break;}

                                                 
 
	}
                   	   
      
}
	    catch(Exception e)

	    {  
	    	if(choice=='R')
	 
	    		{
	    		elog.saveToFile(line);
	    		
	    	 line=bufferedreader.readLine();
	    	 }

	    	else if(choice=='F')

	    	{  
	    		n1=0;

	
	    		try {
		
	    			customerdao.filelog(l);
	
	    		} 
	    		catch (IOException e2) {
		
		
	    			e2.printStackTrace();
	
	    		}
	    		catch (SQLException e2)
	    		{
	
		
	    			e2.printStackTrace();
	
	    		}
}
	}
}                
}