package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.execution.Execution;
import com.nucleus.execution.Execution1;


@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public Controller() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		    response.setContentType("text/html");
		    PrintWriter writer=response.getWriter();
		    
		
		String l=request.getParameter("file");
		
	 String level=request.getParameter("level");
	 
	 char ch=level.toUpperCase().charAt(0);
		
		
	 Execution1 customerdaoi = new Execution1();
	 if(request.getParameter("submit")!=null)
	 { switch(ch)
	 {
	 case 'R':
	 
		 customerdaoi . readFromFile(l,ch);
		 break;
	 case 'F':
	
		 customerdaoi.readFromFile(l, ch);
	 }
	
	}
	 
	 String message="<h2><center>";
	 message+="File reading completed";
	 message+="</h2>";
	 message+="<br></br>";
	 message+="Valid records are inserted......For invalid records,check the errorlog. ";
	 writer.print(message+"</center>");
	 
// writer.println("<h4>"+File reading completed"+</h4>");
	 }

}
