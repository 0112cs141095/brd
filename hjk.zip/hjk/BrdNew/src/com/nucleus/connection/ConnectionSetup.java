package com.nucleus.connection;


import java.util.Properties;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;


import java.sql.SQLException;



public class ConnectionSetup 
{
	Connection con;
	public  Connection getConnection() 
	{
	FileReader file = null;
		try{
		
			Properties p=new Properties();
			
			try {
				file = new FileReader("D:\\BrdNew\\src\\com\\nucleus\\connection\\Connection.properties");
			    } 
			catch (FileNotFoundException e)
			{
				
				e.printStackTrace();
			}
			
			try {
				
				p.load(file);
			
			} 
			catch (IOException e)
			{
			
				e.printStackTrace();
			}
		
			
			String url=p.getProperty("url");
			String username=p.getProperty("username");
			String password=p.getProperty("password");
			
			
				Class.forName("oracle.jdbc.driver.OracleDriver");
			
				try
				{
					con=DriverManager.getConnection(url,username,password);
					return con;
				}
				catch (SQLException e)
				{
					
					e.printStackTrace();
				}
			}
		catch (ClassNotFoundException e)
		{
			
				e.printStackTrace();
			}
		
		
return con;	}}
