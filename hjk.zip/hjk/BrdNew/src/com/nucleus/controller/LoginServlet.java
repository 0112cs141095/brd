package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.dao.UserDao;
import com.nucleus.dao.UserDaoImp;
import com.nucleus.domain.User;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		UserDao userDao=new UserDaoImp();
	    User user = new User();
	  
	    
	    if(request.getParameter("submit")!=null)
	    {  
	 
	    	user.setUsername(request.getParameter("username"));
	        user.setPassword(request.getParameter("password"));

	   /*  if(request.getParameter("remember")!=null)
	     {       String username=  request.getParameter("username");
	    	 Cookie cookie1=new Cookie("name",username);
	    	 cookie1.setMaxAge(20);
	    	 response.addCookie(cookie1);
	    	 
	    	 String password=request.getParameter("password");
	    	 Cookie cookie2=new Cookie("password",password);
	    	 response.addCookie(cookie2);
	     }*/
	    	 
	    	 String str=  userDao.login(user);
	     
		   		if(str.equals("maker"))
		   		{
		   			String username=user.getUsername();
		   			HttpSession session = request.getSession();	    
		          session.setAttribute("currentSessionUser", username); 
		   			request.getRequestDispatcher("Maker.jsp").forward(request, response);
		   		}
		   		
		   		else if(str.equals("checker"))
		   		{
		   			request.getRequestDispatcher("Checker.jsp").forward(request, response);
		   		}
		   		else if(str.equals("not valid"))
		   		{
		   			request.getRequestDispatcher("Register.jsp").forward(request, response);
		   		}
	 
	    }
		        
	    if(request.getParameter("logout")!=null)
	    {
	    	 HttpSession session = request.getSession(false);	 
	    	 List l= new ArrayList();
	    	if(session!=null)
	        {
	    	 
	    		System.out.println("***********");
	           System.out.println((String)session.getAttribute("currentSessionUser"));
	    	
	           if(session!=null)
	         	{
	    		    System.out.println((String)session.getAttribute("currentSessionUser"));
	                 PrintWriter  out= response.getWriter();
	               
	         	
	                 

	                
                   
	    			
	                 request.getRequestDispatcher("Login.jsp").forward(request, response);
	    				session.invalidate();
		        }
	    		
	      }
	    else
	    		request.getRequestDispatcher("Login.jsp").forward(request, response);
	    }
	    
	    
	    
	}
			
			
}
	       

