package com.nucleus.controller;



import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;











import com.nucleus.domain.Customer;
import com.nucleus.service.CustomerService;
import com.nucleus.service.CustomerServiceImp;
@WebServlet("/CustomerServlet")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
   public CustomerServlet() {
        super();
     
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		HttpSession session=request.getSession(false);
		CustomerService customerservice=new CustomerServiceImp();
		PrintWriter out=response.getWriter();
		
		String action = request.getParameter("action");
		
		try
		{
		 
			if(action.equals("new"))
		 {
			 	if(session!=null)
			 	{
			 				RequestDispatcher rd = request.getRequestDispatcher("Customer.jsp");
			 				rd.include(request, response);
			 	}
		
			 	else 
			 	{
			 				RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
			 				rd.include(request, response);
			 	}
		 }
		 
		  if(action.equals("viewbyid"))
		 { 
				if(session!=null)
				{
					
							RequestDispatcher rd = request.getRequestDispatcher("ViewById.jsp");
							rd.include(request, response);
				}
				
				else
				{
							RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
							rd.include(request, response);
				}
		 }
		  if(action.equals("update"))
		 {
				if(session!=null)
				{
							RequestDispatcher rd = request.getRequestDispatcher("UpdateId.jsp");
							rd.include(request, response);
				}
				
				else
				{
							RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
							rd.include(request, response);
				}
		 }
		 
		 if(action.equals("deletid"))
		 {
		        if(session!=null)
		        {
			                RequestDispatcher rd = request.getRequestDispatcher("deleteid.jsp");
			                rd.include(request, response);
		        }
		
		       else
		        {
			                RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
			                rd.include(request, response);
		        }
	     }
		
		 if(action.equals("viewall"))
		 {
		         if(session!=null)
	      	     {

			                 RequestDispatcher rd = request.getRequestDispatcher("view.jsp");
			                 rd.include(request, response);
			     }
		
	           	else
		         {
			                 RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
			                 rd.include(request, response);
		         }
		
		 }
		 
		 if(action.equals("viewpagination"))
		{
			
				if(session!=null)
				{
						 System.out.println("***********");
				         String spageid=request.getParameter("page");  
				         int pageid=Integer.parseInt(spageid);  
				         
				         int start=1; 
				         int stop=5;
				       
				         if(pageid==1){}
				        
				         
				         else
				         {  
				          start=((pageid-1)*stop)+1;
				          stop=pageid*stop;
				       
				         }  

				      List<Customer> list=customerservice.viewpagination(start,stop);
				 
				        for(Customer books:list)
					      out.println(books+"\n");  
				         
				        request.setAttribute("c", list);
				
				        request.getRequestDispatcher("viewallp.jsp").forward(request, response);
				}
					
					 else
						request.getRequestDispatcher("Login.jsp").forward(request, response);
						
					
			}
			
		
		
		
		}
		
		catch(Exception e)
		 {
			 System.out.println(e);
	     }
		 
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out=response.getWriter();
		   
		
		CustomerService customerservice=new CustomerServiceImp();
	
		if(request.getParameter("customersubmit")!=null)
		 
		{
			HttpSession session = request.getSession(false);	 
			
		
		
		    if(session!=null)
		    {
				Customer c=new Customer();
        	    
				c.setCustomerCode(request.getParameter("code"));
                c.setCustomerName(request.getParameter("name"));
                c.setCustomerAddress1(request.getParameter("address1"));
                c.setCustomerAddress2(request.getParameter("address2"));
                c.setPin(Integer.parseInt(request.getParameter("pin")));
                c.setMailId(request.getParameter("email"));
                c.setContactNumber(Long.parseLong(request.getParameter("cnum")));
                c.setContactPerson(request.getParameter("cperson"));
                c.setRecordStatus("N");
                c.setFlag("A");
        
        
                String date=new SimpleDateFormat("dd-MMM-yyyy").format(Calendar.getInstance().getTime());
                c.setDate(date);
        
          
                String name=  (String) session.getAttribute("currentSessionUser"); 
                c.setCreatedBy(name);
      
                c.setModifiedDate("");
                c.setModifiedBy("");
        
                c.setAuthorizedDate(request.getParameter("gghgh"));
                c.setAuthorizedBy(request.getParameter("hjghjgh"));
                c.setGender(request.getParameter("gender"));
      
                System.out.println(c);
                String str= customerservice.insert(c);
       
       if(str.equals("saved"))
       {
    	           request.getRequestDispatcher("Insertion.jsp").forward(request, response);
       }
	   else
				  request.getRequestDispatcher("Login.jsp").forward(request, response);
		
		}	
		    else
			        request.getRequestDispatcher("Login.jsp").forward(request, response);
	}
		
		
	
		
		if(request.getParameter("deleteid")!=null)
		{
			
			     System.out.println("**********");
                 HttpSession session = request.getSession(false);	
			
		 if(session!=null)
		 {
			         String str=customerservice.delete(request.getParameter("dcode"));
			      
			  if(str.equals("deleted"))
	          {
	        	      request.getRequestDispatcher("deletion.jsp").forward(request, response);
	          }
				
			  else if(str.equals("no"))
			  {
					  request.getRequestDispatcher("Deleteerror.jsp").forward(request, response);
			  }
				
			  else
					
					  request.getRequestDispatcher("Login.jsp").forward(request, response);
		}
			else
				
				       request.getRequestDispatcher("Login.jsp").forward(request, response);
		 }
		
		
		
		
		if(request.getParameter("viewbyid")!=null)
		{ 
			HttpSession session = request.getSession(false);	 
			
			if(session!=null)
		
			{
				System.out.println("**********");
			
				try
				{
			          List<Customer> list=customerservice.view(request.getParameter("viewbox"));

			        for(Customer books:list)
				    out.println(books+"\n");  
			  
			        request.setAttribute("c", list);
			        request.getRequestDispatcher("viewall.jsp").forward(request, response);
			     }
			    catch(Exception e)
			    {
				request.getRequestDispatcher("Deleteerror.jsp").forward(request, response);
			    }
			}
			else
				request.getRequestDispatcher("Login.jsp").forward(request, response);
				
			
		}
		
		
		
		if(request.getParameter("viewsubmit")!=null)
		{
			
			HttpSession session = request.getSession(false);	 
			
			if(session!=null)
			{
				System.out.println("***********");
			
				List<Customer> list=customerservice.view("no");
			     
				for(Customer books:list)
				 out.println(books+"\n");  
			 
				request.setAttribute("c", list);
			    request.getRequestDispatcher("viewall.jsp").forward(request, response);
			}
				
			else
					request.getRequestDispatcher("Login.jsp").forward(request, response);
					
				
		}
		
		
		
		if(request.getParameter("update")!=null)
		{ 
			HttpSession session = request.getSession(false);	
			
			if(session!=null)
			{
			      List<Customer> list=customerservice.view(request.getParameter("updatebox"));
		         
			      request.setAttribute("c", list);
		          request.getRequestDispatcher("Update.jsp").forward(request, response);
		    }
			else
			      request.getRequestDispatcher("Login.jsp").forward(request, response);
	     }
		
		
		
		if(request.getParameter("us")!=null)
		{
			HttpSession session = request.getSession(false);	   
			
			Customer c=new Customer();
			     
			          c.setCustomerCode(request.getParameter("code1"));
			          c.setCustomerName(request.getParameter("name"));
		              c.setCustomerAddress1(request.getParameter("address1"));
		              c.setCustomerAddress2(request.getParameter("address2"));
		              c.setPin(Integer.parseInt(request.getParameter("pin")));
		              c.setMailId(request.getParameter("email"));
		              c.setContactNumber(Long.parseLong(request.getParameter("cnum")));
		              c.setContactPerson(request.getParameter("cperson"));
		              c.setRecordStatus("M");
		              c.setFlag("A");
		              c.setDate(request.getParameter("createddate"));
		              c.setCreatedBy(request.getParameter("createdby"));  
		      
		           String name=  (String) session.getAttribute("currentSessionUser"); 
		           System.out.println(name);
		           c.setModifiedBy(name);
		        
                   String date=new SimpleDateFormat("dd-MMM-yyyy").format(Calendar.getInstance().getTime());
		           System.out.println(date);
		           c.setModifiedDate(date);
		       
		           c.setAuthorizedDate(request.getParameter("gghgh"));
		           c.setAuthorizedBy(request.getParameter("hjghjgh"));
              
		            System.out.println(c);
		     String str=customerservice.update(c);
	          
		     
		     if(str.equals("updated"))
	           {
	        	   request.getRequestDispatcher("updation.jsp").forward(request, response);
	           }
	       
		     else
				  request.getRequestDispatcher("Login.jsp").forward(request, response);
		}
	
		
		
		
		
	}

}
