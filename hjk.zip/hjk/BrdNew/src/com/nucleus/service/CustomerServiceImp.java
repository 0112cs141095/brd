package com.nucleus.service;

import java.util.List;

import com.nucleus.dao.CustomerDao;
import com.nucleus.dao.CustomerDaoFactory;
import com.nucleus.dao.CustomerDaoImp;
import com.nucleus.domain.Customer;

public class CustomerServiceImp  implements CustomerService{

	//CustomerDao customerdao=new CustomerDaoImp();
	CustomerDao customerdao=CustomerDaoFactory .getCustomerDaoImpl("rdbms");
	@Override
	public String insert(Customer c) {
		String str=customerdao.insert(c);
		return str;
	}

	@Override
	public String delete(String s) {
		String str=customerdao.delete(s);
		return str;
		
	}

	@Override
	public List view(String id) {
	    List <Customer> list= customerdao.view(id);
		return list;
	}

	@Override
	public String update(Customer c) {
		String str=customerdao.update(c);
		return str;
		
	}

	@Override
	public List viewpagination(int start, int total) {
		  List <Customer> list= customerdao.viewpagination(start,total);
		return list;
	}
	
	
}
