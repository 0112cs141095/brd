package com.nucleus.service;

import com.nucleus.domain.User;

public interface UserService {
	 public  String login(User user);
}
