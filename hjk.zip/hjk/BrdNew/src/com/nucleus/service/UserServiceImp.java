package com.nucleus.service;

import com.nucleus.dao.UserDao;
import com.nucleus.dao.UserDaoImp;
import com.nucleus.domain.User;

public class UserServiceImp implements UserService{
UserDao userdao=new UserDaoImp();
	@Override
	public String login(User user) {
		userdao.login(user);
		return null;
	}

	
}
