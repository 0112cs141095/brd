package com.nucleus.service;

import java.util.List;

import com.nucleus.domain.Customer;

public interface CustomerService {

	public String insert(Customer c);
	 public String delete(String s);
	 public List view(String id);
	 public  String  update(Customer c);
	 public List  viewpagination(int start,int total);
}
