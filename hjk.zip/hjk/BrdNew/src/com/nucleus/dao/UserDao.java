package com.nucleus.dao;

import com.nucleus.domain.User;

public interface UserDao {
	  public  String login(User user);
}
