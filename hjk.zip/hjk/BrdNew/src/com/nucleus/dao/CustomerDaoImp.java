package com.nucleus.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpSession;



import com.nucleus.connection.ConnectionSetup;
import com.nucleus.domain.Customer;


public class CustomerDaoImp implements CustomerDao{
	List list1=new ArrayList();
	ConnectionSetup connectionSetup=new ConnectionSetup();
	Connection	con1=connectionSetup.getConnection();
	
	public String insert(Customer c)
	{
		try{
	

	PreparedStatement pstmt=con1.prepareStatement("insert into customer143 values(sa1.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		
			pstmt.setString(1,c.getCustomerCode());
			pstmt.setString(2,c.getCustomerName());
			pstmt.setString(3,c.getCustomerAddress1());
			pstmt.setString(4, c.getCustomerAddress2());
			       
			pstmt.setInt(5,c.getPin());
			pstmt.setString(6,c.getMailId());
			pstmt.setLong(7,c.getContactNumber());
			pstmt.setString(8,c.getContactPerson());
			
			pstmt.setString(9,c.getRecordStatus());
			pstmt.setString(10,c.getFlag());
		
			pstmt.setString(11,c.getDate());
		
			pstmt.setString(12,c.getCreatedBy());
			pstmt.setString(13,c.getModifiedDate());
			pstmt.setString(14,c.getModifiedBy());
			pstmt.setString(15,c.getAuthorizedDate());
			pstmt.setString(16,c.getAuthorizedBy());
			pstmt.setString(17,c.getGender());
			pstmt.executeUpdate();
			return "saved";
			
		         
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				
			}
		finally{
			try {
				con1.close();
			} 
			catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		return "no";
			
		}
	
	
	
	
	 public String delete(String s)
	 {
		 try{
			 
			      PreparedStatement pstmt1=con1.prepareStatement("select * from customer143 where CODE=?") ;
			       pstmt1.setString(1,s);
			        ResultSet r1= pstmt1.executeQuery();
			 
			   if(r1.next())
			  {
				 PreparedStatement pstmt2=con1.prepareStatement("delete from customer143 where CODE=?");
		         pstmt1.setString(1,s);
		           pstmt1.executeUpdate();
		        
		         return "deleted";
		      }
			   else
			  { 
				 return "no";
              }
		   }	
		  catch(SQLException e)
			    {
				return "no";
				
			       }
			
		 finally{
				try {
					con1.close();
				} 
				catch (SQLException e) {
					
					e.printStackTrace();
				}
	}
			}
	
		
	 
	 public List  view(String id)
	 {PreparedStatement pstmt1;
	 List <Customer> list=null;
	 String ch;
	 String	ch1;
		 try
		 {
		         if(id.equals("no"))
		       {
			      pstmt1=con1.prepareStatement("select CODE,NAME,ADDRESS1 ,ADDRESS2,PINCODE,EMAIL,CONTACTNUMBER,PRIMARY_CONTACT_PERSON,RECORD_STATUS,FLAG,TO_CHAR( CREATE_DATE, 'dd-MON-yyyy'),CREATED_BY,TO_CHAR(MOFIDIEDDATE,'dd-MON-yyyy'),MODIFIED_BY,AUTHORIZED_DATE,AUTHORIZED_BY,GENDER  from customer143");
			
		       }
		         else
			 {
		        	 pstmt1=con1.prepareStatement("select CODE,NAME,ADDRESS1 ,ADDRESS2,PINCODE,EMAIL,CONTACTNUMBER,PRIMARY_CONTACT_PERSON,RECORD_STATUS,FLAG,TO_CHAR( CREATE_DATE, 'dd-MON-yyyy'),CREATED_BY,TO_CHAR(MOFIDIEDDATE,'dd-MON-yyyy'),MODIFIED_BY,AUTHORIZED_DATE,AUTHORIZED_BY,GENDER  from customer143 where CODE=?");
		             pstmt1.setString(1,id);}
		
		            list= new ArrayList<>();
                    ResultSet r1= pstmt1.executeQuery();
		 
		           while(r1.next())
		            {
			               Customer c=new Customer();
			
			                 c.setCustomerCode(r1.getString(1));
			                 c.setCustomerName(r1.getString(2));
			                 c.setCustomerAddress1(r1.getString(3));
			                 c.setCustomerAddress2(r1.getString(4));
			                 c.setPin(r1.getInt(5));
				             c.setMailId(r1.getString(6));
				             c.setContactNumber(r1.getLong(7));
				             c.setContactPerson(r1.getString(8));
                             c.setRecordStatus(r1.getString(9));
				             c.setFlag(r1.getString(10));
				             c.setDate(r1.getString(11));
		                     c.setCreatedBy(r1.getString(12));
			             	 c.setModifiedDate(r1.getString(13));
			              	 c.setModifiedBy(r1.getString(14));
			             	 c.setAuthorizedDate(r1.getString(15));
			             	 c.setAuthorizedBy(r1.getString(16));
			             	 
			             	 String str=r1.getString(17);
			             	
			             	 
			             	
			             	 
			         			 
			         		
			             	if(str.contains("female"))
			         		{
			         			c.setCheckfemale("checked='checked'");
			         		}
			         		else
			         			c.setCheckfemale("")	;
			         		
			             	
			             	 if(str.contains("male"))
				         		{
			             		c.setCheckmale("checked='checked'");
				         		}
				         		else
				         			c.setCheckmale("");
			             	 
			
				           list.add(c);
				           System.out.println(list);
				
	              }
		
		           return list;
		
	 }
		 catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		 
	 finally
	 {
			try {
				con1.close();
			} 
			catch (SQLException e) {
				
				e.printStackTrace();
			}
	}
		
		 return null;	
		 
	 }
	 
	        
	public String update(Customer c)
	{

		try
		{
		PreparedStatement pstmt=con1.prepareStatement("Update customer143 SET  NAME=? ,ADDRESS1=? ,ADDRESS2=? ,PINCODE=?,EMAIL=?,CONTACTNUMBER=?,PRIMARY_CONTACT_PERSON=?,RECORD_STATUS=?,FLAG=?,CREATE_DATE=?,CREATED_BY=?,MOFIDIEDDATE=?,MODIFIED_BY=?,AUTHORIZED_DATE=?,AUTHORIZED_BY=?  WHERE CODE=?");
	
		pstmt.setString(1,c.getCustomerName());
		pstmt.setString(2,c.getCustomerAddress1());
		pstmt.setString(3, c.getCustomerAddress2());
		         
		pstmt.setInt(4,c.getPin());
		pstmt.setString(5,c.getMailId());
		pstmt.setLong(6,c.getContactNumber());
		pstmt.setString(7,c.getContactPerson());
	
		pstmt.setString(8,c.getRecordStatus());
		pstmt.setString(9,c.getFlag());
		
		pstmt.setString(10,c.getDate());
		
		pstmt.setString(11,c.getCreatedBy());
		pstmt.setString(12,c.getModifiedDate());
		pstmt.setString(13,c.getModifiedBy());
		pstmt.setString(14,c.getAuthorizedDate());
		pstmt.setString(15,c.getAuthorizedBy());
		pstmt.setString(16,c.getCustomerCode());
		
		pstmt.executeUpdate();
		return "updated";
		
	}
		catch(SQLException e)
		{
			e.printStackTrace();
		
		}
	
		finally
		{
			try {
				con1.close();
			} 
			catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
			return null;}

	
	public List  viewpagination(int start,int stop)
	 {
		 System.out.println(start);
		 System.out.println(stop);
		 PreparedStatement p;
		 List <Customer> list=new ArrayList<>();
		 try{
			 
	
			 if(start==1&&stop==5)
	 p=con1.prepareStatement("select CODE,NAME,ADDRESS1 ,ADDRESS2,PINCODE,EMAIL,CONTACTNUMBER,PRIMARY_CONTACT_PERSON,RECORD_STATUS,FLAG,TO_CHAR( CREATE_DATE, 'dd-MON-yyyy'),CREATED_BY,TO_CHAR(MOFIDIEDDATE,'dd-MON-yyyy'),MODIFIED_BY,AUTHORIZED_DATE,AUTHORIZED_BY  from customer143 where ROWNUM between "+start+"and "+ stop);
			
			 else
			 { System.out.println(start);
				 p=con1.prepareStatement("select CODE,NAME,ADDRESS1 ,ADDRESS2,PINCODE,EMAIL,CONTACTNUMBER,PRIMARY_CONTACT_PERSON,RECORD_STATUS,FLAG,TO_CHAR( CREATE_DATE, 'dd-MON-yyyy'),CREATED_BY,TO_CHAR(MOFIDIEDDATE,'dd-MON-yyyy'),MODIFIED_BY,AUTHORIZED_DATE,AUTHORIZED_BY  from customer143 OFFSET "+start+" ROW FETCH FIRST 5 ROWS ONLY");		} 
			
			 ResultSet r1= p.executeQuery();
		 
		  while(r1.next())
		 {
			 Customer c=new Customer();
			
			      c.setCustomerCode(r1.getString(1));
			      c.setCustomerName(r1.getString(2));
			      c.setCustomerAddress1(r1.getString(3));
			      c.setCustomerAddress2(r1.getString(4));
		          c.setPin(r1.getInt(5));
				  c.setMailId(r1.getString(6));
				  c.setContactNumber(r1.getLong(7));
				  c.setContactPerson(r1.getString(8));
				  c.setRecordStatus(r1.getString(9));
				  c.setFlag(r1.getString(10));
			      c.setDate(r1.getString(11));
                  c.setCreatedBy(r1.getString(12));
				 c.setModifiedDate(r1.getString(13));
				 c.setModifiedBy(r1.getString(14));
				 c.setAuthorizedDate(r1.getString(15));
				 c.setAuthorizedBy(r1.getString(16));
				
			
				
				System.out.println(c);
				
				
				list.add(c);
				System.out.println(list);
				
				
	 }
		 return list;
		
	 }
		 catch(SQLException e)
			{
			
				e.printStackTrace();
				
			}
		 finally
		 {
				try {
					con1.close();
				} 
				catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
				
		 return null;
				}
	
	
}


