package com.nucleus.dao;

public class CustomerDaoFactory {
	
		public static CustomerDao getCustomerDaoImpl(String imptype)
		{
			if(imptype.equals("rdbms"))
			{
				System.out.println("rdbms implementation");
				return new CustomerDaoImp();
			}	
			else if(imptype.equals("xml")){
				
				System.out.println("xml implementation");

				return new CustomerDaoImp();
			}
			else if(imptype.equals("flat")) {
				
				System.out.println("flat implementation");

				return new CustomerDaoImp();
			}
			else
				return null;
		}
	}


