package Servelet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;






@WebServlet("/Calculator")
public class Calculator extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Calculator() {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		
		String number1=request.getParameter("f_input");
		
	
		int n1=Integer.parseInt(number1);
		String number2=request.getParameter("s_input");
		int n2=Integer.parseInt(number1);
	   
		PrintWriter out=response.getWriter();
		
	
		   String htmlRespone = "<html>";
	        htmlRespone += "<h2>Your first input  is: " + n1 + "<br/>";       
	        htmlRespone += "Your second input is: " + n2+ "</h2>";     
	        
	        htmlRespone += "</html>";

	        out.println(htmlRespone);
	     
		if (request.getParameter("b1") != null) 
	        	{

			out.print("RESULT IS "+(n1+n2));
	        		
	        	}
	        	
	        	
	        else if (request.getParameter("b2") != null) {

	        	out.println("RESULT IS "+((n1-n2)));
	        } else if (request.getParameter("b3") != null) {
	        	out.println("RESULT IS "+((n1*n2)));
	        	
	        } else if (request.getParameter("b4") != null) {

	        	out.println("RESULT IS "+((n1/n2)));
	            
	        }

		
		
		
		
		
		
		
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
