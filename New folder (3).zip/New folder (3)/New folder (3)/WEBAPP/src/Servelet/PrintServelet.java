package Servelet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PrintServelet
 */
@WebServlet("/PrintServelet")
public class PrintServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PrintServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     String n1=request.getParameter("n1");
     int num1=Integer.parseInt(n1);
		String n2=request.getParameter("n2");
		int num2=Integer.parseInt(n2);
		
		PrintWriter out=response.getWriter();
		String s="<table style='width:50%'>";
		 if (request.getParameter("submit") != null) 
	 { for(int i=1;i<=10;i++)
			
		 {
		          if(i%2==0)
				  s+="<tr bgcolor='#FF0000'>";
		          else
		        	  s+="<tr bgcolor='blue'>";
			 for(int j=num1;j<=num2;j++)
			 {      
				 
				 
						  s+="<td><span style='color:black;'>"+ j*i+"</span></td>";
			
			 }
			        s+="</tr>";
				 
		 }out.println(s+"</table>");
	}
		 }
	

}
