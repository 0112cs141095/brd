package Servelet;
import javafiles.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Student
 */
@WebServlet("/Student")
public class Student extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Student() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out=response.getWriter();
	Enumeration e=(request.getParameterNames());
	
		while(e.hasMoreElements())
		{ String parameternames=(String) e.nextElement();
			out.println(parameternames);
		}
	 
	/*	for(;e.hasMoreElements();)
		{  
			 String parameternames=(String) e.nextElement();
			 out.println(parameternames);
		}*/
		
		String name=request.getParameter("name");
		
		String rollno=request.getParameter("rollno");
		String total=request.getParameter("marks");
		int marks=Integer.parseInt(total);
	
		Student1 s=new Student1(rollno,marks,name);
		 String data=s.display();
	
		
		request.setAttribute("stdData",s);
		
	RequestDispatcher dispatcher=request.getRequestDispatcher("StudentServelet2");
      dispatcher.forward(request, response);
	
      
     /*  String s1[]=data.split("\n");
	     if (request.getParameter("submit") != null) 
	        	{for(int i=0;i<s1.length;i++)
	        		out.println(s1[i]+"<br></br>");}
	        	*/
	        	
	       
		
	}

}
