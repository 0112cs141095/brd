package javafiles;



public class Student1 {
	
	 public String name;
	 public 	String rollno;
	 public int marks;
	 final int max_marks=50;
	 public 	float percentage;
	 public 	String grade;
	
	public Student1(String rollno, int marks,String name) {
		super();
		this.name=name;
		this.rollno = rollno;
		this.marks = marks;
		}
	
	float percentage(int marks)
	{

		float x=((float)marks/max_marks)*100;
	
	return x;
	}
	
	String grade(int marks)
	{
		if(marks>=40 || marks==50)
			return "A";
		if(marks>=30|| marks<40)
			return "B";
		if(marks>=20|| marks<30)
			return "C";
		if(marks>=10|| marks<20)
		return "D";
		if(marks<10)
			return "F";
		else
			return "Invalid marks";
	
	}
	
public String display()
{
	String data="namev" + name+"\n";
	        data+="rollnov" +rollno+"\n";
	        data+="marks " +marks+"\n";
	        data+="max_marks "+ max_marks+"\n";
	        data+="grade "+grade(marks)+"\n";
	        data+="percentage "+percentage(marks);
	        return data;
}
	
/*public	String toString()
	{
	
	return "RollNo " +rollno + "Name " + name + "Marks " +marks + "percentage" + percentage +  "grade" +grade;
		
	}*/

	
}
	


