package com.nucleus.execution;
import com.nucleus.connection.ConnectionSetup;
import com.nucleus.DAO.BookDAO;
import com.nucleus.DAO.BookDAOImp;
import com.nucleus.domain.Book;

public class BookExecution {

	public static void main(String[] args) {
		System.out.println("enter your choice");
		System.out.println("1.insert book");
		System.out.println("2.search book by id");
		System.out.println("3.display all books");
		System.out.println("4.delete book by id");
		System.out.println("5.update  books");
		
	
Book b1=new Book(12,"wonder1",200);

BookDAO bookDAO=new BookDAOImp();
bookDAO.saveBook(b1);
System.out.println("*****************");
  Book b2=bookDAO.getBookByBookId(11);
System.out.println(b2);
System.out.println("*****************");
bookDAO.getBook();
System.out.println("*****************");
bookDAO.deletebook(1001);
System.out.println("*****************");
bookDAO.update(12);


	}

}
