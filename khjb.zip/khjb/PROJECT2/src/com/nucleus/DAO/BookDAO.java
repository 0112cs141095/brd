
	package com.nucleus.DAO;

	import com.nucleus.domain.Book;

	public interface BookDAO 
	{
	public void saveBook(Book book);
	public Book getBookByBookId(int bookId);
	public void getBook();
	public void deletebook(int bookId);
	public void update(int bookId);
	}


