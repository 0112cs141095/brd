
		package com.nucleus.DAO;

		import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

		import com.nucleus.connection.ConnectionSetup;
import com.nucleus.domain.Book;

	public	 class BookDAOImp implements BookDAO 
		{
             
		
			public void saveBook(Book book) {
				try
				{
				ConnectionSetup connectionSetup=new ConnectionSetup();
				Connection con1=connectionSetup.getConnection();
				PreparedStatement pstmt=con1.prepareStatement("insert into BookStore1 values(?,?,?)");
				pstmt.setInt(1,book.getBookId() );
				pstmt.setString(2, book.getBookName());
				pstmt.setFloat(3,book.getPrice());
				pstmt.executeUpdate();
				System.out.println("saved");
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
				
			}

	
			public Book getBookByBookId(int bookId) {
				Book b=new Book(0,null,0);
				try
				{ConnectionSetup connectionSetup=new ConnectionSetup();
				Connection con2=connectionSetup.getConnection();
				  PreparedStatement pstmt1=con2.prepareStatement("select * from BookStore1 where bookid=?");  
	       pstmt1.setInt(1,bookId);  
	        pstmt1.executeUpdate();
	        ResultSet r1=pstmt1.executeQuery();
	        r1.next();
	        int bookid1= r1.getInt(1);
	  	  String bookname1=r1.getString(2);
	  		float price1=r1.getFloat(3);
	  	    b=new Book (bookid1,bookname1,price1);
	       // return b;
	        }
	        catch(SQLException e)
			{
				e.printStackTrace();
			}
			catch(NullPointerException e)
			{
				System.out.println("Invalid id");
			}
				 return b;	}
		
			
	
	public void getBook() {
		
		try {
			ConnectionSetup connectionSetup=new ConnectionSetup();
			Connection con3=connectionSetup.getConnection();
			  PreparedStatement pstmt2;
			pstmt2 = con3.prepareStatement("select * from BookStore1");
		
			
		
		
		  ResultSet r1=pstmt2.executeQuery();
		  while(r1.next())
		  { int bookid1= r1.getInt(1);
		  String bookname1=r1.getString(2);
			float price1=r1.getFloat(3);
		    System.out.println("ID: "+   bookid1  +"  NAME: "+ bookname1+ " PRICE: " + price1);   
		  }	}
		  catch (SQLException e) {
			  e.printStackTrace();
		  }
			}
			
         
		
	
	public void deletebook(int bookId)
	{try {
		ConnectionSetup connectionSetup=new ConnectionSetup();
		Connection con4=connectionSetup.getConnection();
		PreparedStatement pstmt3;
		
			pstmt3 = con4.prepareStatement("delete from BookStore1 where bookid=?");
		
			
		 
	       pstmt3.setInt(1,bookId);  
	        pstmt3.executeUpdate(); 
	        
	        System.out.println("deleted");
	}
		catch (SQLException e)
	
		{ e.printStackTrace();
	        
		
	}}
		
	public void update(int bookID)
	{
		try
		{
			ConnectionSetup connectionSetup=new ConnectionSetup();
			Connection con4=connectionSetup.getConnection();
			PreparedStatement pstmt3;
			
			pstmt3 = con4.prepareStatement("update BookStore1  set bookId=? , bookName=?,price=? ");
			Scanner kb=new Scanner (System.in);
			
					String name3=kb.nextLine();
					float price3=kb.nextFloat();
			pstmt3.setInt(1,bookID);
			pstmt3.setString(2,name3 );
			pstmt3.setFloat(3,price3);
			pstmt3.executeUpdate();
			System.out.println("updated");
		}
		catch (SQLException e)
		
		{ e.printStackTrace();
	        
		
	}
	
	
	
	}

	
		}

